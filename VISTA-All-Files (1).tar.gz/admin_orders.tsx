import { useListAllOrders, useUpdateOrderStatus, getListAllOrdersQueryOptions } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { getListAllOrdersQueryKey } from "@workspace/api-client-react";

export default function AdminOrdersPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: orders, isLoading } = useListAllOrders({
    query: {
      ...getListAllOrdersQueryOptions(),
      enabled: !!user && user.role === "admin",
    }
  });

  const updateStatusMutation = useUpdateOrderStatus({
    mutation: {
      onSuccess: () => {
        toast({ title: "Status Updated", description: "Order status has been updated successfully." });
        queryClient.invalidateQueries({ queryKey: getListAllOrdersQueryKey() });
      }
    }
  });

  if (!user || user.role !== "admin") {
    setLocation("/");
    return null;
  }

  const handleStatusChange = (orderId: number, status: any) => {
    updateStatusMutation.mutate({ id: orderId, data: { status } });
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case "delivered": return "bg-green-100 text-green-800 border-green-200";
      case "shipped": return "bg-blue-100 text-blue-800 border-blue-200";
      case "processing": return "bg-orange-100 text-orange-800 border-orange-200";
      case "cancelled": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Manage All Orders</h1>

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-gray-500">Loading orders...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-gray-50 text-gray-600 font-medium border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4">Order Details</th>
                  <th className="px-6 py-4">Customer</th>
                  <th className="px-6 py-4">Value / Comm.</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Update Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {orders?.map(order => (
                  <tr key={order.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="font-medium text-gray-900">#{order.id}</div>
                      <div className="text-gray-500 text-xs mt-1">{format(new Date(order.createdAt), "MMM d, yyyy HH:mm")}</div>
                      <div className="text-xs mt-1 text-gray-500 max-w-[200px] truncate" title={`${order.hostelName}, Room ${order.roomNumber}`}>
                        {order.hostelName}, Room {order.roomNumber}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-medium text-gray-900">{order.customerName || `User #${order.customerId}`}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-medium text-gray-900">KSh {order.totalAmount.toLocaleString()}</div>
                      <div className="text-xs text-green-600 font-medium mt-1">Comm: KSh {order.commissionAmount?.toLocaleString() || 0}</div>
                      <div className="text-xs text-gray-500 mt-1">Vendor: KSh {order.vendorAmount?.toLocaleString() || 0}</div>
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant="outline" className={`${getStatusColor(order.status)}`}>{order.status}</Badge>
                    </td>
                    <td className="px-6 py-4">
                      <Select 
                        defaultValue={order.status} 
                        onValueChange={(val) => handleStatusChange(order.id, val)}
                        disabled={updateStatusMutation.isPending}
                      >
                        <SelectTrigger className="w-[130px] h-8 text-xs bg-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="processing">Processing</SelectItem>
                          <SelectItem value="shipped">Shipped</SelectItem>
                          <SelectItem value="delivered">Delivered</SelectItem>
                          <SelectItem value="cancelled">Cancelled</SelectItem>
                        </SelectContent>
                      </Select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}