import { useGetCart, useUpdateCartItem, useRemoveFromCart, getGetCartQueryOptions } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { useGuestCart } from "@/hooks/use-guest-cart";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useQueryClient } from "@tanstack/react-query";
import { getGetCartQueryKey } from "@workspace/api-client-react";
import { Trash2, ShoppingBag } from "lucide-react";

export default function CartPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const guestCart = useGuestCart();

  const { data: cartItems, isLoading } = useGetCart({
    query: { ...getGetCartQueryOptions(), enabled: !!user && user.role === "buyer" },
  });

  const updateCartItemMutation = useUpdateCartItem();
  const removeFromCartMutation = useRemoveFromCart();

  const handleUpdateQuantity = async (id: number, quantity: number) => {
    if (quantity <= 0) return;
    await updateCartItemMutation.mutateAsync({ id, data: { quantity } });
    queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
  };

  const handleRemove = async (id: number) => {
    await removeFromCartMutation.mutateAsync({ id });
    queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
  };

  if (!user) {
    const guestItems = guestCart.items;
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Cart</h1>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6 flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
          <p className="text-sm text-blue-800">
            <Link href="/login" className="font-semibold underline">Sign in</Link> for faster checkout, order tracking, and history.
          </p>
          <Link href="/register">
            <Button variant="outline" size="sm">Create account</Button>
          </Link>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          <div className="flex-1">
            {guestItems.length === 0 ? (
              <div className="bg-white p-8 rounded-lg border border-gray-200 text-center">
                <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                  <ShoppingBag className="h-8 w-8 text-gray-400" />
                </div>
                <h2 className="text-xl font-bold text-gray-900 mb-2">Your cart is empty</h2>
                <p className="text-gray-500 mb-6">Browse our products and add items you'd like to order.</p>
                <Button onClick={() => setLocation("/products")} className="bg-secondary text-primary hover:bg-[#f3a847]">
                  Browse Products
                </Button>
              </div>
            ) : (
              <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                <div className="border-b border-gray-200 p-4 bg-gray-50 text-sm text-gray-500 font-medium">
                  {guestItems.length} item(s) in your cart
                </div>
                <ul className="divide-y divide-gray-200">
                  {guestItems.map((item) => (
                    <li key={item.productId} className="p-6 flex flex-col sm:flex-row gap-6">
                      <div className="w-full sm:w-28 h-28 bg-gray-100 rounded flex-shrink-0 flex items-center justify-center p-2">
                        {item.imageUrl ? (
                          <img src={item.imageUrl} alt={item.name} className="w-full h-full object-contain" />
                        ) : (
                          <span className="text-xs text-gray-400">No image</span>
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <Link href={`/products/${item.productId}`} className="text-lg font-medium text-gray-900 hover:text-blue-600">
                              {item.name}
                            </Link>
                            <div className="text-sm text-gray-500 mt-1">Sold by {item.vendorName}</div>
                          </div>
                          <div className="text-lg font-bold text-gray-900">KSh {item.price.toLocaleString()}</div>
                        </div>
                        <div className="mt-4 flex items-center gap-6">
                          <div className="flex items-center gap-2">
                            <label className="text-sm text-gray-600">Qty:</label>
                            <select
                              className="border-gray-300 rounded bg-gray-50 py-1 px-2 text-sm"
                              value={item.quantity}
                              onChange={(e) => guestCart.updateQuantity(item.productId, Number(e.target.value))}
                            >
                              {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => (
                                <option key={n} value={n}>{n}</option>
                              ))}
                            </select>
                          </div>
                          <div className="w-px h-4 bg-gray-300" />
                          <button
                            onClick={() => guestCart.removeItem(item.productId)}
                            className="text-sm text-blue-600 hover:underline flex items-center gap-1"
                          >
                            <Trash2 className="h-4 w-4" /> Remove
                          </button>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
                <div className="p-4 bg-gray-50 text-right text-lg">
                  Subtotal: <span className="font-bold text-gray-900">KSh {guestCart.subtotal.toLocaleString()}</span>
                </div>
              </div>
            )}
          </div>

          {guestItems.length > 0 && (
            <div className="w-full lg:w-80 flex-shrink-0">
              <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm sticky top-24 space-y-4">
                <div className="text-lg">
                  Subtotal ({guestCart.totalItems} item{guestCart.totalItems !== 1 ? "s" : ""}):{" "}
                  <span className="font-bold text-gray-900">KSh {guestCart.subtotal.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-green-700">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  Free delivery to your hostel room.
                </div>
                <Button
                  className="w-full bg-secondary hover:bg-[#f3a847] text-primary font-bold rounded-full"
                  onClick={() => setLocation("/checkout")}
                >
                  Proceed to Checkout
                </Button>
                <p className="text-xs text-center text-gray-400">No account required to check out.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (user.role !== "buyer") {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <p className="text-gray-500">The cart is only available for buyers.</p>
      </div>
    );
  }

  if (isLoading) {
    return <div className="container mx-auto px-4 py-12 text-center">Loading cart...</div>;
  }

  const subtotal = cartItems?.reduce((sum, item) => sum + item.subtotal, 0) || 0;
  const itemCount = cartItems?.reduce((sum, item) => sum + item.quantity, 0) || 0;

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Shopping Cart</h1>

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="flex-1">
          {cartItems?.length === 0 ? (
            <div className="bg-white p-8 rounded-lg border border-gray-200 text-center">
              <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <ShoppingBag className="h-8 w-8 text-gray-400" />
              </div>
              <h2 className="text-xl font-bold text-gray-900 mb-2">Your VISTA Cart is empty</h2>
              <p className="text-gray-500 mb-6">Continue shopping to add items.</p>
              <Button onClick={() => setLocation("/products")} className="bg-secondary text-primary hover:bg-[#f3a847]">
                Continue Shopping
              </Button>
            </div>
          ) : (
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              <div className="border-b border-gray-200 p-4 bg-gray-50 text-sm text-gray-500 font-medium">
                {itemCount} item(s) in your cart
              </div>
              <ul className="divide-y divide-gray-200">
                {cartItems?.map((item) => (
                  <li key={item.id} className="p-6 flex flex-col sm:flex-row gap-6">
                    <div className="w-full sm:w-32 h-32 bg-gray-100 rounded flex-shrink-0 relative">
                      {item.product?.imageUrl ? (
                        <img src={item.product.imageUrl} alt={item.product.name} className="w-full h-full object-contain p-2" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">No image</div>
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <div>
                          <Link href={`/products/${item.productId}`} className="text-lg font-medium text-gray-900 hover:text-blue-600 line-clamp-2">
                            {item.product?.name}
                          </Link>
                          <div className="text-sm text-green-600 mt-1">In Stock</div>
                          <div className="text-sm text-gray-500 mt-1">Sold by {item.product?.vendorName}</div>
                        </div>
                        <div className="text-lg font-bold text-gray-900">KSh {item.product?.price.toLocaleString()}</div>
                      </div>
                      <div className="mt-4 flex items-center gap-6">
                        <div className="flex items-center gap-2">
                          <label htmlFor={`qty-${item.id}`} className="text-sm text-gray-600">Qty:</label>
                          <select
                            id={`qty-${item.id}`}
                            className="border-gray-300 rounded bg-gray-50 py-1 px-2 text-sm focus:ring-secondary focus:border-secondary shadow-sm"
                            value={item.quantity}
                            onChange={(e) => handleUpdateQuantity(item.id, Number(e.target.value))}
                            disabled={updateCartItemMutation.isPending}
                          >
                            {Array.from({ length: Math.max(10, item.quantity) }, (_, i) => i + 1).map((num) => (
                              <option key={num} value={num}>{num}</option>
                            ))}
                          </select>
                        </div>
                        <div className="w-px h-4 bg-gray-300" />
                        <button
                          onClick={() => handleRemove(item.id)}
                          className="text-sm text-blue-600 hover:underline flex items-center"
                          disabled={removeFromCartMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4 mr-1" /> Delete
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
              <div className="p-4 bg-gray-50 text-right">
                <div className="text-lg">
                  Subtotal ({itemCount} items): <span className="font-bold text-gray-900">KSh {subtotal.toLocaleString()}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {cartItems && cartItems.length > 0 && (
          <div className="w-full lg:w-80 flex-shrink-0">
            <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm sticky top-24">
              <div className="text-lg mb-4">
                Subtotal ({itemCount} items): <span className="font-bold text-gray-900">KSh {subtotal.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-2 mb-6 text-sm text-green-700">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Your order is eligible for campus delivery.
              </div>
              <Button
                className="w-full bg-secondary hover:bg-[#f3a847] text-primary font-normal rounded-full mb-4"
                onClick={() => setLocation("/checkout")}
              >
                Proceed to checkout
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
