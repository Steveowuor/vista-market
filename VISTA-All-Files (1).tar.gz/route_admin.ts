import { Router } from "express";
import {
  db, ordersTable, orderItemsTable, productsTable,
  vendorsTable, usersTable, commissionsTable
} from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth.js";
import { UpdateOrderStatusBody } from "@workspace/api-zod";

const router = Router();

function formatVendor(vendor: any, productCount = 0) {
  return {
    id: vendor.id,
    userId: vendor.userId,
    businessName: vendor.businessName,
    description: vendor.description,
    logoUrl: vendor.logoUrl,
    contactEmail: vendor.contactEmail,
    contactPhone: vendor.contactPhone,
    address: vendor.address,
    commissionRate: parseFloat(vendor.commissionRate),
    isApproved: vendor.isApproved,
    productCount,
    totalSales: 0,
    paymentType: vendor.paymentType,
    mpesaNumber: vendor.mpesaNumber,
    bankName: vendor.bankName,
    bankAccount: vendor.bankAccount,
    bankBranch: vendor.bankBranch,
    paybillNumber: vendor.paybillNumber,
    paybillBusinessName: vendor.paybillBusinessName,
    tillNumber: vendor.tillNumber,
    createdAt: vendor.createdAt.toISOString(),
  };
}

async function formatOrder(order: any) {
  const items = await db.select().from(orderItemsTable).where(eq(orderItemsTable.orderId, order.id));
  let customerName = order.guestName || "Guest";
  if (order.customerId) {
    const [customer] = await db.select().from(usersTable).where(eq(usersTable.id, order.customerId)).limit(1);
    if (customer) customerName = customer.name;
  }
  return {
    id: order.id,
    customerId: order.customerId,
    customerName,
    guestName: order.guestName,
    guestEmail: order.guestEmail,
    hostelName: order.hostelName,
    roomNumber: order.roomNumber,
    contactPhone: order.contactPhone,
    items: items.map((item) => ({
      id: item.id,
      productId: item.productId,
      productName: item.productName,
      quantity: item.quantity,
      unitPrice: parseFloat(item.unitPrice),
      subtotal: parseFloat(item.subtotal),
    })),
    subtotal: parseFloat(order.subtotal || order.totalAmount),
    buyerFee: parseFloat(order.buyerFee || "0"),
    totalAmount: parseFloat(order.totalAmount),
    commissionAmount: parseFloat(order.commissionAmount),
    vendorAmount: parseFloat(order.vendorAmount),
    status: order.status,
    paymentMethod: order.paymentMethod,
    mpesaPhone: order.mpesaPhone,
    createdAt: order.createdAt.toISOString(),
  };
}

router.get("/stats", requireAuth, async (req, res) => {
  const user = (req as any).user;
  if (user.role !== "admin") { res.status(403).json({ message: "Forbidden" }); return; }

  const [{ totalRevenue }] = await db
    .select({ totalRevenue: sql<number>`coalesce(sum(total_amount::numeric), 0)::float` })
    .from(ordersTable);

  const [{ totalCommissions }] = await db
    .select({ totalCommissions: sql<number>`coalesce(sum(commission_amount::numeric), 0)::float` })
    .from(ordersTable);

  const [{ totalBuyerFees }] = await db
    .select({ totalBuyerFees: sql<number>`coalesce(sum(buyer_fee::numeric), 0)::float` })
    .from(ordersTable);

  const [{ totalOrders }] = await db
    .select({ totalOrders: sql<number>`count(*)::int` })
    .from(ordersTable);

  const [{ pendingOrders }] = await db
    .select({ pendingOrders: sql<number>`count(*)::int` })
    .from(ordersTable)
    .where(eq(ordersTable.status, "pending"));

  const [{ totalProducts }] = await db
    .select({ totalProducts: sql<number>`count(*)::int` })
    .from(productsTable);

  const [{ totalVendors }] = await db
    .select({ totalVendors: sql<number>`count(*)::int` })
    .from(vendorsTable);

  const [{ pendingVendors }] = await db
    .select({ pendingVendors: sql<number>`count(*)::int` })
    .from(vendorsTable)
    .where(eq(vendorsTable.isApproved, false));

  const [{ totalUsers }] = await db
    .select({ totalUsers: sql<number>`count(*)::int` })
    .from(usersTable);

  const recentOrders = await db.select().from(ordersTable)
    .orderBy(sql`${ordersTable.createdAt} DESC`).limit(5);
  const formattedRecent = await Promise.all(recentOrders.map(formatOrder));

  // Real top vendors by sales
  const vendors = await db.select().from(vendorsTable);
  const topVendors = await Promise.all(
    vendors.map(async (v) => {
      const products = await db.select().from(productsTable).where(eq(productsTable.vendorId, v.id));
      const productIds = products.map((p) => p.id);
      let sales = 0;
      if (productIds.length > 0) {
        const orderItems = await db.select().from(orderItemsTable)
          .where(sql`${orderItemsTable.productId} = ANY(${productIds})`);
        for (const oi of orderItems) sales += parseFloat(oi.subtotal);
      }
      return { vendorName: v.businessName, sales, commission: sales * 0.07 };
    })
  );
  topVendors.sort((a, b) => b.sales - a.sales);

  // Revenue by month (last 6 months from real data)
  const revenueByMonth = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    const monthStart = new Date(d.getFullYear(), d.getMonth(), 1);
    const monthEnd = new Date(d.getFullYear(), d.getMonth() + 1, 0);
    const [{ rev }] = await db.select({
      rev: sql<number>`coalesce(sum(total_amount::numeric), 0)::float`
    }).from(ordersTable)
      .where(sql`${ordersTable.createdAt} >= ${monthStart} AND ${ordersTable.createdAt} <= ${monthEnd}`);
    const [{ comm }] = await db.select({
      comm: sql<number>`coalesce(sum(commission_amount::numeric), 0)::float`
    }).from(ordersTable)
      .where(sql`${ordersTable.createdAt} >= ${monthStart} AND ${ordersTable.createdAt} <= ${monthEnd}`);
    revenueByMonth.push({
      month: d.toLocaleString("default", { month: "short", year: "2-digit" }),
      revenue: rev,
      commissions: comm,
    });
  }

  const orderStatusCounts = await db.select({
    status: ordersTable.status,
    count: sql<number>`count(*)::int`,
  }).from(ordersTable).groupBy(ordersTable.status);

  const ordersByStatus: Record<string, number> = {};
  for (const row of orderStatusCounts) ordersByStatus[row.status] = row.count;

  res.json({
    totalRevenue,
    totalCommissions,
    totalBuyerFees,
    totalOrders,
    totalProducts,
    totalVendors,
    totalUsers,
    pendingOrders,
    pendingVendors,
    revenueByMonth,
    topVendors: topVendors.slice(0, 5),
    recentOrders: formattedRecent,
    ordersByStatus,
  });
});

router.get("/commissions", requireAuth, async (req, res) => {
  const user = (req as any).user;
  if (user.role !== "admin") { res.status(403).json({ message: "Forbidden" }); return; }

  const commissions = await db.select().from(commissionsTable)
    .orderBy(sql`${commissionsTable.createdAt} DESC`);

  const formatted = await Promise.all(
    commissions.map(async (c) => {
      const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.id, c.vendorId)).limit(1);
      return {
        id: c.id,
        orderId: c.orderId,
        vendorId: c.vendorId,
        vendorName: vendor?.businessName || "Unknown",
        orderAmount: parseFloat(c.orderAmount),
        commissionRate: parseFloat(c.commissionRate),
        commissionAmount: parseFloat(c.commissionAmount),
        status: c.status,
        createdAt: c.createdAt.toISOString(),
      };
    })
  );
  res.json(formatted);
});

router.get("/orders", requireAuth, async (req, res) => {
  const user = (req as any).user;
  if (user.role !== "admin") { res.status(403).json({ message: "Forbidden" }); return; }
  const orders = await db.select().from(ordersTable).orderBy(sql`${ordersTable.createdAt} DESC`);
  const formatted = await Promise.all(orders.map(formatOrder));
  res.json(formatted);
});

router.put("/orders/:id/status", requireAuth, async (req, res) => {
  const user = (req as any).user;
  if (user.role !== "admin") { res.status(403).json({ message: "Forbidden" }); return; }

  const id = parseInt(String(req.params.id));
  const parsed = UpdateOrderStatusBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ message: "Invalid input" }); return; }

  const [order] = await db.update(ordersTable).set({ status: parsed.data.status }).where(eq(ordersTable.id, id)).returning();
  if (!order) { res.status(404).json({ message: "Order not found" }); return; }
  res.json(await formatOrder(order));
});

router.get("/vendors", requireAuth, async (req, res) => {
  const user = (req as any).user;
  if (user.role !== "admin") { res.status(403).json({ message: "Forbidden" }); return; }

  const vendors = await db.select().from(vendorsTable).orderBy(sql`${vendorsTable.createdAt} DESC`);
  const withCounts = await Promise.all(
    vendors.map(async (v) => {
      const [{ count }] = await db.select({ count: sql<number>`count(*)::int` })
        .from(productsTable).where(eq(productsTable.vendorId, v.id));
      return formatVendor(v, count);
    })
  );
  res.json(withCounts);
});

router.put("/vendors/:id/approve", requireAuth, async (req, res) => {
  const user = (req as any).user;
  if (user.role !== "admin") { res.status(403).json({ message: "Forbidden" }); return; }

  const id = parseInt(String(req.params.id));
  const [vendor] = await db.update(vendorsTable).set({ isApproved: true }).where(eq(vendorsTable.id, id)).returning();
  if (!vendor) { res.status(404).json({ message: "Vendor not found" }); return; }

  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` })
    .from(productsTable).where(eq(productsTable.vendorId, vendor.id));
  res.json(formatVendor(vendor, count));
});

router.put("/vendors/:id/reject", requireAuth, async (req, res) => {
  const user = (req as any).user;
  if (user.role !== "admin") { res.status(403).json({ message: "Forbidden" }); return; }

  const id = parseInt(String(req.params.id));
  const [vendor] = await db.update(vendorsTable).set({ isApproved: false }).where(eq(vendorsTable.id, id)).returning();
  if (!vendor) { res.status(404).json({ message: "Vendor not found" }); return; }
  res.json(formatVendor(vendor, 0));
});

router.get("/products", requireAuth, async (req, res) => {
  const user = (req as any).user;
  if (user.role !== "admin") { res.status(403).json({ message: "Forbidden" }); return; }

  const products = await db.select().from(productsTable).orderBy(sql`${productsTable.createdAt} DESC`);
  const formatted = await Promise.all(products.map(async (p) => {
    const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.id, p.vendorId)).limit(1);
    const orderItems = await db.select().from(orderItemsTable).where(eq(orderItemsTable.productId, p.id));
    const totalSold = orderItems.reduce((sum, i) => sum + i.quantity, 0);
    const totalRevenue = orderItems.reduce((sum, i) => sum + parseFloat(i.subtotal), 0);
    return {
      id: p.id, name: p.name, price: parseFloat(p.price),
      category: p.category, condition: p.condition, stock: p.stock,
      imageUrl: p.imageUrl, vendorId: p.vendorId,
      vendorName: vendor?.businessName || "Unknown",
      rating: p.rating ? parseFloat(p.rating) : 0,
      reviewCount: p.reviewCount, totalSold, totalRevenue,
      createdAt: p.createdAt.toISOString(),
    };
  }));
  res.json(formatted);
});

router.get("/customers", requireAuth, async (req, res) => {
  const user = (req as any).user;
  if (user.role !== "admin") { res.status(403).json({ message: "Forbidden" }); return; }

  const customers = await db.select().from(usersTable)
    .where(eq(usersTable.role, "buyer"))
    .orderBy(sql`${usersTable.createdAt} DESC`);

  const formatted = await Promise.all(customers.map(async (c) => {
    const orders = await db.select().from(ordersTable).where(eq(ordersTable.customerId, c.id));
    const totalSpent = orders.reduce((sum, o) => sum + parseFloat(o.totalAmount), 0);
    const lastOrder = orders.sort((a, b) =>
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    )[0];
    return {
      id: c.id,
      name: c.name,
      email: c.email,
      orderCount: orders.length,
      totalSpent,
      lastOrderAt: lastOrder?.createdAt?.toISOString() || null,
      createdAt: c.createdAt.toISOString(),
    };
  }));

  res.json(formatted);
});

export default router;
