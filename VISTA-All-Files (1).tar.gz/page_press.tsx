import { Calendar, ExternalLink } from "lucide-react";

const RELEASES = [
  {
    date: "May 10, 2026",
    title: "VISTA Marketplace Crosses 8,000 Orders Milestone",
    summary: "VISTA Rongo University Marketplace has processed over 8,000 campus orders since launch, with Food Products and Books being the most popular categories.",
    tag: "Growth",
    tagColor: "bg-green-100 text-green-700",
  },
  {
    date: "March 28, 2026",
    title: "VISTA Introduces Vendor Analytics Dashboard with Real-Time Charts",
    summary: "Vendors on the VISTA platform can now access monthly revenue trends, top product rankings, and order-status breakdowns directly from their dashboard.",
    tag: "Product Update",
    tagColor: "bg-blue-100 text-blue-700",
  },
  {
    date: "February 14, 2026",
    title: "VISTA Partners with Local Rongo Boutiques for Expanded Clothing Category",
    summary: "Over 15 new boutique vendors from Rongo town have joined the VISTA marketplace, bringing fashion, accessories, and clothing to campus shoppers.",
    tag: "Partnership",
    tagColor: "bg-purple-100 text-purple-700",
  },
  {
    date: "January 5, 2026",
    title: "M-PESA and Airtel Money Now Available at Checkout",
    summary: "VISTA has integrated M-PESA STK Push and Airtel Money at checkout, making it seamless for students to pay directly from their mobile wallets.",
    tag: "Feature",
    tagColor: "bg-orange-100 text-orange-700",
  },
  {
    date: "November 20, 2025",
    title: "VISTA Marketplace Officially Launches at Rongo University",
    summary: "After months of development and vendor onboarding, VISTA Rongo Uni Marketplace officially launched, offering 7 product categories and campus hostel delivery.",
    tag: "Launch",
    tagColor: "bg-yellow-100 text-yellow-700",
  },
];

export default function PressPage() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <h1 className="text-4xl font-bold mb-4">Press Releases</h1>
          <p className="text-xl text-gray-300">Latest news and announcements from VISTA Rongo University Marketplace</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-3xl">
        <div className="space-y-6">
          {RELEASES.map((r) => (
            <div key={r.title} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow group">
              <div className="flex items-center gap-3 mb-3">
                <span className={`text-xs font-semibold px-3 py-1 rounded-full ${r.tagColor}`}>{r.tag}</span>
                <span className="flex items-center gap-1 text-xs text-gray-400">
                  <Calendar className="h-3.5 w-3.5" />{r.date}
                </span>
              </div>
              <h2 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-primary transition-colors">{r.title}</h2>
              <p className="text-gray-600 text-sm leading-relaxed mb-4">{r.summary}</p>
              <button className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:text-secondary transition-colors">
                Read Full Release <ExternalLink className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>

        {/* Media contact */}
        <div className="mt-12 bg-gray-50 rounded-xl p-8 text-center">
          <h3 className="font-bold text-gray-900 text-xl mb-2">Media Enquiries</h3>
          <p className="text-gray-600 text-sm mb-4">
            For press enquiries, interview requests, or media kits, contact our communications team.
          </p>
          <a href="mailto:press@vista.ac.ke" className="inline-block bg-primary text-white font-semibold px-6 py-2.5 rounded-lg hover:bg-primary/90 transition-colors">
            press@vista.ac.ke
          </a>
        </div>
      </div>
    </div>
  );
}
