import { useGetVendorStats, useGetVendorProducts, useGetVendorOrders, useGetMyVendorProfile, useGetVendorPayment, getGetVendorPaymentQueryOptions, getGetMyVendorProfileQueryOptions, getGetVendorStatsQueryOptions, getGetVendorProductsQueryOptions, getGetVendorOrdersQueryOptions } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Package, ShoppingCart, TrendingUp, Clock, Plus, Edit, Store, AlertCircle, Wallet, Settings, ArrowUpRight, CheckCircle, BarChart2, ListOrdered } from "lucide-react";
import { format } from "date-fns";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell, PieChart, Pie, Legend,
} from "recharts";

const STATUS_COLORS: Record<string, string> = {
  pending: "#febd69", processing: "#3b82f6", shipped: "#8b5cf6", delivered: "#22c55e", cancelled: "#ef4444",
};

export default function VendorDashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: profile, isLoading: isProfileLoading } = useGetMyVendorProfile({
    query: { ...getGetMyVendorProfileQueryOptions(), enabled: !!user && user.role === "vendor" },
  });
  const { data: stats, isLoading: isStatsLoading } = useGetVendorStats({
    query: { ...getGetVendorStatsQueryOptions(), enabled: !!user && user.role === "vendor" },
  });
  const { data: productsData, isLoading: isProductsLoading } = useGetVendorProducts({
    query: { ...getGetVendorProductsQueryOptions(), enabled: !!user && user.role === "vendor" },
  });
  const { data: orders, isLoading: isOrdersLoading } = useGetVendorOrders({
    query: { ...getGetVendorOrdersQueryOptions(), enabled: !!user && user.role === "vendor" },
  });
  const { data: payment } = useGetVendorPayment({
    query: { ...getGetVendorPaymentQueryOptions(), enabled: !!user && user.role === "vendor" },
  });

  if (!user || user.role !== "vendor") { setLocation("/login"); return null; }
  if (isProfileLoading || isStatsLoading || isProductsLoading || isOrdersLoading) {
    return <div className="container mx-auto px-4 py-12 text-center text-gray-500">Loading dashboard...</div>;
  }

  if (!profile) {
    return (
      <div className="container mx-auto px-4 py-20 text-center max-w-md">
        <Store className="h-16 w-16 mx-auto text-gray-400 mb-4" />
        <h2 className="text-2xl font-bold mb-4">Complete Your Vendor Profile</h2>
        <p className="text-gray-600 mb-6">Register your business details to start selling on VISTA.</p>
        <Button onClick={() => setLocation("/vendor/register")} className="w-full">Register Business</Button>
      </div>
    );
  }

  const grossRevenue = (stats as any)?.grossRevenue ?? 0;
  const platformFee = (stats as any)?.platformFee ?? (grossRevenue * 0.07);
  const netPayout = (stats as any)?.netPayout ?? (grossRevenue * 0.93);
  const revenueByMonth: { month: string; revenue: number }[] = (stats as any)?.revenueByMonth ?? [];
  const topProducts: { productName: string; revenue: number; quantity: number }[] = (stats as any)?.topProducts ?? [];
  const ordersByStatus: Record<string, number> = (stats as any)?.ordersByStatus ?? {};

  const orderStatusData = Object.entries(ordersByStatus).map(([name, value]) => ({
    name: name.charAt(0).toUpperCase() + name.slice(1),
    value,
    fill: STATUS_COLORS[name] || "#94a3b8",
  }));

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered": return "bg-green-100 text-green-800";
      case "shipped": return "bg-blue-100 text-blue-800";
      case "processing": return "bg-orange-100 text-orange-800";
      case "cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Vendor Dashboard</h1>
          <p className="text-gray-500 mt-1">Welcome back, <span className="font-semibold text-primary">{profile.businessName}</span></p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" onClick={() => setLocation("/vendor/orders")} className="gap-2">
            <ListOrdered className="h-4 w-4" /> Orders
          </Button>
          <Button variant="outline" onClick={() => setLocation("/vendor/settings")} className="gap-2">
            <Settings className="h-4 w-4" /> Payout Settings
          </Button>
          {profile.isApproved && (
            <Button onClick={() => setLocation("/vendor/products/new")} className="bg-secondary text-primary hover:bg-[#f3a847] gap-2">
              <Plus className="h-4 w-4" /> Add Product
            </Button>
          )}
        </div>
      </div>

      {/* Banners */}
      {!profile.isApproved && (
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 mb-6 flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-orange-500 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-semibold text-orange-800">Account Pending Approval</p>
            <p className="text-sm text-orange-700 mt-1">Your vendor application is being reviewed. You'll be able to list products once approved by VISTA admin.</p>
          </div>
        </div>
      )}
      {!payment?.paymentType && profile.isApproved && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 mb-6 flex items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-semibold text-yellow-800">Set up your payout method</p>
              <p className="text-sm text-yellow-700">Add your M-PESA, bank, paybill, or till number to receive payments.</p>
            </div>
          </div>
          <Button size="sm" variant="outline" onClick={() => setLocation("/vendor/settings")} className="flex-shrink-0">Set Up Now</Button>
        </div>
      )}

      {/* Revenue Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="bg-primary text-white border-none">
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-primary-foreground/70 text-xs font-medium mb-1">Gross Sales</p>
                <h3 className="text-2xl font-bold">KSh {grossRevenue.toLocaleString(undefined, { maximumFractionDigits: 0 })}</h3>
              </div>
              <div className="bg-white/10 p-2 rounded-full"><TrendingUp className="h-5 w-5 text-secondary" /></div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-red-100 bg-red-50">
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-red-600 text-xs font-medium mb-1">Platform Fee (7%)</p>
                <h3 className="text-2xl font-bold text-red-700">− KSh {platformFee.toLocaleString(undefined, { maximumFractionDigits: 0 })}</h3>
              </div>
              <div className="bg-red-100 p-2 rounded-full"><ArrowUpRight className="h-5 w-5 text-red-500" /></div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-green-700 text-xs font-medium mb-1">Your Net Payout</p>
                <h3 className="text-2xl font-bold text-green-700">KSh {netPayout.toLocaleString(undefined, { maximumFractionDigits: 0 })}</h3>
              </div>
              <div className="bg-green-100 p-2 rounded-full"><Wallet className="h-5 w-5 text-green-600" /></div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-xs font-medium mb-1">Total Orders</p>
                <h3 className="text-2xl font-bold text-gray-900">{stats?.totalOrders ?? 0}</h3>
                <p className="text-xs text-orange-600 mt-1">{stats?.pendingOrders ?? 0} pending</p>
              </div>
              <div className="bg-gray-100 p-2 rounded-full"><ShoppingCart className="h-5 w-5 text-gray-500" /></div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payout method display */}
      {payment?.paymentType && (
        <Card className="mb-8 border-green-200 bg-green-50/50">
          <CardContent className="p-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
              <div>
                <p className="font-semibold text-green-800 text-sm">Payout Method Active</p>
                <p className="text-xs text-green-700 capitalize">
                  {payment.paymentType === "mpesa" ? `M-PESA: ${payment.mpesaNumber}` :
                   payment.paymentType === "bank" ? `Bank: ${payment.bankName} — ${payment.bankAccount}` :
                   payment.paymentType === "paybill" ? `Paybill: ${payment.paybillNumber}` :
                   `Till: ${payment.tillNumber}`}
                </p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setLocation("/vendor/settings")}>Edit</Button>
          </CardContent>
        </Card>
      )}

      {/* Analytics Charts */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-4">
          <BarChart2 className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-bold text-gray-900">Sales Analytics</h2>
        </div>
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Revenue Trend */}
          <div className="lg:col-span-2 bg-white border border-gray-200 rounded-xl p-5">
            <div className="flex justify-between items-center mb-4">
              <p className="font-semibold text-gray-700 text-sm">Monthly Revenue</p>
              <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded">Last 6 months</span>
            </div>
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={revenueByMonth} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 10, fill: "#9ca3af" }} />
                <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                <Tooltip formatter={(v: number) => [`KSh ${v.toLocaleString()}`, "Revenue"]} contentStyle={{ borderRadius: "8px", fontSize: 11 }} />
                <Line type="monotone" dataKey="revenue" stroke="#232f3e" strokeWidth={2.5} dot={{ r: 3, fill: "#febd69" }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          {/* Order Status Pie */}
          <div className="bg-white border border-gray-200 rounded-xl p-5">
            <p className="font-semibold text-gray-700 text-sm mb-4">Orders by Status</p>
            {orderStatusData.length > 0 ? (
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={orderStatusData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={3} dataKey="value">
                    {orderStatusData.map((entry, idx) => <Cell key={idx} fill={entry.fill} />)}
                  </Pie>
                  <Tooltip formatter={(v: number) => [v, "Orders"]} contentStyle={{ borderRadius: "8px", fontSize: 11 }} />
                  <Legend iconSize={8} iconType="circle" wrapperStyle={{ fontSize: 10 }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[180px] flex items-center justify-center text-gray-400 text-xs text-center">No orders yet</div>
            )}
          </div>
        </div>

        {/* Top Products */}
        {topProducts.length > 0 && (
          <div className="bg-white border border-gray-200 rounded-xl p-5 mt-4">
            <p className="font-semibold text-gray-700 text-sm mb-4">Top Products by Revenue</p>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={topProducts} layout="vertical" margin={{ top: 0, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 10 }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                <YAxis type="category" dataKey="productName" tick={{ fontSize: 10 }} width={130} />
                <Tooltip formatter={(v: number) => [`KSh ${v.toLocaleString()}`, "Revenue"]} contentStyle={{ borderRadius: "8px", fontSize: 11 }} />
                <Bar dataKey="revenue" radius={[0, 4, 4, 0]}>
                  {topProducts.map((_, idx) => (
                    <Cell key={idx} fill={idx === 0 ? "#232f3e" : idx === 1 ? "#febd69" : "#3b82f6"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Products & Orders Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Package className="h-5 w-5 text-primary" />
              My Products
              <Badge variant="secondary">{productsData?.length ?? 0}</Badge>
            </CardTitle>
            {profile.isApproved && (
              <Button size="sm" variant="outline" onClick={() => setLocation("/vendor/products/new")}>
                <Plus className="h-3.5 w-3.5 mr-1" /> Add
              </Button>
            )}
          </CardHeader>
          <CardContent>
            {productsData && productsData.length > 0 ? (
              <div className="space-y-3 max-h-80 overflow-y-auto">
                {productsData.map((product) => (
                  <div key={product.id} className="flex items-center gap-3 p-2 border rounded-lg hover:bg-gray-50">
                    <div className="w-10 h-10 bg-gray-100 rounded flex-shrink-0 overflow-hidden">
                      {product.imageUrl
                        ? <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
                        : <Package className="h-4 w-4 text-gray-300 m-3" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm text-gray-900 truncate">{product.name}</p>
                      <p className="text-xs text-gray-500">KSh {product.price.toLocaleString()} · Stock: {product.stock}</p>
                    </div>
                    <Button size="icon" variant="ghost" className="h-7 w-7 flex-shrink-0"
                      onClick={() => setLocation(`/vendor/products/${product.id}/edit`)}>
                      <Edit className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-10 text-gray-400">
                <Package className="h-10 w-10 mx-auto mb-2 opacity-40" />
                <p className="text-sm">{profile.isApproved ? "No products yet. Add your first one!" : "Awaiting approval to list products."}</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <ShoppingCart className="h-5 w-5 text-primary" />
              Recent Orders
            </CardTitle>
            <Button size="sm" variant="outline" onClick={() => setLocation("/vendor/orders")}>View All</Button>
          </CardHeader>
          <CardContent>
            {orders && orders.length > 0 ? (
              <div className="space-y-3 max-h-80 overflow-y-auto">
                {orders.slice(0, 6).map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-2 border rounded-lg hover:bg-gray-50">
                    <div>
                      <p className="font-medium text-sm text-gray-900">Order #{order.id}</p>
                      <p className="text-xs text-gray-500">{order.customerName} · {order.hostelName} {order.roomNumber}</p>
                      <p className="text-xs text-gray-400">{format(new Date(order.createdAt), "dd MMM, HH:mm")}</p>
                    </div>
                    <div className="text-right flex-shrink-0 ml-3">
                      <p className="text-sm font-bold text-primary">KSh {(order.vendorAmount ?? 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
                      <Badge className={`text-xs mt-1 ${getStatusColor(order.status)}`}>{order.status}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-10 text-gray-400">
                <Clock className="h-10 w-10 mx-auto mb-2 opacity-40" />
                <p className="text-sm">No orders yet. Share your products to start selling!</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
