"""
VISTA Marketplace — main.py (shim only)
Real entry: server_index.ts (Express) and main.tsx (React)
"""
print("VISTA runs on Node.js. See server_index.ts and main.tsx.")
