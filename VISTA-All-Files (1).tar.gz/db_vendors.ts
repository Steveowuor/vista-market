import { pgTable, text, serial, timestamp, integer, numeric, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const vendorsTable = pgTable("vendors", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  businessName: text("business_name").notNull(),
  description: text("description"),
  logoUrl: text("logo_url"),
  contactEmail: text("contact_email").notNull(),
  contactPhone: text("contact_phone"),
  address: text("address"),
  commissionRate: numeric("commission_rate", { precision: 5, scale: 2 }).notNull().default("7.00"),
  isApproved: boolean("is_approved").notNull().default(false),
  // Payment payout details
  paymentType: text("payment_type"),
  mpesaNumber: text("mpesa_number"),
  bankName: text("bank_name"),
  bankAccount: text("bank_account"),
  bankBranch: text("bank_branch"),
  paybillNumber: text("paybill_number"),
  paybillBusinessName: text("paybill_business_name"),
  tillNumber: text("till_number"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertVendorSchema = createInsertSchema(vendorsTable).omit({ id: true, createdAt: true });
export type InsertVendor = z.infer<typeof insertVendorSchema>;
export type Vendor = typeof vendorsTable.$inferSelect;
