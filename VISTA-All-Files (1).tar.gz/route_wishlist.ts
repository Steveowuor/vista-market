import { Router } from "express";
import { db, wishlistItemsTable, productsTable, vendorsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth.js";
import { AddToWishlistBody } from "@workspace/api-zod";

const router = Router();

async function formatWishlistItem(item: any) {
  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, item.productId)).limit(1);
  if (!product) return null;
  const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.id, product.vendorId)).limit(1);
  return {
    id: item.id,
    productId: item.productId,
    addedAt: item.addedAt.toISOString(),
    product: {
      id: product.id,
      name: product.name,
      description: product.description,
      price: parseFloat(product.price),
      imageUrl: product.imageUrl,
      category: product.category,
      condition: product.condition,
      stock: product.stock,
      rating: product.rating ? parseFloat(product.rating) : 0,
      reviewCount: product.reviewCount,
      vendorId: product.vendorId,
      vendorName: vendor?.businessName || "Unknown Vendor",
      createdAt: product.createdAt.toISOString(),
    },
  };
}

router.get("/", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const items = await db.select().from(wishlistItemsTable).where(eq(wishlistItemsTable.userId, user.id));
  const formatted = await Promise.all(items.map(formatWishlistItem));
  res.json(formatted.filter(Boolean));
});

router.post("/", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const parsed = AddToWishlistBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }

  const { productId } = parsed.data;

  const [existing] = await db
    .select()
    .from(wishlistItemsTable)
    .where(and(eq(wishlistItemsTable.userId, user.id), eq(wishlistItemsTable.productId, productId)))
    .limit(1);

  if (existing) {
    res.status(409).json({ message: "Already in wishlist" });
    return;
  }

  const [item] = await db.insert(wishlistItemsTable).values({ userId: user.id, productId }).returning();
  const formatted = await formatWishlistItem(item);
  res.status(201).json(formatted);
});

router.delete("/:productId", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const productId = parseInt(String(req.params.productId));

  await db
    .delete(wishlistItemsTable)
    .where(and(eq(wishlistItemsTable.userId, user.id), eq(wishlistItemsTable.productId, productId)));

  res.json({ message: "Removed from wishlist" });
});

export default router;
