import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Bell, ShoppingBag, Store, CheckCircle2, Info, X } from "lucide-react";
import { format } from "date-fns";

interface Notification {
  id: string;
  type: string;
  title: string;
  message: string;
  href: string;
  createdAt: string;
}

const typeIcon: Record<string, React.ReactNode> = {
  order: <ShoppingBag className="h-4 w-4 text-blue-500" />,
  sale: <ShoppingBag className="h-4 w-4 text-green-500" />,
  vendor_pending: <Store className="h-4 w-4 text-orange-500" />,
  success: <CheckCircle2 className="h-4 w-4 text-green-500" />,
  error: <X className="h-4 w-4 text-red-500" />,
  info: <Info className="h-4 w-4 text-blue-500" />,
};

export function NotificationBell() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);

  const { data: notifications } = useQuery<Notification[]>({
    queryKey: ["notifications", user?.id],
    queryFn: async () => {
      const res = await fetch("/api/notifications");
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!user,
    refetchInterval: 30000,
  });

  const count = Math.min(notifications?.length || 0, 9);

  return (
    <div className="relative">
      <button
        className="relative text-white hover:bg-white/10 p-2 rounded-lg transition-colors"
        onClick={() => setOpen((v) => !v)}
        aria-label="Notifications"
      >
        <Bell className="h-5 w-5" />
        {count > 0 && (
          <span className="absolute -top-0.5 -right-0.5 bg-red-500 text-white text-[10px] font-bold rounded-full h-4 w-4 flex items-center justify-center leading-none">
            {count}
          </span>
        )}
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-11 w-80 bg-white rounded-xl shadow-xl border border-gray-200 z-50 overflow-hidden">
            <div className="px-4 py-3 border-b border-gray-100 flex justify-between items-center bg-gray-50">
              <h3 className="font-bold text-gray-900 text-sm">Notifications</h3>
              <button onClick={() => setOpen(false)} className="text-gray-400 hover:text-gray-600">
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="max-h-[400px] overflow-y-auto divide-y divide-gray-50">
              {!notifications || notifications.length === 0 ? (
                <div className="px-4 py-8 text-center text-gray-400 text-sm">
                  <Bell className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  No notifications
                </div>
              ) : notifications.map((n) => (
                <button
                  key={n.id}
                  className="w-full text-left px-4 py-3 hover:bg-gray-50 transition-colors flex items-start gap-3"
                  onClick={() => { setOpen(false); setLocation(n.href); }}
                >
                  <div className="mt-0.5 p-1.5 rounded-lg bg-gray-100 flex-shrink-0">
                    {typeIcon[n.type] || <Bell className="h-4 w-4 text-gray-400" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-gray-900 truncate">{n.title}</p>
                    <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{n.message}</p>
                    <p className="text-xs text-gray-300 mt-1">
                      {format(new Date(n.createdAt), "MMM d, HH:mm")}
                    </p>
                  </div>
                </button>
              ))}
            </div>
            <div className="px-4 py-2 border-t border-gray-100 bg-gray-50 text-center">
              <button className="text-xs text-blue-600 hover:underline" onClick={() => setOpen(false)}>
                Close
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
