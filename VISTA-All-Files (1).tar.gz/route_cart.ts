import { Router } from "express";
import { db, cartItemsTable, productsTable, vendorsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth.js";
import { AddToCartBody, UpdateCartItemBody } from "@workspace/api-zod";

const router = Router();

async function formatCartItem(item: any) {
  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, item.productId)).limit(1);
  if (!product) return null;
  const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.id, product.vendorId)).limit(1);
  const subtotal = parseFloat(product.price) * item.quantity;
  return {
    id: item.id,
    productId: item.productId,
    quantity: item.quantity,
    subtotal,
    product: {
      id: product.id,
      name: product.name,
      description: product.description,
      price: parseFloat(product.price),
      imageUrl: product.imageUrl,
      category: product.category,
      condition: product.condition,
      stock: product.stock,
      rating: product.rating ? parseFloat(product.rating) : 0,
      reviewCount: product.reviewCount,
      vendorId: product.vendorId,
      vendorName: vendor?.businessName || "Unknown Vendor",
      createdAt: product.createdAt.toISOString(),
    },
  };
}

router.get("/", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const items = await db.select().from(cartItemsTable).where(eq(cartItemsTable.userId, user.id));
  const formatted = await Promise.all(items.map(formatCartItem));
  res.json(formatted.filter(Boolean));
});

router.post("/", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const parsed = AddToCartBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }

  const { productId, quantity } = parsed.data;

  const [existing] = await db
    .select()
    .from(cartItemsTable)
    .where(and(eq(cartItemsTable.userId, user.id), eq(cartItemsTable.productId, productId)))
    .limit(1);

  let item;
  if (existing) {
    [item] = await db
      .update(cartItemsTable)
      .set({ quantity: existing.quantity + quantity })
      .where(eq(cartItemsTable.id, existing.id))
      .returning();
  } else {
    [item] = await db.insert(cartItemsTable).values({ userId: user.id, productId, quantity }).returning();
  }

  const formatted = await formatCartItem(item);
  res.status(201).json(formatted);
});

router.put("/:id", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const id = parseInt(String(req.params.id));
  const parsed = UpdateCartItemBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }

  const [item] = await db
    .update(cartItemsTable)
    .set({ quantity: parsed.data.quantity })
    .where(and(eq(cartItemsTable.id, id), eq(cartItemsTable.userId, user.id)))
    .returning();

  if (!item) {
    res.status(404).json({ message: "Cart item not found" });
    return;
  }

  const formatted = await formatCartItem(item);
  res.json(formatted);
});

router.delete("/:id", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const id = parseInt(String(req.params.id));

  await db
    .delete(cartItemsTable)
    .where(and(eq(cartItemsTable.id, id), eq(cartItemsTable.userId, user.id)));

  res.json({ message: "Item removed from cart" });
});

export default router;
