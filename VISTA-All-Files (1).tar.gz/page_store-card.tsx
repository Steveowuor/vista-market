import { Link } from "wouter";
import { CreditCard, CheckCircle, Lock, Zap, RefreshCcw } from "lucide-react";

export default function StoreCardPage() {
  return (
    <div className="min-h-screen">
      <div className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <CreditCard className="h-12 w-12 mx-auto mb-4 text-secondary" />
          <h1 className="text-4xl font-bold mb-4">VISTA Store Card</h1>
          <p className="text-xl text-gray-300">
            The simplest way to pay on VISTA. Load once, spend anywhere on campus. No bank account needed.
          </p>
          <div className="mt-8">
            <Link href="/register">
              <button className="bg-secondary text-primary font-bold px-8 py-3 rounded-lg hover:bg-[#f3a847] transition-colors text-lg">
                Get Your Store Card
              </button>
            </Link>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        {/* How it works */}
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-10">How It Works</h2>
        <div className="grid md:grid-cols-3 gap-6 mb-14">
          {[
            { step: "1", icon: CreditCard, title: "Get Your Card", desc: "Apply online in 2 minutes. Your virtual card is ready instantly after account verification." },
            { step: "2", icon: RefreshCcw, title: "Load Funds", desc: "Top up using M-PESA, Airtel Money, or bank transfer. Minimum top-up is KSh 100." },
            { step: "3", icon: Zap, title: "Pay Instantly", desc: "Use your card balance at checkout on any VISTA product. One tap, done." },
          ].map(({ step, icon: Icon, title, desc }) => (
            <div key={step} className="bg-white border border-gray-200 rounded-xl p-6 text-center hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-full bg-primary text-white font-bold text-xl flex items-center justify-center mx-auto mb-4">{step}</div>
              <Icon className="h-6 w-6 text-primary mx-auto mb-3" />
              <h3 className="font-bold text-gray-900 mb-2">{title}</h3>
              <p className="text-sm text-gray-600 leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>

        {/* Features */}
        <div className="bg-gray-50 rounded-2xl p-8 mb-10">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Store Card Features</h2>
          <div className="grid md:grid-cols-2 gap-3">
            {[
              "No bank account required — M-PESA top-up",
              "Instant checkout on all VISTA products",
              "Balance never expires",
              "Transfer balance to friends' VISTA accounts",
              "Full transaction history in your account",
              "Zero transaction fees within VISTA",
              "Protected by VISTA security systems",
              "Works for guests and registered buyers",
            ].map((f) => (
              <div key={f} className="flex items-start gap-2">
                <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                <span className="text-sm text-gray-700">{f}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-6 flex gap-4 mb-8">
          <Lock className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
          <div>
            <h3 className="font-bold text-gray-900 mb-1">Your money is safe</h3>
            <p className="text-sm text-gray-600">All Store Card balances are held in a secure escrow account. Funds are only released when you complete a purchase.</p>
          </div>
        </div>

        <div className="text-center">
          <Link href="/register">
            <button className="bg-primary text-white font-bold px-8 py-3 rounded-lg hover:bg-primary/90 transition-colors text-lg">
              Open Your Store Card
            </button>
          </Link>
          <p className="text-sm text-gray-500 mt-3">Already have an account? <Link href="/login" className="text-primary underline">Sign in</Link></p>
        </div>
      </div>
    </div>
  );
}
