import { useState } from "react";
import { useGetVendorOrders, getGetVendorOrdersQueryOptions } from "@workspace/api-client-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { ArrowLeft, ShoppingCart, Clock, CheckCircle2, Truck, PackageCheck, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

const STATUS_OPTIONS = [
  { value: "all", label: "All Orders" },
  { value: "pending", label: "Pending" },
  { value: "processing", label: "Processing" },
  { value: "shipped", label: "Shipped" },
  { value: "delivered", label: "Delivered" },
  { value: "cancelled", label: "Cancelled" },
];

const STATUS_NEXT: Record<string, { value: string; label: string; color: string }> = {
  pending: { value: "processing", label: "Mark Processing", color: "bg-blue-500 hover:bg-blue-600 text-white" },
  processing: { value: "shipped", label: "Mark Shipped", color: "bg-purple-500 hover:bg-purple-600 text-white" },
  shipped: { value: "delivered", label: "Mark Delivered", color: "bg-green-500 hover:bg-green-600 text-white" },
};

const STATUS_ICON: Record<string, React.ReactNode> = {
  pending: <Clock className="h-3.5 w-3.5" />,
  processing: <PackageCheck className="h-3.5 w-3.5" />,
  shipped: <Truck className="h-3.5 w-3.5" />,
  delivered: <CheckCircle2 className="h-3.5 w-3.5" />,
  cancelled: <XCircle className="h-3.5 w-3.5" />,
};

const STATUS_BADGE: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
  processing: "bg-blue-100 text-blue-800 border-blue-200",
  shipped: "bg-purple-100 text-purple-800 border-purple-200",
  delivered: "bg-green-100 text-green-800 border-green-200",
  cancelled: "bg-red-100 text-red-800 border-red-200",
};

export default function VendorOrdersPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState("all");

  const { data: orders, isLoading } = useGetVendorOrders({
    query: { ...getGetVendorOrdersQueryOptions(), enabled: !!user && user.role === "vendor" },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ orderId, status }: { orderId: number; status: string }) => {
      const res = await fetch(`/api/vendor/orders/${orderId}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error("Failed to update");
      return res.json();
    },
    onSuccess: (_, { status }) => {
      queryClient.invalidateQueries({ queryKey: getGetVendorOrdersQueryOptions().queryKey });
      toast({ title: "Order updated", description: `Order marked as ${status}.` });
    },
    onError: () => toast({ title: "Error", description: "Could not update order status.", variant: "destructive" }),
  });

  if (!user || user.role !== "vendor") { setLocation("/login"); return null; }

  const filtered = (orders || []).filter((o) => statusFilter === "all" || o.status === statusFilter);

  const counts = STATUS_OPTIONS.slice(1).reduce((acc, s) => {
    acc[s.value] = (orders || []).filter((o) => o.status === s.value).length;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Link href="/vendor/dashboard">
          <button className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50">
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Order Management</h1>
          <p className="text-sm text-gray-500">Manage and fulfill your customer orders</p>
        </div>
      </div>

      {/* Status Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 mb-6">
        {STATUS_OPTIONS.map((s) => (
          <button
            key={s.value}
            onClick={() => setStatusFilter(s.value)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
              statusFilter === s.value
                ? "bg-primary text-white"
                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            }`}
          >
            {s.label}
            {s.value !== "all" && counts[s.value] > 0 && (
              <span className={`text-xs rounded-full px-1.5 py-0.5 font-bold ${statusFilter === s.value ? "bg-white/20" : "bg-gray-300"}`}>
                {counts[s.value]}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Orders */}
      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => <div key={i} className="h-28 bg-gray-100 rounded-xl animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20 bg-white border border-gray-200 rounded-xl">
          <ShoppingCart className="h-12 w-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No {statusFilter === "all" ? "" : statusFilter} orders yet</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((order) => {
            const nextStatus = STATUS_NEXT[order.status];
            return (
              <div key={order.id} className="bg-white border border-gray-200 rounded-xl p-5 hover:shadow-sm transition-shadow">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="font-bold text-gray-900">Order #{order.id}</span>
                      <Badge variant="outline" className={`text-xs flex items-center gap-1 ${STATUS_BADGE[order.status] || ""}`}>
                        {STATUS_ICON[order.status]} {order.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p><span className="font-medium">Customer:</span> {order.customerName}</p>
                      <p><span className="font-medium">Deliver to:</span> {order.hostelName}, Room {order.roomNumber}</p>
                      <p><span className="font-medium">Contact:</span> {order.contactPhone}</p>
                      <p className="text-xs text-gray-400">{format(new Date(order.createdAt), "dd MMM yyyy, HH:mm")}</p>
                    </div>
                    {/* Items */}
                    <div className="mt-3 space-y-1">
                      {order.items?.map((item: any) => (
                        <div key={item.id} className="text-xs text-gray-500 flex justify-between">
                          <span>{item.productName} × {item.quantity}</span>
                          <span>KSh {item.subtotal.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-3 flex-shrink-0">
                    <div className="text-right">
                      <p className="text-xs text-gray-400">Your payout</p>
                      <p className="text-xl font-bold text-primary">
                        KSh {(order.vendorAmount ?? 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </p>
                      <p className="text-xs text-gray-400">Payment: {order.paymentMethod}</p>
                    </div>
                    {nextStatus && (
                      <Button
                        size="sm"
                        className={nextStatus.color}
                        disabled={updateStatusMutation.isPending}
                        onClick={() => updateStatusMutation.mutate({ orderId: order.id, status: nextStatus.value })}
                      >
                        {nextStatus.label}
                      </Button>
                    )}
                    {order.status !== "cancelled" && order.status !== "delivered" && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-red-200 text-red-600 hover:bg-red-50 text-xs"
                        disabled={updateStatusMutation.isPending}
                        onClick={() => updateStatusMutation.mutate({ orderId: order.id, status: "cancelled" })}
                      >
                        <XCircle className="h-3 w-3 mr-1" /> Cancel
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
