import { Link } from "wouter";
import { CreditCard, Star, Gift, Shield, Zap, CheckCircle } from "lucide-react";

export default function RewardsPage() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="bg-gradient-to-br from-primary via-primary to-[#1a2535] text-white py-20">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <div className="inline-flex items-center gap-2 bg-secondary/20 text-secondary px-4 py-2 rounded-full text-sm font-semibold mb-6">
            <Star className="h-4 w-4 fill-current" /> VISTA Signature Card
          </div>
          <h1 className="text-4xl font-bold mb-4">VISTA Rewards Visa Signature Card</h1>
          <p className="text-xl text-gray-300">
            Earn points on every purchase at VISTA. Redeem for discounts, free deliveries, and exclusive perks.
          </p>
          <div className="mt-8">
            <Link href="/register">
              <button className="bg-secondary text-primary font-bold px-8 py-3 rounded-lg hover:bg-[#f3a847] transition-colors text-lg">
                Apply for Your Card
              </button>
            </Link>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        {/* Card visual */}
        <div className="flex justify-center mb-16">
          <div className="w-80 h-48 bg-gradient-to-br from-primary to-[#1a2535] rounded-2xl shadow-2xl p-6 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-48 h-48 bg-secondary/10 rounded-full -translate-y-12 translate-x-12" />
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-12 -translate-x-12" />
            <div className="relative z-10">
              <div className="flex justify-between items-start mb-8">
                <span className="text-secondary font-bold text-xl">VISTA</span>
                <CreditCard className="h-8 w-8 text-secondary" />
              </div>
              <p className="text-gray-300 text-sm tracking-widest mb-2">•••• •••• •••• 4521</p>
              <div className="flex justify-between items-end">
                <div>
                  <p className="text-xs text-gray-400">Card Holder</p>
                  <p className="font-semibold">RONGO STUDENT</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-gray-400">Expires</p>
                  <p className="font-semibold">05/29</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Benefits */}
        <div className="grid md:grid-cols-2 gap-6 mb-14">
          {[
            { icon: Star, title: "Earn 3× Points", desc: "Get triple reward points on every VISTA purchase — food, books, electronics, and more.", color: "text-yellow-500 bg-yellow-50" },
            { icon: Gift, title: "Redeem for Discounts", desc: "Use your points for instant checkout discounts, free deliveries, or gift vouchers.", color: "text-pink-600 bg-pink-50" },
            { icon: Zap, title: "Instant Approval", desc: "Apply online and get approved within 24 hours. No bank visits required.", color: "text-blue-600 bg-blue-50" },
            { icon: Shield, title: "Zero Fraud Liability", desc: "Shop with confidence. All transactions are monitored and you're protected against fraud.", color: "text-green-600 bg-green-50" },
          ].map(({ icon: Icon, title, desc, color }) => (
            <div key={title} className="bg-white border border-gray-200 rounded-xl p-6 flex gap-4 hover:shadow-md transition-shadow">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${color}`}>
                <Icon className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 mb-1">{title}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Eligibility */}
        <div className="bg-gray-50 rounded-xl p-8 mb-10">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Eligibility Requirements</h2>
          <div className="space-y-2">
            {[
              "Must be a registered student or staff member at Rongo University",
              "Valid VISTA marketplace account (buyer role)",
              "At least 3 completed orders on the platform",
              "Valid national ID or student ID",
            ].map((r) => (
              <div key={r} className="flex items-start gap-2">
                <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                <span className="text-sm text-gray-700">{r}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center">
          <Link href="/register">
            <button className="bg-primary text-white font-bold px-8 py-3 rounded-lg hover:bg-primary/90 transition-colors">
              Apply Now — Free to Join
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
