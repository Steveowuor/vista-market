import { useAuth } from "@/hooks/use-auth";
import { useLocation, Link } from "wouter";
import { User, ShoppingBag, Heart, Settings, LogOut, ChevronRight, Store } from "lucide-react";

export default function AccountPage() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();

  if (!user) {
    setLocation("/login");
    return null;
  }

  const MENU = [
    { icon: ShoppingBag, label: "Your Orders", desc: "Track, return, or buy again", href: "/orders", show: user.role === "buyer" },
    { icon: Heart, label: "Your Wishlist", desc: "Items you've saved for later", href: "/wishlist", show: user.role === "buyer" },
    { icon: Store, label: "Vendor Dashboard", desc: "Manage your store and products", href: "/vendor/dashboard", show: user.role === "vendor" },
    { icon: Settings, label: "Payout Settings", desc: "M-PESA, bank, or paybill details", href: "/vendor/settings", show: user.role === "vendor" },
    { icon: Settings, label: "Admin Dashboard", desc: "Platform management and analytics", href: "/admin/dashboard", show: user.role === "admin" },
  ].filter((m) => m.show);

  const ROLE_BADGE: Record<string, string> = {
    buyer: "bg-blue-100 text-blue-700",
    vendor: "bg-orange-100 text-orange-700",
    admin: "bg-red-100 text-red-700",
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-2xl">
      {/* Profile card */}
      <div className="bg-white border border-gray-200 rounded-2xl p-8 mb-8 text-center shadow-sm">
        <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
          <User className="h-10 w-10 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
        <p className="text-gray-500 mt-1">{user.email}</p>
        <span className={`inline-block mt-3 text-xs font-semibold px-3 py-1 rounded-full capitalize ${ROLE_BADGE[user.role] || "bg-gray-100 text-gray-700"}`}>
          {user.role}
        </span>
      </div>

      {/* Menu items */}
      <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden mb-6 shadow-sm">
        {MENU.map((item, idx) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <div className={`flex items-center gap-4 p-5 hover:bg-gray-50 transition-colors cursor-pointer ${idx < MENU.length - 1 ? "border-b border-gray-100" : ""}`}>
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-900">{item.label}</p>
                  <p className="text-sm text-gray-500">{item.desc}</p>
                </div>
                <ChevronRight className="h-5 w-5 text-gray-400" />
              </div>
            </Link>
          );
        })}
      </div>

      {/* Help links */}
      <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden mb-6 shadow-sm">
        {[
          { label: "Shipping Rates & Policies", href: "/shipping" },
          { label: "Returns & Replacements", href: "/returns" },
          { label: "Help Centre", href: "/help" },
        ].map((item, idx) => (
          <Link key={item.href} href={item.href}>
            <div className={`flex items-center justify-between p-5 hover:bg-gray-50 transition-colors cursor-pointer ${idx < 2 ? "border-b border-gray-100" : ""}`}>
              <span className="text-sm font-medium text-gray-700">{item.label}</span>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </div>
          </Link>
        ))}
      </div>

      {/* Sign out */}
      <button
        onClick={() => { logout(); setLocation("/"); }}
        className="w-full flex items-center justify-center gap-2 bg-white border border-red-200 text-red-600 font-semibold py-4 rounded-xl hover:bg-red-50 transition-colors"
      >
        <LogOut className="h-5 w-5" />
        Sign Out
      </button>
    </div>
  );
}
