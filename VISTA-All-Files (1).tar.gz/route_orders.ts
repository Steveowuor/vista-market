import { Router } from "express";
import {
  db, ordersTable, orderItemsTable, cartItemsTable,
  productsTable, vendorsTable, usersTable, commissionsTable
} from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { requireAuth, optionalAuth } from "../middlewares/auth.js";
import { CreateOrderBody, CreateGuestOrderBody } from "@workspace/api-zod";

const router = Router();

// Buyer pays 10% service fee on top of product prices
const BUYER_FEE_RATE = 0.10;
// Vendor is charged 7% commission on their sales
const VENDOR_COMMISSION_RATE = 0.07;

async function formatOrder(order: any) {
  const items = await db.select().from(orderItemsTable).where(eq(orderItemsTable.orderId, order.id));
  let customerName = order.guestName || "Guest";
  if (order.customerId) {
    const [customer] = await db.select().from(usersTable).where(eq(usersTable.id, order.customerId)).limit(1);
    if (customer) customerName = customer.name;
  }
  return {
    id: order.id,
    customerId: order.customerId,
    customerName,
    guestName: order.guestName,
    guestEmail: order.guestEmail,
    hostelName: order.hostelName,
    roomNumber: order.roomNumber,
    contactPhone: order.contactPhone,
    items: items.map((item) => ({
      id: item.id,
      productId: item.productId,
      productName: item.productName,
      quantity: item.quantity,
      unitPrice: parseFloat(item.unitPrice),
      subtotal: parseFloat(item.subtotal),
    })),
    subtotal: parseFloat(order.subtotal || order.totalAmount),
    buyerFee: parseFloat(order.buyerFee || "0"),
    totalAmount: parseFloat(order.totalAmount),
    commissionAmount: parseFloat(order.commissionAmount),
    vendorAmount: parseFloat(order.vendorAmount),
    status: order.status,
    paymentMethod: order.paymentMethod,
    mpesaPhone: order.mpesaPhone,
    createdAt: order.createdAt.toISOString(),
  };
}

async function processItems(itemsData: { product: any; quantity: number; subtotal: number }[], orderId: number) {
  for (const { product, quantity, subtotal } of itemsData) {
    await db.insert(orderItemsTable).values({
      orderId,
      productId: product.id,
      productName: product.name,
      quantity,
      unitPrice: product.price,
      subtotal: String(subtotal),
    });

    const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.id, product.vendorId)).limit(1);
    if (vendor) {
      const itemCommission = subtotal * VENDOR_COMMISSION_RATE;
      await db.insert(commissionsTable).values({
        orderId,
        vendorId: vendor.id,
        orderAmount: String(subtotal),
        commissionRate: String(VENDOR_COMMISSION_RATE * 100),
        commissionAmount: String(itemCommission),
        status: "pending",
      });
    }
  }
}

router.get("/", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const orders = await db.select().from(ordersTable)
    .where(eq(ordersTable.customerId, user.id))
    .orderBy(sql`${ordersTable.createdAt} DESC`);
  const formatted = await Promise.all(orders.map(formatOrder));
  res.json(formatted);
});

router.get("/:id", optionalAuth, async (req, res) => {
  const user = (req as any).user;
  const id = parseInt(String(req.params.id));
  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, id)).limit(1);
  if (!order) { res.status(404).json({ message: "Order not found" }); return; }
  if (user?.role !== "admin" && order.customerId !== user?.id) {
    res.status(403).json({ message: "Access denied" }); return;
  }
  res.json(await formatOrder(order));
});

router.post("/guest", async (req, res) => {
  const parsed = CreateGuestOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input", errors: parsed.error.errors });
    return;
  }

  const { guestName, guestEmail, hostelName, roomNumber, contactPhone, paymentMethod, mpesaPhone, items } = parsed.data;

  let productSubtotal = 0;
  const itemsData = [];

  for (const { productId, quantity } of items) {
    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, productId)).limit(1);
    if (!product) continue;
    const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.id, product.vendorId)).limit(1);
    if (!vendor || !vendor.isApproved) continue;
    const subtotal = parseFloat(product.price) * quantity;
    productSubtotal += subtotal;
    itemsData.push({ product, quantity, subtotal });
  }

  if (itemsData.length === 0) {
    res.status(400).json({ message: "No valid products in order" });
    return;
  }

  // Buyer pays 10% service fee on top
  const buyerFee = productSubtotal * BUYER_FEE_RATE;
  const totalAmount = productSubtotal + buyerFee;
  // Vendor is charged 7% from their product revenue
  const commissionAmount = productSubtotal * VENDOR_COMMISSION_RATE;
  const vendorAmount = productSubtotal - commissionAmount;

  const [order] = await db.insert(ordersTable).values({
    guestName,
    guestEmail,
    hostelName,
    roomNumber,
    contactPhone,
    subtotal: String(productSubtotal),
    buyerFee: String(buyerFee),
    totalAmount: String(totalAmount),
    commissionAmount: String(commissionAmount),
    vendorAmount: String(vendorAmount),
    status: "pending",
    paymentMethod,
    mpesaPhone: mpesaPhone || null,
  }).returning();

  await processItems(itemsData, order.id);
  res.status(201).json(await formatOrder(order));
});

router.post("/", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }

  const cartItems = await db.select().from(cartItemsTable).where(eq(cartItemsTable.userId, user.id));
  if (cartItems.length === 0) {
    res.status(400).json({ message: "Cart is empty" });
    return;
  }

  let productSubtotal = 0;
  const itemsData = [];

  for (const cartItem of cartItems) {
    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, cartItem.productId)).limit(1);
    if (!product) continue;
    const subtotal = parseFloat(product.price) * cartItem.quantity;
    productSubtotal += subtotal;
    itemsData.push({ product, quantity: cartItem.quantity, subtotal });
  }

  // Buyer pays 10% service fee on top
  const buyerFee = productSubtotal * BUYER_FEE_RATE;
  const totalAmount = productSubtotal + buyerFee;
  // Vendor is charged 7% from their product revenue
  const commissionAmount = productSubtotal * VENDOR_COMMISSION_RATE;
  const vendorAmount = productSubtotal - commissionAmount;

  const [order] = await db.insert(ordersTable).values({
    customerId: user.id,
    hostelName: parsed.data.hostelName,
    roomNumber: parsed.data.roomNumber,
    contactPhone: parsed.data.contactPhone,
    subtotal: String(productSubtotal),
    buyerFee: String(buyerFee),
    totalAmount: String(totalAmount),
    commissionAmount: String(commissionAmount),
    vendorAmount: String(vendorAmount),
    status: "pending",
    paymentMethod: parsed.data.paymentMethod,
    mpesaPhone: parsed.data.mpesaPhone || null,
  }).returning();

  await processItems(itemsData, order.id);
  await db.delete(cartItemsTable).where(eq(cartItemsTable.userId, user.id));
  res.status(201).json(await formatOrder(order));
});

export default router;
