import { ReactNode } from "react";
import { Navbar } from "./Navbar";
import { Link } from "wouter";

export function AppLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-[100dvh] flex flex-col bg-gray-50">
      <Navbar />
      <main className="flex-1">
        {children}
      </main>
      <footer className="bg-primary text-white py-12 mt-12">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8 text-sm">
          <div>
            <h3 className="font-bold text-lg mb-4">Get to Know Us</h3>
            <ul className="space-y-2 text-gray-300">
              <li><Link href="/about" className="hover:underline">About VISTA</Link></li>
              <li><Link href="/careers" className="hover:underline">Careers</Link></li>
              <li><Link href="/press" className="hover:underline">Press Releases</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-lg mb-4">Make Money with Us</h3>
            <ul className="space-y-2 text-gray-300">
              <li><Link href="/vendor/register" className="hover:underline">Sell on VISTA</Link></li>
              <li><Link href="/affiliates" className="hover:underline">Become an Affiliate</Link></li>
              <li><Link href="/advertise" className="hover:underline">Advertise Your Products</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-lg mb-4">VISTA Payment Products</h3>
            <ul className="space-y-2 text-gray-300">
              <li><Link href="/rewards" className="hover:underline">VISTA Rewards Visa Signature Cards</Link></li>
              <li><Link href="/store-card" className="hover:underline">VISTA Store Card</Link></li>
              <li><Link href="/reload" className="hover:underline">VISTA Secured Card</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-lg mb-4">Let Us Help You</h3>
            <ul className="space-y-2 text-gray-300">
              <li><Link href="/account" className="hover:underline">Your Account</Link></li>
              <li><Link href="/orders" className="hover:underline">Your Orders</Link></li>
              <li><Link href="/shipping" className="hover:underline">Shipping Rates & Policies</Link></li>
              <li><Link href="/returns" className="hover:underline">Returns & Replacements</Link></li>
              <li><Link href="/help" className="hover:underline">Help</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-white/20 text-center text-gray-400 text-xs">
          <p>&copy; {new Date().getFullYear()} VISTA Rongo Uni Marketplace. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}