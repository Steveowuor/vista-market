import { useGetAdminStats, useListAllOrders, getGetAdminStatsQueryOptions, getListAllOrdersQueryOptions } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, DollarSign, Users, Store, ShoppingBag, TrendingUp, Package, BarChart2, UserCheck, Bell } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell, PieChart, Pie, Legend,
} from "recharts";

const STATUS_COLORS: Record<string, string> = {
  pending: "#febd69",
  processing: "#3b82f6",
  shipped: "#8b5cf6",
  delivered: "#22c55e",
  cancelled: "#ef4444",
};

const VENDOR_COLORS = ["#232f3e", "#febd69", "#3b82f6", "#22c55e", "#8b5cf6"];

export default function AdminDashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: stats, isLoading: isStatsLoading } = useGetAdminStats({
    query: { ...getGetAdminStatsQueryOptions(), enabled: !!user && user.role === "admin" },
  });

  const { data: recentOrders, isLoading: isOrdersLoading } = useListAllOrders({
    query: { ...getListAllOrdersQueryOptions(), enabled: !!user && user.role === "admin" },
  });

  if (!user || user.role !== "admin") { setLocation("/"); return null; }
  if (isStatsLoading || isOrdersLoading) {
    return <div className="container mx-auto px-4 py-12 text-center text-gray-500">Loading admin dashboard...</div>;
  }

  const orderStatusData = Object.entries((stats as any)?.ordersByStatus || {}).map(([name, value]) => ({
    name: name.charAt(0).toUpperCase() + name.slice(1),
    value: value as number,
    fill: STATUS_COLORS[name] || "#94a3b8",
  }));

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <Shield className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Platform Administration</h1>
            <p className="text-sm text-gray-500">VISTA Rongo University Marketplace</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Link href="/admin/reports">
            <button className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary/90">
              <BarChart2 className="h-4 w-4" /> Analytics
            </button>
          </Link>
          <Link href="/admin/customers">
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50">
              <UserCheck className="h-4 w-4" /> Customers
            </button>
          </Link>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card className="bg-primary text-white border-none col-span-2 md:col-span-1">
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-white/70 text-xs font-medium mb-1">Total Revenue</p>
                <h3 className="text-2xl font-bold">KSh {stats?.totalRevenue.toLocaleString()}</h3>
                <p className="text-xs text-white/60 mt-1">All-time gross</p>
              </div>
              <div className="bg-white/10 p-2 rounded-full"><DollarSign className="h-5 w-5 text-secondary" /></div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-secondary text-primary border-none">
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-primary/70 text-xs font-medium mb-1">VISTA Earnings</p>
                <h3 className="text-2xl font-bold">KSh {stats?.totalCommissions.toLocaleString()}</h3>
                <p className="text-xs text-primary/60 mt-1">7% commissions</p>
              </div>
              <div className="bg-primary/10 p-2 rounded-full"><TrendingUp className="h-5 w-5 text-primary" /></div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-xs font-medium mb-1">Total Orders</p>
                <h3 className="text-2xl font-bold text-gray-900">{stats?.totalOrders}</h3>
                <p className="text-xs text-orange-500 mt-1">{stats?.pendingOrders} pending</p>
              </div>
              <ShoppingBag className="h-5 w-5 text-gray-300" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-xs font-medium mb-1">Vendors</p>
                <h3 className="text-2xl font-bold text-gray-900">{stats?.totalVendors}</h3>
                {stats?.pendingVendors ? (
                  <p className="text-xs text-orange-500 mt-1">{stats.pendingVendors} awaiting approval</p>
                ) : <p className="text-xs text-green-600 mt-1">All approved</p>}
              </div>
              <Store className="h-5 w-5 text-gray-300" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-xs font-medium mb-1">Customers</p>
                <h3 className="text-2xl font-bold text-gray-900">{stats?.totalUsers}</h3>
                <p className="text-xs text-gray-400 mt-1">Registered users</p>
              </div>
              <Users className="h-5 w-5 text-gray-300" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-xs font-medium mb-1">Products</p>
                <h3 className="text-2xl font-bold text-gray-900">{stats?.totalProducts}</h3>
                <p className="text-xs text-gray-400 mt-1">Listed on platform</p>
              </div>
              <Package className="h-5 w-5 text-gray-300" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-xs font-medium mb-1">Buyer Fees</p>
                <h3 className="text-2xl font-bold text-gray-900">KSh {stats?.totalBuyerFees.toLocaleString()}</h3>
                <p className="text-xs text-gray-400 mt-1">10% service fees</p>
              </div>
              <TrendingUp className="h-5 w-5 text-gray-300" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-green-50 border-green-100">
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-green-700 text-xs font-medium mb-1">Platform Income</p>
                <h3 className="text-2xl font-bold text-green-800">
                  KSh {((stats?.totalCommissions || 0) + (stats?.totalBuyerFees || 0)).toLocaleString()}
                </h3>
                <p className="text-xs text-green-600 mt-1">Commissions + fees</p>
              </div>
              <TrendingUp className="h-5 w-5 text-green-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-3 gap-6 mb-8">
        {/* Revenue Trend */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-bold text-gray-900">Revenue Trend</h2>
            <span className="text-xs text-gray-400 bg-gray-100 px-2 py-1 rounded">Last 6 months</span>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={stats?.revenueByMonth || []} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#6b7280" }} />
              <YAxis tick={{ fontSize: 11, fill: "#6b7280" }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
              <Tooltip
                formatter={(value: number, name: string) => [`KSh ${value.toLocaleString()}`, name === "revenue" ? "Revenue" : "Commission"]}
                contentStyle={{ borderRadius: "8px", border: "1px solid #e5e7eb", fontSize: 12 }}
              />
              <Legend iconSize={10} iconType="circle" wrapperStyle={{ fontSize: 12 }} />
              <Line type="monotone" dataKey="revenue" stroke="#232f3e" strokeWidth={2.5} dot={{ r: 3 }} name="revenue" />
              <Line type="monotone" dataKey="commissions" stroke="#febd69" strokeWidth={2.5} dot={{ r: 3 }} name="commissions" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Order Status Pie */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-6">Orders by Status</h2>
          {orderStatusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={orderStatusData} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={3} dataKey="value">
                  {orderStatusData.map((entry, idx) => (
                    <Cell key={idx} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip formatter={(v: number) => [v, "Orders"]} contentStyle={{ borderRadius: "8px", fontSize: 12 }} />
                <Legend iconSize={10} iconType="circle" wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[220px] flex items-center justify-center text-gray-400 text-sm">No orders yet</div>
          )}
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Top Vendors Bar */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-bold text-gray-900">Top Vendors by Sales</h2>
            <Link href="/admin/vendors" className="text-xs text-blue-600 hover:underline">Manage all</Link>
          </div>
          {stats?.topVendors && stats.topVendors.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={stats.topVendors} margin={{ top: 0, right: 10, left: 0, bottom: 0 }} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 10, fill: "#6b7280" }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                <YAxis type="category" dataKey="vendorName" tick={{ fontSize: 11, fill: "#374151" }} width={110} />
                <Tooltip
                  formatter={(v: number) => [`KSh ${v.toLocaleString()}`, "Sales"]}
                  contentStyle={{ borderRadius: "8px", border: "1px solid #e5e7eb", fontSize: 12 }}
                />
                <Bar dataKey="sales" radius={[0, 4, 4, 0]}>
                  {stats.topVendors.map((_, idx) => (
                    <Cell key={idx} fill={VENDOR_COLORS[idx % VENDOR_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[200px] flex items-center justify-center text-gray-400 text-sm">No sales data yet</div>
          )}
        </div>

        {/* Right Panel */}
        <div className="space-y-4">
          {/* Quick Nav */}
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h2 className="text-sm font-bold text-gray-700 mb-3 uppercase tracking-wide">Quick Access</h2>
            <div className="space-y-1">
              {[
                { label: "Vendor Approvals", href: "/admin/vendors", badge: stats?.pendingVendors || 0 },
                { label: "All Orders", href: "/admin/orders", badge: stats?.pendingOrders || 0 },
                { label: "Customer Management", href: "/admin/customers", badge: 0 },
                { label: "Commission Reports", href: "/admin/commissions", badge: 0 },
                { label: "Analytics & Reports", href: "/admin/reports", badge: 0 },
              ].map(({ label, href, badge }) => (
                <Link key={href} href={href} className="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-gray-50 text-sm text-gray-700 transition-colors">
                  <span>{label}</span>
                  {badge > 0 && <Badge className="bg-orange-100 text-orange-700 border-orange-200 text-xs">{badge}</Badge>}
                </Link>
              ))}
            </div>
          </div>

          {/* Recent Orders */}
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div className="p-4 border-b border-gray-100 flex justify-between items-center">
              <h2 className="text-sm font-bold text-gray-700 uppercase tracking-wide">Recent Orders</h2>
              <Link href="/admin/orders" className="text-xs text-blue-600 hover:underline">View all</Link>
            </div>
            <div className="divide-y divide-gray-50">
              {recentOrders?.slice(0, 5).map((order) => (
                <div key={order.id} className="px-4 py-3 flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium text-gray-900">#{order.id}</p>
                    <p className="text-xs text-gray-400">{format(new Date(order.createdAt), "MMM d, HH:mm")}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-gray-900">KSh {order.totalAmount.toLocaleString()}</p>
                    <Badge variant="outline" className="text-xs">{order.status}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
