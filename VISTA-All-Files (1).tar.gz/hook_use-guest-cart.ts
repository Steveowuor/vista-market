import { useState, useCallback } from "react";

export interface GuestCartItem {
  productId: number;
  name: string;
  price: number;
  imageUrl?: string;
  vendorName?: string;
  quantity: number;
}

const STORAGE_KEY = "vista_guest_cart";

function readCart(): GuestCartItem[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
}

function writeCart(items: GuestCartItem[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}

export function useGuestCart() {
  const [items, setItems] = useState<GuestCartItem[]>(readCart);

  const addItem = useCallback((item: Omit<GuestCartItem, "quantity"> & { quantity?: number }) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.productId === item.productId);
      let updated: GuestCartItem[];
      if (existing) {
        updated = prev.map((i) =>
          i.productId === item.productId
            ? { ...i, quantity: i.quantity + (item.quantity ?? 1) }
            : i
        );
      } else {
        updated = [...prev, { ...item, quantity: item.quantity ?? 1 }];
      }
      writeCart(updated);
      return updated;
    });
  }, []);

  const updateQuantity = useCallback((productId: number, quantity: number) => {
    setItems((prev) => {
      const updated = quantity <= 0
        ? prev.filter((i) => i.productId !== productId)
        : prev.map((i) => i.productId === productId ? { ...i, quantity } : i);
      writeCart(updated);
      return updated;
    });
  }, []);

  const removeItem = useCallback((productId: number) => {
    setItems((prev) => {
      const updated = prev.filter((i) => i.productId !== productId);
      writeCart(updated);
      return updated;
    });
  }, []);

  const clearCart = useCallback(() => {
    setItems([]);
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  const totalItems = items.reduce((s, i) => s + i.quantity, 0);
  const subtotal = items.reduce((s, i) => s + i.price * i.quantity, 0);

  return { items, addItem, updateQuantity, removeItem, clearCart, totalItems, subtotal };
}
