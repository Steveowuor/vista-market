import { Link } from "wouter";
import { Share2, DollarSign, TrendingUp, CheckCircle, ChevronRight } from "lucide-react";

const STEPS = [
  { step: "1", title: "Sign Up Free", desc: "Create your VISTA account and apply for the affiliate programme — approval takes less than 24 hours." },
  { step: "2", title: "Get Your Link", desc: "Receive a unique referral link you can share via WhatsApp, Instagram, TikTok, or any channel." },
  { step: "3", title: "Earn Commission", desc: "Earn 5% on every completed order placed through your link. No cap on earnings." },
];

export default function AffiliatesPage() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <h1 className="text-4xl font-bold mb-4">Become a VISTA Affiliate</h1>
          <p className="text-xl text-gray-300">
            Share VISTA with your network. Earn 5% commission on every sale you refer. Zero upfront cost.
          </p>
          <div className="mt-8">
            <Link href="/register">
              <button className="bg-secondary text-primary font-bold px-8 py-3 rounded-lg hover:bg-[#f3a847] transition-colors text-lg">
                Apply Now — It's Free
              </button>
            </Link>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-6 mb-16">
          {[
            { icon: DollarSign, label: "Commission Rate", value: "5%", color: "text-green-600 bg-green-50" },
            { icon: Share2, label: "Payment Cycle", value: "Monthly", color: "text-blue-600 bg-blue-50" },
            { icon: TrendingUp, label: "Avg. Monthly Earn", value: "KSh 3,200", color: "text-orange-600 bg-orange-50" },
          ].map(({ icon: Icon, label, value, color }) => (
            <div key={label} className="bg-white border border-gray-200 rounded-xl p-6 text-center hover:shadow-md transition-shadow">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 ${color}`}>
                <Icon className="h-6 w-6" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{value}</p>
              <p className="text-sm text-gray-500 mt-1">{label}</p>
            </div>
          ))}
        </div>

        {/* How it works */}
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-10">How It Works</h2>
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {STEPS.map((s) => (
            <div key={s.step} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow text-center">
              <div className="w-12 h-12 rounded-full bg-primary text-white font-bold text-xl flex items-center justify-center mx-auto mb-4">{s.step}</div>
              <h3 className="font-bold text-gray-900 mb-2">{s.title}</h3>
              <p className="text-sm text-gray-600 leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>

        {/* Benefits */}
        <div className="bg-gray-50 rounded-2xl p-8 mb-10">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Affiliate Benefits</h2>
          <div className="grid md:grid-cols-2 gap-3">
            {[
              "5% commission on every completed order",
              "Real-time dashboard to track clicks and earnings",
              "Monthly M-PESA payout — no minimum threshold",
              "Exclusive affiliate-only promotions and bonuses",
              "Dedicated affiliate support via WhatsApp",
              "Special badges and recognition for top affiliates",
            ].map((b) => (
              <div key={b} className="flex items-start gap-2">
                <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                <span className="text-sm text-gray-700">{b}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center">
          <Link href="/register">
            <button className="inline-flex items-center gap-2 bg-primary text-white font-bold px-8 py-3 rounded-lg hover:bg-primary/90 transition-colors text-lg">
              Start Earning Today <ChevronRight className="h-5 w-5" />
            </button>
          </Link>
          <p className="text-sm text-gray-500 mt-3">Questions? Email <a href="mailto:affiliates@vista.ac.ke" className="text-primary underline">affiliates@vista.ac.ke</a></p>
        </div>
      </div>
    </div>
  );
}
