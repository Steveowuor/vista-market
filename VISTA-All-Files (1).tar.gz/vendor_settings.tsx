import { useState } from "react";
import { useGetVendorPayment, useUpdateVendorPayment, getGetVendorPaymentQueryOptions } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Smartphone, Building2, Hash, CreditCard, CheckCircle, AlertCircle, ArrowLeft, Info } from "lucide-react";

const PAYMENT_TYPES = [
  {
    id: "mpesa",
    label: "M-PESA",
    icon: Smartphone,
    color: "text-green-600 bg-green-50 border-green-200",
    description: "Receive payments directly to your M-PESA number",
  },
  {
    id: "bank",
    label: "Bank Account",
    icon: Building2,
    color: "text-blue-600 bg-blue-50 border-blue-200",
    description: "Receive payouts to your bank account",
  },
  {
    id: "paybill",
    label: "Paybill",
    icon: Hash,
    color: "text-purple-600 bg-purple-50 border-purple-200",
    description: "Receive via M-PESA Paybill number",
  },
  {
    id: "till",
    label: "Till Number",
    icon: CreditCard,
    color: "text-orange-600 bg-orange-50 border-orange-200",
    description: "Receive via M-PESA Buy Goods till number",
  },
];

export default function VendorSettingsPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: payment, isLoading, refetch } = useGetVendorPayment({
    query: { ...getGetVendorPaymentQueryOptions(), enabled: !!user && user.role === "vendor" },
  });

  const updateMutation = useUpdateVendorPayment({
    mutation: {
      onSuccess: () => {
        refetch();
        toast({ title: "Payment details saved!", description: "Your payout information has been updated." });
      },
      onError: (err: any) => {
        toast({ title: "Save failed", description: err?.response?.data?.message || "Please try again.", variant: "destructive" });
      },
    },
  });

  const [selectedType, setSelectedType] = useState<string>("");
  const [form, setForm] = useState({
    mpesaNumber: "",
    bankName: "",
    bankAccount: "",
    bankBranch: "",
    paybillNumber: "",
    paybillBusinessName: "",
    tillNumber: "",
  });

  const currentType = selectedType || payment?.paymentType || "";

  if (!user || user.role !== "vendor") {
    setLocation("/login");
    return null;
  }

  if (isLoading) {
    return <div className="container mx-auto px-4 py-12 text-center">Loading settings...</div>;
  }

  const handleTypeSelect = (type: string) => {
    setSelectedType(type);
    setForm({
      mpesaNumber: payment?.mpesaNumber || "",
      bankName: payment?.bankName || "",
      bankAccount: payment?.bankAccount || "",
      bankBranch: payment?.bankBranch || "",
      paybillNumber: payment?.paybillNumber || "",
      paybillBusinessName: payment?.paybillBusinessName || "",
      tillNumber: payment?.tillNumber || "",
    });
  };

  const handleSave = () => {
    if (!currentType) {
      toast({ title: "Select a payment type", description: "Choose how you want to receive payouts.", variant: "destructive" });
      return;
    }
    updateMutation.mutate({
      data: {
        paymentType: currentType as any,
        ...form,
      },
    });
  };

  const hasPaymentSetup = !!payment?.paymentType;

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <Button variant="ghost" className="mb-6 gap-2" onClick={() => setLocation("/vendor/dashboard")}>
        <ArrowLeft className="h-4 w-4" /> Back to Dashboard
      </Button>

      <div className="flex items-center gap-3 mb-2">
        <h1 className="text-3xl font-bold text-gray-900">Payout Settings</h1>
        {hasPaymentSetup ? (
          <Badge className="bg-green-100 text-green-800 border-green-200">
            <CheckCircle className="h-3 w-3 mr-1" /> Configured
          </Badge>
        ) : (
          <Badge className="bg-orange-100 text-orange-800 border-orange-200">
            <AlertCircle className="h-3 w-3 mr-1" /> Not Set
          </Badge>
        )}
      </div>
      <p className="text-gray-500 mb-8">
        Configure where VISTA sends your earnings. You receive <strong>93%</strong> of every sale (after 7% platform fee).
      </p>

      {/* Fee breakdown */}
      <Card className="mb-8 bg-primary/5 border-primary/20">
        <CardContent className="p-5">
          <div className="flex items-start gap-3">
            <Info className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-semibold text-primary mb-1">How your earnings work</p>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div className="text-center p-2 bg-white rounded-lg border">
                  <p className="text-xs text-gray-500">Sale Price</p>
                  <p className="font-bold text-gray-900">100%</p>
                </div>
                <div className="text-center p-2 bg-red-50 rounded-lg border border-red-100">
                  <p className="text-xs text-red-600">Platform Fee</p>
                  <p className="font-bold text-red-600">− 7%</p>
                </div>
                <div className="text-center p-2 bg-green-50 rounded-lg border border-green-200">
                  <p className="text-xs text-green-700">You Receive</p>
                  <p className="font-bold text-green-700">93%</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 mt-2">
                Payouts are processed after orders are marked as delivered.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Current setup */}
      {hasPaymentSetup && !selectedType && (
        <Card className="mb-6 border-green-200 bg-green-50/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-base text-green-800 flex items-center gap-2">
              <CheckCircle className="h-4 w-4" /> Current Payout Method
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4 text-sm">
              <div><span className="text-gray-500">Type:</span> <span className="font-semibold capitalize">{payment.paymentType}</span></div>
              {payment.mpesaNumber && <div><span className="text-gray-500">M-PESA:</span> <span className="font-semibold">{payment.mpesaNumber}</span></div>}
              {payment.bankName && <div><span className="text-gray-500">Bank:</span> <span className="font-semibold">{payment.bankName}</span></div>}
              {payment.bankAccount && <div><span className="text-gray-500">Account:</span> <span className="font-semibold">{payment.bankAccount}</span></div>}
              {payment.paybillNumber && <div><span className="text-gray-500">Paybill:</span> <span className="font-semibold">{payment.paybillNumber}</span></div>}
              {payment.tillNumber && <div><span className="text-gray-500">Till:</span> <span className="font-semibold">{payment.tillNumber}</span></div>}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Payment type selection */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Choose Payout Method</CardTitle>
          <CardDescription>Select how you want to receive payments from VISTA</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {PAYMENT_TYPES.map((type) => {
              const Icon = type.icon;
              const isSelected = currentType === type.id;
              return (
                <button
                  key={type.id}
                  type="button"
                  onClick={() => handleTypeSelect(type.id)}
                  className={`flex items-start gap-3 p-4 rounded-xl border-2 text-left transition-all ${
                    isSelected
                      ? `border-2 ${type.color}`
                      : "border-gray-200 hover:border-gray-300 bg-white"
                  }`}
                >
                  <Icon className={`h-5 w-5 mt-0.5 flex-shrink-0 ${isSelected ? type.color.split(" ")[0] : "text-gray-400"}`} />
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">{type.label}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{type.description}</p>
                  </div>
                  {isSelected && <CheckCircle className={`h-4 w-4 ml-auto flex-shrink-0 ${type.color.split(" ")[0]}`} />}
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Payment details form */}
      {currentType && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="capitalize">{currentType === "mpesa" ? "M-PESA" : currentType === "bank" ? "Bank Account" : currentType === "paybill" ? "Paybill" : "Till Number"} Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {currentType === "mpesa" && (
              <div className="space-y-1">
                <Label>M-PESA Phone Number</Label>
                <Input
                  placeholder="e.g. 0712 345 678"
                  value={form.mpesaNumber}
                  onChange={(e) => setForm({ ...form, mpesaNumber: e.target.value })}
                />
                <p className="text-xs text-gray-500">Safaricom number registered to M-PESA</p>
              </div>
            )}

            {currentType === "bank" && (
              <>
                <div className="space-y-1">
                  <Label>Bank Name</Label>
                  <Input
                    placeholder="e.g. Equity Bank, KCB, Co-op Bank"
                    value={form.bankName}
                    onChange={(e) => setForm({ ...form, bankName: e.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <Label>Account Number</Label>
                  <Input
                    placeholder="Your bank account number"
                    value={form.bankAccount}
                    onChange={(e) => setForm({ ...form, bankAccount: e.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <Label>Branch <span className="text-gray-400 text-xs">(optional)</span></Label>
                  <Input
                    placeholder="e.g. Rongo Branch"
                    value={form.bankBranch}
                    onChange={(e) => setForm({ ...form, bankBranch: e.target.value })}
                  />
                </div>
              </>
            )}

            {currentType === "paybill" && (
              <>
                <div className="space-y-1">
                  <Label>Paybill Number</Label>
                  <Input
                    placeholder="e.g. 247247"
                    value={form.paybillNumber}
                    onChange={(e) => setForm({ ...form, paybillNumber: e.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <Label>Business Name / Account Name</Label>
                  <Input
                    placeholder="Your business/account name on paybill"
                    value={form.paybillBusinessName}
                    onChange={(e) => setForm({ ...form, paybillBusinessName: e.target.value })}
                  />
                </div>
              </>
            )}

            {currentType === "till" && (
              <div className="space-y-1">
                <Label>Till Number</Label>
                <Input
                  placeholder="e.g. 123456"
                  value={form.tillNumber}
                  onChange={(e) => setForm({ ...form, tillNumber: e.target.value })}
                />
                <p className="text-xs text-gray-500">M-PESA Buy Goods till number</p>
              </div>
            )}

            <Button
              onClick={handleSave}
              disabled={updateMutation.isPending}
              className="w-full bg-primary text-white hover:bg-primary/90"
            >
              {updateMutation.isPending ? "Saving..." : "Save Payout Details"}
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
