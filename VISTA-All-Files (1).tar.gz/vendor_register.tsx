import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useCreateVendor } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Store, Clock, CheckCircle } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

const vendorRegisterSchema = z.object({
  businessName: z.string().min(3, "Business name must be at least 3 characters"),
  description: z.string().optional(),
  contactEmail: z.string().email("Invalid email address"),
  contactPhone: z.string().optional(),
  address: z.string().optional(),
});

type VendorRegisterValues = z.infer<typeof vendorRegisterSchema>;

export default function VendorRegisterPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [registered, setRegistered] = useState(false);
  const [businessName, setBusinessName] = useState("");

  const createVendorMutation = useCreateVendor({
    mutation: {
      onSuccess: (vendor) => {
        queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
        setBusinessName(vendor.businessName);
        setRegistered(true);
      },
      onError: (err: any) => {
        toast({ title: "Registration Failed", description: err?.response?.data?.message || "Failed to register as vendor", variant: "destructive" });
      }
    }
  });

  const form = useForm<VendorRegisterValues>({
    resolver: zodResolver(vendorRegisterSchema),
    defaultValues: {
      businessName: "",
      description: "",
      contactEmail: user?.email || "",
      contactPhone: "",
      address: "",
    },
  });

  const onSubmit = async (data: VendorRegisterValues) => {
    if (!user) {
      toast({ title: "Please sign in first", description: "You must be logged in to register a business." });
      setLocation("/login");
      return;
    }
    createVendorMutation.mutate({ data });
  };

  if (registered) {
    return (
      <div className="container mx-auto px-4 py-16 max-w-lg text-center">
        <div className="bg-white border border-gray-200 rounded-2xl shadow-sm p-10">
          <div className="w-20 h-20 rounded-full bg-yellow-100 flex items-center justify-center mx-auto mb-6">
            <Clock className="w-10 h-10 text-yellow-500" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-3">Application Submitted!</h1>
          <p className="text-gray-600 mb-2 text-lg font-medium">{businessName}</p>
          <p className="text-gray-500 mb-8">
            Your vendor application has been received. The VISTA admin team will review it and approve your account — usually within <strong>1–2 business days</strong>.
          </p>

          <div className="bg-gray-50 rounded-xl p-5 text-left space-y-3 mb-8 border border-gray-100">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
              <span className="text-sm text-gray-700">Account created &amp; application submitted</span>
            </div>
            <div className="flex items-center gap-3">
              <Clock className="w-5 h-5 text-yellow-500 flex-shrink-0" />
              <span className="text-sm text-gray-700">Pending admin review and approval</span>
            </div>
            <div className="flex items-center gap-3">
              <Store className="w-5 h-5 text-gray-300 flex-shrink-0" />
              <span className="text-sm text-gray-400">Upload products (available after approval)</span>
            </div>
          </div>

          <Button
            className="w-full bg-secondary hover:bg-[#f3a847] text-primary font-bold"
            onClick={() => setLocation("/vendor/dashboard")}
          >
            Go to My Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-2xl">
      <div className="text-center mb-10">
        <Store className="h-16 w-16 mx-auto text-primary mb-4" />
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Sell on VISTA</h1>
        <p className="text-xl text-gray-600">Reach thousands of students across Rongo University.</p>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg shadow-sm p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 border-b pb-4">Business Information</h2>

        {!user ? (
          <div className="text-center py-6">
            <p className="mb-4 text-gray-600">You need a VISTA account to register as a seller.</p>
            <div className="flex justify-center gap-4">
              <Button onClick={() => setLocation("/login")}>Sign In</Button>
              <Button variant="outline" onClick={() => setLocation("/register")}>Create Account</Button>
            </div>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="businessName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-bold text-gray-900">Business / Store Name *</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Rongo Electronics Hub" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-bold text-gray-900">Business Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="What do you sell?" className="min-h-[100px]" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="contactEmail"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-bold text-gray-900">Contact Email *</FormLabel>
                      <FormControl>
                        <Input type="email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="contactPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-bold text-gray-900">Phone Number</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 0712345678" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-bold text-gray-900">Location / Address</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Main Campus, Block C" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="bg-gray-50 p-4 rounded border border-gray-200 text-sm text-gray-700 mt-8">
                <h3 className="font-bold mb-2">VISTA Seller Agreement</h3>
                <p>By registering, you agree to VISTA's standard 5% commission rate on all successful sales. You are responsible for fulfilling your own orders within the campus premises.</p>
              </div>

              <Button 
                type="submit" 
                className="w-full bg-secondary hover:bg-[#f3a847] text-primary font-bold text-lg py-6 mt-4"
                disabled={createVendorMutation.isPending}
              >
                {createVendorMutation.isPending ? "Registering..." : "Register and Start Selling"}
              </Button>
            </form>
          </Form>
        )}
      </div>
    </div>
  );
}