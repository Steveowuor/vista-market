import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useLocation, Link } from "wouter";
import { ArrowLeft, Search, Users, ShoppingBag, TrendingUp, Mail } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

interface Customer {
  id: number;
  name: string;
  email: string;
  orderCount: number;
  totalSpent: number;
  lastOrderAt: string | null;
  createdAt: string;
}

export default function AdminCustomersPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState<"totalSpent" | "orderCount" | "createdAt">("totalSpent");

  const { data: customers, isLoading } = useQuery<Customer[]>({
    queryKey: ["admin-customers"],
    queryFn: async () => {
      const res = await fetch("/api/admin/customers");
      if (!res.ok) throw new Error("Failed to fetch customers");
      return res.json();
    },
    enabled: !!user && user.role === "admin",
  });

  if (!user || user.role !== "admin") { setLocation("/"); return null; }

  const filtered = (customers || [])
    .filter((c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.email.toLowerCase().includes(search.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === "createdAt") return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      return b[sortBy] - a[sortBy];
    });

  const totalRevenue = (customers || []).reduce((sum, c) => sum + c.totalSpent, 0);
  const activeCustomers = (customers || []).filter((c) => c.orderCount > 0).length;

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Link href="/admin/dashboard">
          <button className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50">
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Customer Management</h1>
          <p className="text-sm text-gray-500">All registered buyers on VISTA</p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <div className="flex items-center gap-3">
            <div className="bg-primary/10 p-2 rounded-lg"><Users className="h-5 w-5 text-primary" /></div>
            <div>
              <p className="text-xs text-gray-500">Total Customers</p>
              <p className="text-2xl font-bold text-gray-900">{customers?.length || 0}</p>
            </div>
          </div>
        </div>
        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <div className="flex items-center gap-3">
            <div className="bg-green-100 p-2 rounded-lg"><ShoppingBag className="h-5 w-5 text-green-600" /></div>
            <div>
              <p className="text-xs text-gray-500">Active Buyers</p>
              <p className="text-2xl font-bold text-gray-900">{activeCustomers}</p>
            </div>
          </div>
        </div>
        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <div className="flex items-center gap-3">
            <div className="bg-secondary/20 p-2 rounded-lg"><TrendingUp className="h-5 w-5 text-primary" /></div>
            <div>
              <p className="text-xs text-gray-500">Total Customer Spend</p>
              <p className="text-2xl font-bold text-gray-900">KSh {totalRevenue.toLocaleString()}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search by name or email..."
            className="pl-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <select
          className="px-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-700 bg-white focus:outline-none focus:ring-2 focus:ring-primary/20"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
        >
          <option value="totalSpent">Sort by Highest Spend</option>
          <option value="orderCount">Sort by Most Orders</option>
          <option value="createdAt">Sort by Newest</option>
        </select>
      </div>

      {/* Table */}
      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-16 bg-gray-100 rounded-xl animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20 bg-white border border-gray-200 rounded-xl">
          <Users className="h-12 w-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No customers found</p>
        </div>
      ) : (
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="px-6 py-4 text-left font-semibold text-gray-600">Customer</th>
                <th className="px-6 py-4 text-left font-semibold text-gray-600">Joined</th>
                <th className="px-6 py-4 text-center font-semibold text-gray-600">Orders</th>
                <th className="px-6 py-4 text-right font-semibold text-gray-600">Total Spent</th>
                <th className="px-6 py-4 text-left font-semibold text-gray-600">Last Order</th>
                <th className="px-6 py-4 text-center font-semibold text-gray-600">Segment</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.map((customer) => {
                const segment =
                  customer.totalSpent >= 10000 ? { label: "VIP", className: "bg-yellow-100 text-yellow-800 border-yellow-200" } :
                  customer.totalSpent >= 3000 ? { label: "Regular", className: "bg-blue-100 text-blue-800 border-blue-200" } :
                  customer.orderCount > 0 ? { label: "Active", className: "bg-green-100 text-green-800 border-green-200" } :
                  { label: "New", className: "bg-gray-100 text-gray-600 border-gray-200" };
                return (
                  <tr key={customer.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm flex-shrink-0">
                          {customer.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-semibold text-gray-900">{customer.name}</p>
                          <p className="text-xs text-gray-400 flex items-center gap-1">
                            <Mail className="h-3 w-3" /> {customer.email}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-gray-500">{format(new Date(customer.createdAt), "MMM d, yyyy")}</td>
                    <td className="px-6 py-4 text-center">
                      <span className="font-semibold text-gray-900">{customer.orderCount}</span>
                    </td>
                    <td className="px-6 py-4 text-right font-bold text-gray-900">
                      KSh {customer.totalSpent.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-gray-500 text-xs">
                      {customer.lastOrderAt ? format(new Date(customer.lastOrderAt), "MMM d, yyyy") : "No orders"}
                    </td>
                    <td className="px-6 py-4 text-center">
                      <Badge variant="outline" className={`text-xs ${segment.className}`}>{segment.label}</Badge>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <div className="px-6 py-3 border-t border-gray-100 bg-gray-50 text-xs text-gray-500">
            Showing {filtered.length} of {customers?.length} customers
          </div>
        </div>
      )}
    </div>
  );
}
