import { useListCommissions, getListCommissionsQueryOptions } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function AdminCommissionsPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: commissions, isLoading } = useListCommissions({
    query: {
      ...getListCommissionsQueryOptions(),
      enabled: !!user && user.role === "admin",
    }
  });

  if (!user || user.role !== "admin") {
    setLocation("/");
    return null;
  }

  const totalCommissions = commissions?.reduce((sum, c) => sum + c.commissionAmount, 0) || 0;

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Commission Ledger</h1>
          <p className="text-gray-500 mt-1">Track platform earnings from vendor sales</p>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 min-w-[200px] text-right">
          <div className="text-sm font-medium text-green-800">Total Earned</div>
          <div className="text-2xl font-bold text-green-700">KSh {totalCommissions.toLocaleString()}</div>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-gray-500">Loading ledger...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-gray-50 text-gray-600 font-medium border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4">Date</th>
                  <th className="px-6 py-4">Order ID</th>
                  <th className="px-6 py-4">Vendor</th>
                  <th className="px-6 py-4">Order Amount</th>
                  <th className="px-6 py-4 text-right">VISTA Commission</th>
                  <th className="px-6 py-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {commissions?.map(comm => (
                  <tr key={comm.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-gray-500">{format(new Date(comm.createdAt), "MMM d, yyyy")}</td>
                    <td className="px-6 py-4 font-medium">#{comm.orderId}</td>
                    <td className="px-6 py-4">
                      <div className="font-medium text-gray-900">{comm.vendorName}</div>
                      <div className="text-xs text-gray-500">Rate: {(comm.commissionRate * 100).toFixed(1)}%</div>
                    </td>
                    <td className="px-6 py-4">KSh {comm.orderAmount?.toLocaleString() || 0}</td>
                    <td className="px-6 py-4 text-right font-bold text-green-600">
                      KSh {comm.commissionAmount.toLocaleString()}
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant="outline" className={comm.status === 'paid' ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}>
                        {comm.status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}