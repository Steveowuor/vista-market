import { useGetAdminStats, getGetAdminStatsQueryOptions } from "@workspace/api-client-react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useLocation, Link } from "wouter";
import { ArrowLeft, TrendingUp, DollarSign, BarChart2, PieChart as PieIcon } from "lucide-react";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell, Legend, AreaChart, Area,
} from "recharts";
import { format } from "date-fns";

const STATUS_COLORS: Record<string, string> = {
  pending: "#febd69",
  processing: "#3b82f6",
  shipped: "#8b5cf6",
  delivered: "#22c55e",
  cancelled: "#ef4444",
};

interface Customer { id: number; name: string; totalSpent: number; orderCount: number; createdAt: string; }

export default function AdminReportsPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: stats, isLoading } = useGetAdminStats({
    query: { ...getGetAdminStatsQueryOptions(), enabled: !!user && user.role === "admin" },
  });

  const { data: customers } = useQuery<Customer[]>({
    queryKey: ["admin-customers"],
    queryFn: async () => {
      const res = await fetch("/api/admin/customers");
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!user && user.role === "admin",
  });

  if (!user || user.role !== "admin") { setLocation("/"); return null; }
  if (isLoading) {
    return <div className="container mx-auto px-4 py-12 text-center text-gray-500">Loading analytics...</div>;
  }

  const orderStatusData = Object.entries((stats as any)?.ordersByStatus || {}).map(([name, value]) => ({
    name: name.charAt(0).toUpperCase() + name.slice(1),
    value: value as number,
    fill: STATUS_COLORS[name] || "#94a3b8",
  }));

  const revenueData = stats?.revenueByMonth || [];

  const topCustomers = (customers || [])
    .filter((c) => c.orderCount > 0)
    .sort((a, b) => b.totalSpent - a.totalSpent)
    .slice(0, 8);

  const customerGrowth = (customers || [])
    .reduce((acc: Record<string, number>, c) => {
      const month = format(new Date(c.createdAt), "MMM yy");
      acc[month] = (acc[month] || 0) + 1;
      return acc;
    }, {});
  const customerGrowthData = Object.entries(customerGrowth).slice(-6).map(([month, count]) => ({ month, count }));

  const totalPlatformIncome = (stats?.totalCommissions || 0) + (stats?.totalBuyerFees || 0);

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Link href="/admin/dashboard">
          <button className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50">
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Analytics & Reports</h1>
          <p className="text-sm text-gray-500">Platform performance insights · VISTA Marketplace</p>
        </div>
      </div>

      {/* Income Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Gross Revenue", value: stats?.totalRevenue || 0, color: "text-gray-900", bg: "bg-white" },
          { label: "Vendor Commissions (7%)", value: stats?.totalCommissions || 0, color: "text-primary", bg: "bg-primary/5" },
          { label: "Buyer Service Fees (10%)", value: stats?.totalBuyerFees || 0, color: "text-blue-700", bg: "bg-blue-50" },
          { label: "Total Platform Income", value: totalPlatformIncome, color: "text-green-700", bg: "bg-green-50" },
        ].map(({ label, value, color, bg }) => (
          <div key={label} className={`${bg} border border-gray-200 rounded-xl p-5`}>
            <p className="text-xs text-gray-500 mb-1">{label}</p>
            <p className={`text-2xl font-bold ${color}`}>KSh {value.toLocaleString()}</p>
          </div>
        ))}
      </div>

      {/* Revenue & Commission Trend */}
      <div className="bg-white border border-gray-200 rounded-xl p-6 mb-6">
        <div className="flex items-center gap-2 mb-6">
          <TrendingUp className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-bold text-gray-900">Revenue & Commission Trend</h2>
          <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded ml-auto">Last 6 months</span>
        </div>
        <ResponsiveContainer width="100%" height={280}>
          <AreaChart data={revenueData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
            <defs>
              <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#232f3e" stopOpacity={0.15} />
                <stop offset="95%" stopColor="#232f3e" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="colorCommissions" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#febd69" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#febd69" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="month" tick={{ fontSize: 12, fill: "#6b7280" }} />
            <YAxis tick={{ fontSize: 12, fill: "#6b7280" }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
            <Tooltip
              formatter={(v: number, name: string) => [`KSh ${v.toLocaleString()}`, name === "revenue" ? "Revenue" : "Commission"]}
              contentStyle={{ borderRadius: "8px", border: "1px solid #e5e7eb", fontSize: 12 }}
            />
            <Legend iconType="circle" iconSize={10} wrapperStyle={{ fontSize: 12 }} />
            <Area type="monotone" dataKey="revenue" stroke="#232f3e" strokeWidth={2.5} fill="url(#colorRevenue)" name="revenue" dot={{ r: 3 }} />
            <Area type="monotone" dataKey="commissions" stroke="#febd69" strokeWidth={2.5} fill="url(#colorCommissions)" name="commissions" dot={{ r: 3 }} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Middle Row */}
      <div className="grid lg:grid-cols-2 gap-6 mb-6">
        {/* Orders by Status */}
        <div className="bg-white border border-gray-200 rounded-xl p-6">
          <div className="flex items-center gap-2 mb-6">
            <PieIcon className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-bold text-gray-900">Orders by Status</h2>
          </div>
          {orderStatusData.length > 0 ? (
            <div className="flex items-center gap-6">
              <ResponsiveContainer width="50%" height={200}>
                <PieChart>
                  <Pie data={orderStatusData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                    {orderStatusData.map((entry, idx) => <Cell key={idx} fill={entry.fill} />)}
                  </Pie>
                  <Tooltip formatter={(v: number) => [v, "Orders"]} contentStyle={{ borderRadius: "8px", fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex-1 space-y-2">
                {orderStatusData.map((s) => (
                  <div key={s.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ background: s.fill }} />
                      <span className="text-sm text-gray-600">{s.name}</span>
                    </div>
                    <span className="text-sm font-bold text-gray-900">{s.value}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="h-[200px] flex items-center justify-center text-gray-400 text-sm">No order data yet</div>
          )}
        </div>

        {/* Top Vendors */}
        <div className="bg-white border border-gray-200 rounded-xl p-6">
          <div className="flex items-center gap-2 mb-6">
            <BarChart2 className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-bold text-gray-900">Top Vendors</h2>
          </div>
          {stats?.topVendors && stats.topVendors.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={stats.topVendors} layout="vertical" margin={{ top: 0, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 10 }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                <YAxis type="category" dataKey="vendorName" tick={{ fontSize: 10 }} width={100} />
                <Tooltip formatter={(v: number) => [`KSh ${v.toLocaleString()}`, "Sales"]} contentStyle={{ borderRadius: "8px", fontSize: 12 }} />
                <Bar dataKey="sales" radius={[0, 4, 4, 0]}>
                  {stats.topVendors.map((_, idx) => (
                    <Cell key={idx} fill={idx === 0 ? "#232f3e" : idx === 1 ? "#febd69" : "#3b82f6"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[200px] flex items-center justify-center text-gray-400 text-sm">No vendor data yet</div>
          )}
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Customer Growth */}
        <div className="bg-white border border-gray-200 rounded-xl p-6">
          <div className="flex items-center gap-2 mb-6">
            <DollarSign className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-bold text-gray-900">Customer Registration</h2>
          </div>
          {customerGrowthData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={customerGrowthData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: "8px", fontSize: 12 }} />
                <Bar dataKey="count" fill="#232f3e" radius={[4, 4, 0, 0]} name="New Customers" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[200px] flex items-center justify-center text-gray-400 text-sm">No customer data yet</div>
          )}
        </div>

        {/* Top Customers */}
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <div className="p-5 border-b border-gray-100">
            <h2 className="text-lg font-bold text-gray-900">Top Customers by Spend</h2>
          </div>
          <div className="divide-y divide-gray-50">
            {topCustomers.length === 0 ? (
              <div className="p-8 text-center text-gray-400 text-sm">No customer data yet</div>
            ) : topCustomers.map((c, idx) => (
              <div key={c.id} className="px-5 py-3 flex items-center gap-4">
                <span className="text-lg font-bold text-gray-300 w-6 text-center">{idx + 1}</span>
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm flex-shrink-0">
                  {c.name.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-gray-900 truncate">{c.name}</p>
                  <p className="text-xs text-gray-400">{c.orderCount} order{c.orderCount !== 1 ? "s" : ""}</p>
                </div>
                <p className="text-sm font-bold text-gray-900">KSh {c.totalSpent.toLocaleString()}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
