import { Briefcase, MapPin, Clock, ChevronRight } from "lucide-react";

const JOBS = [
  { title: "Frontend Developer (React)", dept: "Engineering", type: "Full-time", location: "Rongo (Hybrid)", desc: "Build and maintain the VISTA marketplace UI using React, TypeScript, and TailwindCSS." },
  { title: "Vendor Relations Officer", dept: "Operations", type: "Full-time", location: "Rongo, On-site", desc: "Onboard new vendors, conduct verifications, and support vendor growth on the platform." },
  { title: "Customer Support Specialist", dept: "Support", type: "Part-time", location: "Remote", desc: "Assist buyers and vendors with orders, payments, and general platform queries." },
  { title: "Marketing & Social Media Intern", dept: "Marketing", type: "Internship", location: "Rongo (Hybrid)", desc: "Create content, manage social handles, and run campaigns to grow the VISTA brand on campus." },
  { title: "Database Administrator", dept: "Engineering", type: "Full-time", location: "Remote", desc: "Manage PostgreSQL databases, optimise queries, and ensure data reliability and security." },
  { title: "Campus Brand Ambassador", dept: "Marketing", type: "Part-time", location: "Rongo University", desc: "Represent VISTA on campus, drive sign-ups, and be the face of the brand among students." },
];

const TYPE_COLOR: Record<string, string> = {
  "Full-time": "bg-blue-100 text-blue-700",
  "Part-time": "bg-green-100 text-green-700",
  "Internship": "bg-orange-100 text-orange-700",
};

export default function CareersPage() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <h1 className="text-4xl font-bold mb-4">Work with VISTA</h1>
          <p className="text-xl text-gray-300">
            Help us build the future of campus commerce in Kenya. Join a passionate, student-first team.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        {/* Why Join */}
        <div className="grid md:grid-cols-3 gap-6 mb-14">
          {[
            { emoji: "🚀", title: "Impact from Day One", desc: "Small team, big mission — your work is seen immediately by thousands of students." },
            { emoji: "📚", title: "Learn & Grow", desc: "Access to courses, mentorship, and real-world engineering and business challenges." },
            { emoji: "🤝", title: "Community Culture", desc: "We're all part of the Rongo University community — we support each other like family." },
          ].map((b) => (
            <div key={b.title} className="bg-white border border-gray-200 rounded-xl p-6 text-center hover:shadow-md transition-shadow">
              <div className="text-4xl mb-3">{b.emoji}</div>
              <h3 className="font-bold text-gray-900 mb-2">{b.title}</h3>
              <p className="text-sm text-gray-600 leading-relaxed">{b.desc}</p>
            </div>
          ))}
        </div>

        {/* Open Roles */}
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Open Positions</h2>
        <div className="space-y-4">
          {JOBS.map((job) => (
            <div key={job.title} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md hover:border-primary/30 transition-all group cursor-pointer">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <h3 className="font-bold text-gray-900 text-lg">{job.title}</h3>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${TYPE_COLOR[job.type]}`}>{job.type}</span>
                  </div>
                  <div className="flex flex-wrap gap-4 text-sm text-gray-500 mb-2">
                    <span className="flex items-center gap-1"><Briefcase className="h-3.5 w-3.5" />{job.dept}</span>
                    <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{job.location}</span>
                  </div>
                  <p className="text-sm text-gray-600">{job.desc}</p>
                </div>
                <button className="flex items-center gap-1 text-sm font-semibold text-primary group-hover:text-secondary transition-colors flex-shrink-0">
                  Apply Now <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* No match */}
        <div className="mt-10 bg-gray-50 rounded-xl p-8 text-center">
          <Clock className="h-8 w-8 text-gray-400 mx-auto mb-3" />
          <h3 className="font-bold text-gray-900 mb-2">Don't see a fit?</h3>
          <p className="text-gray-600 text-sm mb-4">Send your CV and a short note about how you'd contribute to VISTA.</p>
          <a href="mailto:careers@vista.ac.ke" className="inline-block bg-primary text-white font-semibold px-6 py-2.5 rounded-lg hover:bg-primary/90 transition-colors">
            careers@vista.ac.ke
          </a>
        </div>
      </div>
    </div>
  );
}
