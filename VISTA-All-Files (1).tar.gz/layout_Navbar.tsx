import { Link, useLocation } from "wouter";
import { Search, ShoppingCart, Heart, LogOut, Store, Shield } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useGetCart, getGetCartQueryOptions } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { NotificationBell } from "./NotificationBell";

export function Navbar() {
  const { user, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [, setLocation] = useLocation();

  const { data: cartItems } = useGetCart({
    query: {
      ...getGetCartQueryOptions(),
      enabled: !!user && user.role === "buyer",
    }
  });

  const cartCount = cartItems?.reduce((acc, item) => acc + item.quantity, 0) || 0;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/products?search=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <header className="bg-primary text-primary-foreground sticky top-0 z-50 shadow-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 flex-shrink-0">
          <span className="text-2xl font-bold tracking-tight text-white">VISTA</span>
        </Link>

        {/* Search Bar - Amazon style */}
        <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-2xl">
          <div className="flex w-full overflow-hidden rounded-md focus-within:ring-2 focus-within:ring-secondary focus-within:ring-offset-2 focus-within:ring-offset-primary transition-all">
            <Input
              type="search"
              placeholder="Search Rongo Uni Marketplace..."
              className="w-full bg-white text-black border-none rounded-none rounded-l-md px-4 py-2 focus-visible:ring-0 focus-visible:ring-offset-0 h-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button type="submit" variant="secondary" className="rounded-none rounded-r-md h-10 px-6 bg-secondary hover:bg-[#f3a847] text-primary">
              <Search className="h-5 w-5" />
            </Button>
          </div>
        </form>

        {/* Right Nav Items */}
        <div className="flex items-center gap-1 md:gap-4 flex-shrink-0">
          {user ? (
            <>
              {/* Notification Bell */}
              <NotificationBell />

              {/* Account Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="text-white hover:bg-white/10 hover:text-white px-2 flex flex-col items-start h-auto py-1">
                    <span className="text-xs text-gray-300 font-normal leading-none">Hello, {user.name.split(' ')[0]}</span>
                    <span className="text-sm font-bold leading-none mt-1 flex items-center">
                      Account & Lists
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-2 py-1.5 text-sm font-medium">My Account</div>
                  <DropdownMenuSeparator />
                  {user.role === "buyer" && (
                    <>
                      <DropdownMenuItem onClick={() => setLocation("/orders")}>
                        Your Orders
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setLocation("/wishlist")}>
                        Your Wishlist
                      </DropdownMenuItem>
                    </>
                  )}
                  {user.role === "vendor" && (
                    <>
                      <DropdownMenuItem onClick={() => setLocation("/vendor/dashboard")}>
                        <Store className="mr-2 h-4 w-4" /> Vendor Dashboard
                      </DropdownMenuItem>
                    </>
                  )}
                  {user.role === "admin" && (
                    <>
                      <DropdownMenuItem onClick={() => setLocation("/admin/dashboard")}>
                        <Shield className="mr-2 h-4 w-4" /> Admin Dashboard
                      </DropdownMenuItem>
                    </>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => logout()} className="text-destructive focus:bg-destructive/10">
                    <LogOut className="mr-2 h-4 w-4" /> Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {user.role === "buyer" && (
                <>
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 hover:text-white relative" onClick={() => setLocation("/wishlist")}>
                    <Heart className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" className="text-white hover:bg-white/10 hover:text-white px-2 flex items-end gap-1 h-auto py-1" onClick={() => setLocation("/cart")}>
                    <div className="relative">
                      <ShoppingCart className="h-8 w-8" />
                      <span className="absolute -top-1 -right-1 bg-secondary text-primary text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                        {cartCount}
                      </span>
                    </div>
                    <span className="text-sm font-bold hidden md:inline-block pb-1">Cart</span>
                  </Button>
                </>
              )}
            </>
          ) : (
            <div className="flex items-center gap-2">
              <Button variant="ghost" className="text-white hover:bg-white/10 hover:text-white" onClick={() => setLocation("/login")}>
                Sign In
              </Button>
              <Button className="bg-secondary text-primary hover:bg-[#f3a847] hidden md:flex" onClick={() => setLocation("/register")}>
                Sign Up
              </Button>
            </div>
          )}
        </div>
      </div>
      
      {/* Mobile Search Bar */}
      <div className="md:hidden px-4 pb-3">
        <form onSubmit={handleSearch} className="flex w-full overflow-hidden rounded-md">
          <Input
            type="search"
            placeholder="Search Marketplace..."
            className="w-full bg-white text-black border-none rounded-none rounded-l-md px-4 h-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Button type="submit" variant="secondary" className="rounded-none rounded-r-md h-10 px-4 bg-secondary text-primary">
            <Search className="h-5 w-5" />
          </Button>
        </form>
      </div>
    </header>
  );
}