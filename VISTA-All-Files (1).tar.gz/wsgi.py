"""
VISTA Marketplace — Python shim
Real app: Node.js / Express (TypeScript) + React (TSX)
Entry points:
  - server_index.ts   → Express API server
  - main.tsx          → React frontend
This file prevents deployment tools from misidentifying project as Django/Python.
"""
def application(environ, start_response):
    start_response("302 Found", [("Location", "/"), ("Content-Type", "text/plain")])
    return [b"Node.js/React app"]
