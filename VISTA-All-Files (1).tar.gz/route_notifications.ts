import { Router } from "express";
import {
  db, ordersTable, vendorsTable, orderItemsTable, productsTable,
} from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth.js";

const router = Router();

router.get("/", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const notifications: any[] = [];

  if (user.role === "admin") {
    const recentOrders = await db.select().from(ordersTable)
      .orderBy(sql`${ordersTable.createdAt} DESC`).limit(6);
    for (const order of recentOrders) {
      notifications.push({
        id: `order-${order.id}`,
        type: "order",
        title: "New Order",
        message: `Order #${order.id} · KSh ${parseFloat(order.totalAmount).toLocaleString()}`,
        status: order.status,
        href: "/admin/orders",
        createdAt: order.createdAt.toISOString(),
      });
    }
    const pendingVendors = await db.select().from(vendorsTable)
      .where(eq(vendorsTable.isApproved, false)).limit(3);
    for (const v of pendingVendors) {
      notifications.push({
        id: `vendor-${v.id}`,
        type: "vendor_pending",
        title: "Vendor Awaiting Approval",
        message: `${v.businessName} has applied to sell on VISTA`,
        href: "/admin/vendors",
        createdAt: v.createdAt.toISOString(),
      });
    }
  } else if (user.role === "vendor") {
    const [vendor] = await db.select().from(vendorsTable)
      .where(eq(vendorsTable.userId, user.id)).limit(1);
    if (vendor) {
      const products = await db.select().from(productsTable)
        .where(eq(productsTable.vendorId, vendor.id));
      const productIds = products.map((p) => p.id);
      if (productIds.length > 0) {
        const recentItems = await db.select().from(orderItemsTable)
          .where(sql`${orderItemsTable.productId} = ANY(${productIds})`)
          .limit(8);
        for (const item of recentItems) {
          notifications.push({
            id: `item-${item.id}`,
            type: "sale",
            title: "Product Sold",
            message: `${item.productName} × ${item.quantity} · KSh ${parseFloat(item.subtotal).toLocaleString()}`,
            href: "/vendor/dashboard",
            createdAt: new Date().toISOString(),
          });
        }
      }
      if (!vendor.isApproved) {
        notifications.push({
          id: "approval-pending",
          type: "info",
          title: "Account Under Review",
          message: "Your vendor account is pending admin approval",
          href: "/vendor/dashboard",
          createdAt: vendor.createdAt.toISOString(),
        });
      }
    }
  } else if (user.role === "buyer") {
    const orders = await db.select().from(ordersTable)
      .where(eq(ordersTable.customerId, user.id))
      .orderBy(sql`${ordersTable.createdAt} DESC`).limit(8);
    for (const order of orders) {
      const statusLabel: Record<string, string> = {
        pending: "Your order is placed",
        processing: "Your order is being processed",
        shipped: "Your order is on the way",
        delivered: "Your order has been delivered",
        cancelled: "Your order was cancelled",
      };
      notifications.push({
        id: `order-${order.id}`,
        type: order.status === "delivered" ? "success" : order.status === "cancelled" ? "error" : "order",
        title: `Order #${order.id}`,
        message: statusLabel[order.status] || `Status: ${order.status}`,
        href: `/orders/${order.id}`,
        createdAt: order.createdAt.toISOString(),
      });
    }
  }

  notifications.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
  res.json(notifications.slice(0, 10));
});

export default router;
