import { useGetFeaturedProducts, useListCategories } from "@workspace/api-client-react";
import { Link } from "wouter";
import { ProductCard } from "@/components/product/product-card";
import { ChevronRight } from "lucide-react";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { data: categories, isLoading: isLoadingCategories } = useListCategories();
  const { data: featuredProducts, isLoading: isLoadingFeatured } = useGetFeaturedProducts();

  return (
    <div className="w-full pb-12">
      {/* Categories Bar */}
      <div className="bg-primary/5 border-b border-gray-200 py-3">
        <div className="container mx-auto px-4">
          <ScrollArea className="w-full whitespace-nowrap">
            <div className="flex w-max space-x-2 pb-2">
              <Link href="/products" className="inline-flex items-center justify-center px-4 py-1.5 text-sm font-medium rounded-full bg-white border border-gray-200 text-gray-800 hover:bg-gray-50 hover:text-primary transition-colors">
                All Departments
              </Link>
              {isLoadingCategories ? (
                Array(6).fill(0).map((_, i) => (
                  <Skeleton key={i} className="h-8 w-24 rounded-full" />
                ))
              ) : (
                categories?.map((category) => (
                  <Link 
                    key={category.id} 
                    href={`/categories/${category.slug}`}
                    className="inline-flex items-center justify-center px-4 py-1.5 text-sm font-medium rounded-full bg-white border border-gray-200 text-gray-800 hover:bg-gray-50 hover:text-primary transition-colors"
                  >
                    {category.name}
                  </Link>
                ))
              )}
            </div>
            <ScrollBar orientation="horizontal" className="invisible" />
          </ScrollArea>
        </div>
      </div>

      {/* Hero Banner */}
      <div className="bg-primary relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary to-primary/80 z-10" />
        {/* Placeholder for a nice hero background image */}
        <div className="absolute inset-0 opacity-20 mix-blend-overlay">
          <img src="https://images.unsplash.com/photo-1522204523234-8729aa6e3d5f?auto=format&fit=crop&w=2000&q=80" alt="Students" className="w-full h-full object-cover" />
        </div>
        
        <div className="container mx-auto px-4 py-16 md:py-24 relative z-20">
          <div className="max-w-2xl text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 tracking-tight">
              Rongo University's <br />
              <span className="text-secondary">Premier Marketplace</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-xl">
              Buy and sell products securely within the campus. From textbooks to electronics, fresh produce to fashion.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link href="/products" className="bg-secondary text-primary font-bold px-8 py-3 rounded-md hover:bg-[#f3a847] transition-colors inline-flex items-center">
                Shop Now <ChevronRight className="ml-2 h-5 w-5" />
              </Link>
              <Link href="/vendor/register" className="bg-white/10 text-white font-medium px-8 py-3 rounded-md hover:bg-white/20 transition-colors">
                Start Selling
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 mt-8 md:-mt-8 relative z-30">
        <div className="bg-white rounded-lg shadow-md p-6 mb-12 flex flex-col md:flex-row gap-6 md:items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="bg-primary/10 p-3 rounded-full text-primary">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            </div>
            <div>
              <h3 className="font-bold text-lg text-gray-900">Secure Payments</h3>
              <p className="text-gray-500 text-sm">Protected transactions</p>
            </div>
          </div>
          <div className="w-px h-12 bg-gray-200 hidden md:block"></div>
          <div className="flex items-center gap-4">
            <div className="bg-primary/10 p-3 rounded-full text-primary">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
            </div>
            <div>
              <h3 className="font-bold text-lg text-gray-900">Campus Delivery</h3>
              <p className="text-gray-500 text-sm">Fast local fulfillment</p>
            </div>
          </div>
          <div className="w-px h-12 bg-gray-200 hidden md:block"></div>
          <div className="flex items-center gap-4">
            <div className="bg-primary/10 p-3 rounded-full text-primary">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><path d="M2 7h20"/><path d="M22 7v3a2 2 0 0 1-2 2v0a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 16 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 12 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 8 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 4 12v0a2 2 0 0 1-2-2V7"/></svg>
            </div>
            <div>
              <h3 className="font-bold text-lg text-gray-900">Student Vendors</h3>
              <p className="text-gray-500 text-sm">Support your peers</p>
            </div>
          </div>
        </div>

        {/* Featured Products Section */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Latest Discoveries</h2>
            <Link href="/products" className="text-blue-600 hover:text-blue-800 hover:underline font-medium flex items-center">
              See all <ChevronRight className="h-4 w-4 ml-1" />
            </Link>
          </div>
          
          {isLoadingFeatured ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {Array(10).fill(0).map((_, i) => (
                <div key={i} className="flex flex-col space-y-3">
                  <Skeleton className="h-[200px] w-full rounded-xl" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-1/2" />
                    <Skeleton className="h-4 w-[80%]" />
                    <Skeleton className="h-6 w-1/3" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
              {featuredProducts?.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
              {(!featuredProducts || featuredProducts.length === 0) && (
                <div className="col-span-full py-12 text-center text-gray-500 bg-white rounded-lg border border-gray-100">
                  <p>No products available yet.</p>
                </div>
              )}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}