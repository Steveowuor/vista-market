import { Link } from "wouter";
import { Megaphone, Target, BarChart2, CheckCircle, Star } from "lucide-react";

const PLANS = [
  {
    name: "Basic Boost",
    price: "KSh 500",
    period: "/ week",
    desc: "Perfect for individual products you want more visibility on.",
    features: ["Featured badge on product card", "Appears in 'Sponsored' row on homepage", "Weekly performance report"],
    highlight: false,
  },
  {
    name: "Vendor Spotlight",
    price: "KSh 1,500",
    period: "/ month",
    desc: "Get your entire store featured — ideal for growing vendors.",
    features: ["Store banner on homepage carousel", "Top placement in category pages", "Priority in search results", "Monthly analytics report", "Social media shoutout"],
    highlight: true,
  },
  {
    name: "Campus Campaign",
    price: "KSh 3,500",
    period: "/ month",
    desc: "Full campus-wide campaign — posters, banners, and digital presence.",
    features: ["Everything in Vendor Spotlight", "Physical flyer distribution on campus", "WhatsApp broadcast to 3,000+ students", "Dedicated account manager", "Custom promotional banners"],
    highlight: false,
  },
];

export default function AdvertisePage() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <Megaphone className="h-12 w-12 mx-auto mb-4 text-secondary" />
          <h1 className="text-4xl font-bold mb-4">Advertise on VISTA</h1>
          <p className="text-xl text-gray-300">
            Reach 5,000+ students and staff at Rongo University. Affordable, targeted, and effective.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-5xl">
        {/* Why advertise */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {[
            { icon: Target, title: "Hyper-Targeted", desc: "Your ads reach only Rongo University students and staff — the exact people on campus." },
            { icon: BarChart2, title: "Measurable Results", desc: "Get click rates, impressions, and conversion data for every campaign you run." },
            { icon: Star, title: "Affordable Rates", desc: "Campus advertising at a fraction of traditional marketing cost. Starting at KSh 500/week." },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow text-center">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">{title}</h3>
              <p className="text-sm text-gray-600 leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>

        {/* Plans */}
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-10">Advertising Plans</h2>
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {PLANS.map((plan) => (
            <div key={plan.name} className={`rounded-xl border-2 p-6 flex flex-col ${plan.highlight ? "border-secondary bg-primary text-white shadow-xl scale-105" : "border-gray-200 bg-white"}`}>
              {plan.highlight && <div className="text-xs font-bold bg-secondary text-primary px-3 py-1 rounded-full self-start mb-3">MOST POPULAR</div>}
              <h3 className={`text-xl font-bold mb-1 ${plan.highlight ? "text-white" : "text-gray-900"}`}>{plan.name}</h3>
              <div className="mb-3">
                <span className={`text-3xl font-bold ${plan.highlight ? "text-secondary" : "text-primary"}`}>{plan.price}</span>
                <span className={`text-sm ${plan.highlight ? "text-gray-300" : "text-gray-500"}`}>{plan.period}</span>
              </div>
              <p className={`text-sm mb-5 ${plan.highlight ? "text-gray-300" : "text-gray-600"}`}>{plan.desc}</p>
              <ul className="space-y-2 flex-1 mb-6">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <CheckCircle className={`h-4 w-4 mt-0.5 flex-shrink-0 ${plan.highlight ? "text-secondary" : "text-green-500"}`} />
                    <span className={plan.highlight ? "text-gray-200" : "text-gray-700"}>{f}</span>
                  </li>
                ))}
              </ul>
              <a href="mailto:advertise@vista.ac.ke" className={`block text-center font-bold py-2.5 rounded-lg transition-colors ${plan.highlight ? "bg-secondary text-primary hover:bg-[#f3a847]" : "bg-primary text-white hover:bg-primary/90"}`}>
                Get Started
              </a>
            </div>
          ))}
        </div>

        <div className="bg-gray-50 rounded-xl p-8 text-center">
          <h3 className="font-bold text-gray-900 text-xl mb-2">Need a Custom Package?</h3>
          <p className="text-gray-600 text-sm mb-4">Contact us for bulk deals, event sponsorships, or semester-long campaigns.</p>
          <a href="mailto:advertise@vista.ac.ke" className="inline-block bg-primary text-white font-semibold px-6 py-2.5 rounded-lg hover:bg-primary/90 transition-colors">
            advertise@vista.ac.ke
          </a>
        </div>
      </div>
    </div>
  );
}
