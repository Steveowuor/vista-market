import { pgTable, text, serial, timestamp, integer, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const ordersTable = pgTable("orders", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id"),
  guestName: text("guest_name"),
  guestEmail: text("guest_email"),
  hostelName: text("hostel_name").notNull(),
  roomNumber: text("room_number").notNull(),
  contactPhone: text("contact_phone").notNull(),
  subtotal: numeric("subtotal", { precision: 10, scale: 2 }).notNull().default("0.00"),
  buyerFee: numeric("buyer_fee", { precision: 10, scale: 2 }).notNull().default("0.00"),
  totalAmount: numeric("total_amount", { precision: 10, scale: 2 }).notNull(),
  commissionAmount: numeric("commission_amount", { precision: 10, scale: 2 }).notNull().default("0.00"),
  vendorAmount: numeric("vendor_amount", { precision: 10, scale: 2 }).notNull().default("0.00"),
  status: text("status").notNull().default("pending"),
  paymentMethod: text("payment_method").notNull().default("cash"),
  mpesaPhone: text("mpesa_phone"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const orderItemsTable = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  productId: integer("product_id").notNull(),
  productName: text("product_name").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: numeric("unit_price", { precision: 10, scale: 2 }).notNull(),
  subtotal: numeric("subtotal", { precision: 10, scale: 2 }).notNull(),
});

export const insertOrderSchema = createInsertSchema(ordersTable).omit({ id: true, createdAt: true });
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof ordersTable.$inferSelect;
export type OrderItem = typeof orderItemsTable.$inferSelect;
