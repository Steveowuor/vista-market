import { Router } from "express";
import { db, productsTable, vendorsTable } from "@workspace/db";
import { eq, ilike, and, gte, lte, sql, inArray } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth.js";
import { CreateProductBody } from "@workspace/api-zod";

const router = Router();

function formatProduct(product: any, vendor: any) {
  return {
    id: product.id,
    name: product.name,
    description: product.description,
    price: parseFloat(product.price),
    imageUrl: product.imageUrl,
    category: product.category,
    condition: product.condition,
    stock: product.stock,
    rating: product.rating ? parseFloat(product.rating) : 0,
    reviewCount: product.reviewCount,
    vendorId: product.vendorId,
    vendorName: vendor?.businessName || "Unknown Vendor",
    createdAt: product.createdAt.toISOString(),
  };
}

router.get("/featured", async (req, res) => {
  const approvedVendors = await db.select().from(vendorsTable).where(eq(vendorsTable.isApproved, true));
  const approvedVendorIds = approvedVendors.map((v) => v.id);

  if (approvedVendorIds.length === 0) {
    res.json([]);
    return;
  }

  const products = await db
    .select()
    .from(productsTable)
    .where(inArray(productsTable.vendorId, approvedVendorIds))
    .orderBy(sql`${productsTable.createdAt} DESC`)
    .limit(12);

  const vendorMap = new Map(approvedVendors.map((v) => [v.id, v]));
  res.json(products.map((p) => formatProduct(p, vendorMap.get(p.vendorId))));
});

router.get("/", async (req, res) => {
  const { category, search, vendorId, condition, minPrice, maxPrice, page = "1", limit = "20" } = req.query as any;

  const approvedVendors = await db.select().from(vendorsTable).where(eq(vendorsTable.isApproved, true));
  const approvedVendorIds = approvedVendors.map((v) => v.id);

  if (approvedVendorIds.length === 0) {
    res.json({ products: [], total: 0, page: 1, totalPages: 0 });
    return;
  }

  const conditions: any[] = [inArray(productsTable.vendorId, approvedVendorIds)];

  if (category) conditions.push(eq(productsTable.category, category));
  if (vendorId) conditions.push(eq(productsTable.vendorId, parseInt(vendorId)));
  if (condition) conditions.push(eq(productsTable.condition, condition));
  if (search) conditions.push(ilike(productsTable.name, `%${search}%`));
  if (minPrice) conditions.push(gte(sql`${productsTable.price}::numeric`, parseFloat(minPrice)));
  if (maxPrice) conditions.push(lte(sql`${productsTable.price}::numeric`, parseFloat(maxPrice)));

  const pageNum = parseInt(page) || 1;
  const limitNum = parseInt(limit) || 20;
  const offset = (pageNum - 1) * limitNum;

  const whereClause = and(...conditions);

  const products = await db
    .select()
    .from(productsTable)
    .where(whereClause)
    .limit(limitNum)
    .offset(offset)
    .orderBy(sql`${productsTable.createdAt} DESC`);

  const [{ total }] = await db
    .select({ total: sql<number>`count(*)::int` })
    .from(productsTable)
    .where(whereClause);

  const vendorMap = new Map(approvedVendors.map((v) => [v.id, v]));

  res.json({
    products: products.map((p) => formatProduct(p, vendorMap.get(p.vendorId))),
    total,
    page: pageNum,
    totalPages: Math.ceil(total / limitNum),
  });
});

router.get("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, id)).limit(1);
  if (!product) {
    res.status(404).json({ message: "Product not found" });
    return;
  }
  const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.id, product.vendorId)).limit(1);

  if (!vendor?.isApproved) {
    res.status(404).json({ message: "Product not available" });
    return;
  }

  res.json(formatProduct(product, vendor));
});

router.post("/", requireAuth, async (req, res) => {
  const user = (req as any).user;
  if (user.role !== "vendor") {
    res.status(403).json({ message: "Only vendors can create products" });
    return;
  }

  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }

  const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.userId, user.id)).limit(1);
  if (!vendor) {
    res.status(403).json({ message: "No vendor profile found" });
    return;
  }

  if (!vendor.isApproved) {
    res.status(403).json({ message: "Your vendor account is pending approval. Products can only be listed after admin approval." });
    return;
  }

  const [product] = await db.insert(productsTable).values({
    ...parsed.data,
    vendorId: vendor.id,
    price: String(parsed.data.price),
  }).returning();

  res.status(201).json(formatProduct(product, vendor));
});

router.put("/:id", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const id = parseInt(String(req.params.id));

  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, id)).limit(1);
  if (!product) {
    res.status(404).json({ message: "Product not found" });
    return;
  }

  const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.userId, user.id)).limit(1);
  if (!vendor || product.vendorId !== vendor.id) {
    res.status(403).json({ message: "Not authorized" });
    return;
  }

  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }

  const [updated] = await db.update(productsTable).set({
    ...parsed.data,
    price: String(parsed.data.price),
  }).where(eq(productsTable.id, id)).returning();

  res.json(formatProduct(updated, vendor));
});

router.delete("/:id", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const id = parseInt(String(req.params.id));

  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, id)).limit(1);
  if (!product) {
    res.status(404).json({ message: "Product not found" });
    return;
  }

  if (user.role !== "admin") {
    const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.userId, user.id)).limit(1);
    if (!vendor || product.vendorId !== vendor.id) {
      res.status(403).json({ message: "Not authorized" });
      return;
    }
  }

  await db.delete(productsTable).where(eq(productsTable.id, id));
  res.json({ message: "Product deleted" });
});

export default router;
