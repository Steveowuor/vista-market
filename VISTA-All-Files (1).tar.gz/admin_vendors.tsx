import { useListAllVendors, useApproveVendor, useRejectVendor } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { getListAllVendorsQueryKey } from "@workspace/api-client-react";
import { Link } from "wouter";
import { CheckCircle, XCircle, Clock, Store, ArrowLeft } from "lucide-react";

export default function AdminVendorsPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: vendors, isLoading } = useListAllVendors();

  const approveMutation = useApproveVendor({
    mutation: {
      onSuccess: (vendor) => {
        queryClient.invalidateQueries({ queryKey: getListAllVendorsQueryKey() });
        toast({ title: "Vendor approved!", description: `${vendor.businessName} can now list products.` });
      },
      onError: () => toast({ title: "Error", description: "Could not approve vendor.", variant: "destructive" }),
    },
  });

  const rejectMutation = useRejectVendor({
    mutation: {
      onSuccess: (vendor) => {
        queryClient.invalidateQueries({ queryKey: getListAllVendorsQueryKey() });
        toast({ title: "Vendor suspended", description: `${vendor.businessName} has been suspended.` });
      },
      onError: () => toast({ title: "Error", description: "Could not reject vendor.", variant: "destructive" }),
    },
  });

  if (!user || user.role !== "admin") {
    setLocation("/login");
    return null;
  }

  const pending = vendors?.filter((v) => !v.isApproved) ?? [];
  const approved = vendors?.filter((v) => v.isApproved) ?? [];

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <div className="flex items-center gap-4 mb-8">
        <Link href="/admin">
          <Button variant="ghost" size="icon"><ArrowLeft className="w-5 h-5" /></Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Vendor Management</h1>
          <p className="text-gray-500 text-sm">Approve or suspend vendor accounts</p>
        </div>
      </div>

      {isLoading && <p className="text-center text-gray-400 py-12">Loading vendors...</p>}

      {!isLoading && (
        <>
          {pending.length > 0 && (
            <section className="mb-10">
              <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <Clock className="w-5 h-5 text-yellow-500" />
                Pending Approval ({pending.length})
              </h2>
              <div className="space-y-4">
                {pending.map((vendor) => (
                  <VendorCard
                    key={vendor.id}
                    vendor={vendor}
                    onApprove={() => approveMutation.mutate({ id: vendor.id })}
                    onReject={() => rejectMutation.mutate({ id: vendor.id })}
                    approving={approveMutation.isPending}
                    rejecting={rejectMutation.isPending}
                  />
                ))}
              </div>
            </section>
          )}

          {pending.length === 0 && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-8 flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
              <p className="text-green-800 text-sm">No vendors pending approval.</p>
            </div>
          )}

          <section>
            <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              Approved Vendors ({approved.length})
            </h2>
            {approved.length === 0 && (
              <p className="text-gray-400 text-sm">No approved vendors yet.</p>
            )}
            <div className="space-y-4">
              {approved.map((vendor) => (
                <VendorCard
                  key={vendor.id}
                  vendor={vendor}
                  onReject={() => rejectMutation.mutate({ id: vendor.id })}
                  rejecting={rejectMutation.isPending}
                />
              ))}
            </div>
          </section>
        </>
      )}
    </div>
  );
}

function VendorCard({
  vendor,
  onApprove,
  onReject,
  approving,
  rejecting,
}: {
  vendor: any;
  onApprove?: () => void;
  onReject?: () => void;
  approving?: boolean;
  rejecting?: boolean;
}) {
  return (
    <div className="bg-white border border-gray-200 rounded-lg p-5 flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between shadow-sm">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
          {vendor.logoUrl
            ? <img src={vendor.logoUrl} alt={vendor.businessName} className="w-12 h-12 rounded-full object-cover" />
            : <Store className="w-6 h-6 text-primary" />}
        </div>
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-bold text-gray-900">{vendor.businessName}</h3>
            <Badge variant={vendor.isApproved ? "default" : "secondary"} className={vendor.isApproved ? "bg-green-100 text-green-700 border-green-200" : "bg-yellow-100 text-yellow-700 border-yellow-200"}>
              {vendor.isApproved ? "Approved" : "Pending"}
            </Badge>
          </div>
          <p className="text-sm text-gray-500">{vendor.contactEmail}</p>
          {vendor.description && <p className="text-sm text-gray-400 mt-1 line-clamp-1">{vendor.description}</p>}
          <div className="text-xs text-gray-400 mt-1">{vendor.productCount ?? 0} products · Joined {new Date(vendor.createdAt).toLocaleDateString()}</div>
        </div>
      </div>
      <div className="flex gap-2 flex-shrink-0">
        {!vendor.isApproved && onApprove && (
          <Button
            size="sm"
            className="bg-green-600 hover:bg-green-700 text-white"
            onClick={onApprove}
            disabled={approving}
          >
            <CheckCircle className="w-4 h-4 mr-1" />
            Approve
          </Button>
        )}
        {onReject && (
          <Button
            size="sm"
            variant="outline"
            className="border-red-200 text-red-600 hover:bg-red-50"
            onClick={onReject}
            disabled={rejecting}
          >
            <XCircle className="w-4 h-4 mr-1" />
            {vendor.isApproved ? "Suspend" : "Reject"}
          </Button>
        )}
      </div>
    </div>
  );
}
