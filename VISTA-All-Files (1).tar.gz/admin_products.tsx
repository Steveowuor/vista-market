import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useListCategories } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation, Link } from "wouter";
import { ArrowLeft, Search, Package, Star, TrendingUp, ShoppingBag } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

interface AdminProduct {
  id: number;
  name: string;
  price: number;
  category: string;
  condition: string;
  stock: number;
  imageUrl: string | null;
  vendorId: number;
  vendorName: string;
  rating: number;
  reviewCount: number;
  totalSold: number;
  totalRevenue: number;
  createdAt: string;
}

export default function AdminProductsPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [conditionFilter, setConditionFilter] = useState("all");
  const [sortBy, setSortBy] = useState<"totalRevenue" | "totalSold" | "createdAt" | "price">("totalRevenue");

  const { data: products, isLoading } = useQuery<AdminProduct[]>({
    queryKey: ["admin-products"],
    queryFn: async () => {
      const res = await fetch("/api/admin/products");
      if (!res.ok) throw new Error("Failed to fetch products");
      return res.json();
    },
    enabled: !!user && user.role === "admin",
  });

  const { data: categories } = useListCategories();

  if (!user || user.role !== "admin") { setLocation("/"); return null; }

  const filtered = (products || [])
    .filter((p) => {
      if (search && !p.name.toLowerCase().includes(search.toLowerCase()) && !p.vendorName.toLowerCase().includes(search.toLowerCase())) return false;
      if (categoryFilter !== "all" && p.category !== categoryFilter) return false;
      if (conditionFilter !== "all" && p.condition !== conditionFilter) return false;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === "createdAt") return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      return b[sortBy] - a[sortBy];
    });

  const totalRevenue = (products || []).reduce((s, p) => s + p.totalRevenue, 0);
  const totalSold = (products || []).reduce((s, p) => s + p.totalSold, 0);
  const uniqueCategories = [...new Set((products || []).map((p) => p.category))];

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Link href="/admin/dashboard">
          <button className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50">
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Product Catalogue</h1>
          <p className="text-sm text-gray-500">All products listed on VISTA Marketplace</p>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <div className="flex items-center gap-3">
            <div className="bg-primary/10 p-2 rounded-lg"><Package className="h-5 w-5 text-primary" /></div>
            <div>
              <p className="text-xs text-gray-500">Total Products</p>
              <p className="text-2xl font-bold text-gray-900">{products?.length || 0}</p>
            </div>
          </div>
        </div>
        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <div className="flex items-center gap-3">
            <div className="bg-blue-100 p-2 rounded-lg"><ShoppingBag className="h-5 w-5 text-blue-600" /></div>
            <div>
              <p className="text-xs text-gray-500">Units Sold</p>
              <p className="text-2xl font-bold text-gray-900">{totalSold.toLocaleString()}</p>
            </div>
          </div>
        </div>
        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <div className="flex items-center gap-3">
            <div className="bg-green-100 p-2 rounded-lg"><TrendingUp className="h-5 w-5 text-green-600" /></div>
            <div>
              <p className="text-xs text-gray-500">Product Revenue</p>
              <p className="text-2xl font-bold text-gray-900">KSh {(totalRevenue / 1000).toFixed(0)}k</p>
            </div>
          </div>
        </div>
        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <div className="flex items-center gap-3">
            <div className="bg-secondary/20 p-2 rounded-lg"><Star className="h-5 w-5 text-primary" /></div>
            <div>
              <p className="text-xs text-gray-500">Categories</p>
              <p className="text-2xl font-bold text-gray-900">{uniqueCategories.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input placeholder="Search products or vendors..." className="pl-9" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select
          className="px-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-700 bg-white focus:outline-none"
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
        >
          <option value="all">All Categories</option>
          {(categories || []).map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
        </select>
        <select
          className="px-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-700 bg-white focus:outline-none"
          value={conditionFilter}
          onChange={(e) => setConditionFilter(e.target.value)}
        >
          <option value="all">All Conditions</option>
          <option value="new">New</option>
          <option value="used">Used</option>
        </select>
        <select
          className="px-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-700 bg-white focus:outline-none"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
        >
          <option value="totalRevenue">Sort by Revenue</option>
          <option value="totalSold">Sort by Units Sold</option>
          <option value="price">Sort by Price</option>
          <option value="createdAt">Sort by Newest</option>
        </select>
      </div>

      {/* Products Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => <div key={i} className="h-48 bg-gray-100 rounded-xl animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20 bg-white border border-gray-200 rounded-xl">
          <Package className="h-12 w-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No products found</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((product) => (
              <div key={product.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:shadow-md transition-shadow group">
                <div className="relative">
                  <div className="h-40 bg-gray-100 overflow-hidden">
                    {product.imageUrl ? (
                      <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Package className="h-12 w-12 text-gray-300" />
                      </div>
                    )}
                  </div>
                  <Badge variant="outline" className={`absolute top-2 left-2 text-xs ${product.condition === "new" ? "bg-green-50 border-green-200 text-green-700" : "bg-orange-50 border-orange-200 text-orange-700"}`}>
                    {product.condition}
                  </Badge>
                  {product.totalSold > 0 && (
                    <div className="absolute top-2 right-2 bg-primary text-white text-xs px-2 py-0.5 rounded-full font-medium">
                      {product.totalSold} sold
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <Link href={`/products/${product.id}`}>
                    <p className="font-bold text-gray-900 text-sm line-clamp-1 hover:text-primary cursor-pointer">{product.name}</p>
                  </Link>
                  <p className="text-xs text-gray-500 mt-0.5">by {product.vendorName}</p>
                  <div className="flex items-center justify-between mt-2">
                    <p className="text-base font-bold text-primary">KSh {product.price.toLocaleString()}</p>
                    <div className="flex items-center gap-1">
                      <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                      <span className="text-xs text-gray-500">{product.rating > 0 ? product.rating.toFixed(1) : "—"}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-100">
                    <span className="text-xs text-gray-400">Stock: {product.stock}</span>
                    <span className="text-xs text-green-600 font-medium">
                      Revenue: KSh {product.totalRevenue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </span>
                  </div>
                  <p className="text-xs text-gray-300 mt-1">{format(new Date(product.createdAt), "MMM d, yyyy")}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 text-sm text-gray-500 text-center">
            Showing {filtered.length} of {products?.length} products
          </div>
        </>
      )}
    </div>
  );
}
