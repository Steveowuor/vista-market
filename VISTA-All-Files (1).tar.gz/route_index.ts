import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import authRouter from "./auth.js";
import categoriesRouter from "./categories.js";
import productsRouter from "./products.js";
import vendorsRouter, { vendorOwnerRouter } from "./vendors.js";
import cartRouter from "./cart.js";
import ordersRouter from "./orders.js";
import wishlistRouter from "./wishlist.js";
import adminRouter from "./admin.js";
import notificationsRouter from "./notifications.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/categories", categoriesRouter);
router.use("/products", productsRouter);
router.use("/vendors", vendorsRouter);
router.use("/vendor", vendorOwnerRouter);
router.use("/cart", cartRouter);
router.use("/orders", ordersRouter);
router.use("/wishlist", wishlistRouter);
router.use("/admin", adminRouter);
router.use("/notifications", notificationsRouter);

export default router;
