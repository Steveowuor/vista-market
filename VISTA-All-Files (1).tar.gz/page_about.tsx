import { Link } from "wouter";
import { Users, Target, Heart, Award, MapPin, Mail, Phone } from "lucide-react";

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <h1 className="text-4xl font-bold mb-4">About VISTA</h1>
          <p className="text-xl text-gray-300">
            Rongo University's official campus marketplace — connecting students, staff, and local vendors in one trusted platform.
          </p>
        </div>
      </div>

      {/* Mission */}
      <div className="container mx-auto px-4 py-16 max-w-5xl">
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Mission</h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              VISTA was founded with a simple goal: make campus life easier. Whether you're a student looking for affordable textbooks, fresh produce, or daily essentials — or a local vendor wanting to reach thousands of campus customers — VISTA is built for you.
            </p>
            <p className="text-gray-600 leading-relaxed">
              We believe that commerce within a university community should be safe, transparent, and fair. Every transaction on VISTA is secured, and every vendor is verified by our admin team before going live.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { icon: Users, label: "Students & Staff", value: "5,000+", color: "bg-blue-50 text-blue-700" },
              { icon: Award, label: "Active Vendors", value: "120+", color: "bg-orange-50 text-orange-700" },
              { icon: Heart, label: "Orders Delivered", value: "8,400+", color: "bg-green-50 text-green-700" },
              { icon: Target, label: "Product Categories", value: "7", color: "bg-purple-50 text-purple-700" },
            ].map(({ icon: Icon, label, value, color }) => (
              <div key={label} className={`${color} rounded-xl p-5 text-center`}>
                <Icon className="h-6 w-6 mx-auto mb-2" />
                <p className="text-2xl font-bold">{value}</p>
                <p className="text-sm font-medium">{label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Values */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-10">Our Values</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { title: "Transparency", desc: "Clear pricing, visible fees, and honest vendor reviews. No hidden charges — ever." },
              { title: "Community First", desc: "VISTA exists to serve the Rongo University community — students, staff, and local entrepreneurs alike." },
              { title: "Security", desc: "Every vendor is manually approved. All payments are tracked. Your safety is our priority." },
            ].map((v) => (
              <div key={v.title} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow">
                <h3 className="font-bold text-lg text-primary mb-2">{v.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Contact */}
        <div className="bg-gray-50 rounded-2xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">Get in Touch</h2>
          <div className="grid md:grid-cols-3 gap-6 text-center">
            <div className="flex flex-col items-center gap-2">
              <MapPin className="h-6 w-6 text-primary" />
              <p className="font-semibold text-gray-900">Location</p>
              <p className="text-sm text-gray-600">Rongo University<br />P.O. Box 103-40404, Rongo, Kenya</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Mail className="h-6 w-6 text-primary" />
              <p className="font-semibold text-gray-900">Email</p>
              <p className="text-sm text-gray-600">support@vista.ac.ke<br />admin@vista.ac.ke</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Phone className="h-6 w-6 text-primary" />
              <p className="font-semibold text-gray-900">Phone</p>
              <p className="text-sm text-gray-600">+254 700 000 000<br />Mon – Fri, 8am – 6pm</p>
            </div>
          </div>
        </div>

        <div className="text-center mt-10">
          <Link href="/vendor/register">
            <button className="bg-secondary text-primary font-bold px-8 py-3 rounded-lg hover:bg-[#f3a847] transition-colors mr-4">
              Become a Vendor
            </button>
          </Link>
          <Link href="/products">
            <button className="border-2 border-primary text-primary font-bold px-8 py-3 rounded-lg hover:bg-primary hover:text-white transition-colors">
              Shop Now
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
