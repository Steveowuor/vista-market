import { createContext, useContext, ReactNode } from "react";
import { useGetMe, useLogout, useLogin, useRegister, getGetMeQueryOptions } from "@workspace/api-client-react";
import type { User, LoginBody, RegisterBody } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (data: LoginBody) => Promise<void>;
  register: (data: RegisterBody) => Promise<void>;
  logout: () => Promise<void>;
  isLoginPending: boolean;
  isRegisterPending: boolean;
  isLogoutPending: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const { data: user = null, isLoading } = useGetMe({
    query: {
      ...getGetMeQueryOptions(),
      retry: false,
      staleTime: 5 * 60 * 1000,
    },
  });

  const loginMutation = useLogin({
    mutation: {
      onSuccess: (res) => {
        queryClient.setQueryData(["/api/auth/me"], res.user);
        toast({ title: "Welcome back!", description: res.message });
        setLocation("/");
      },
      onError: (error: any) => {
        toast({
          title: "Login failed",
          description: error.message || "Invalid credentials",
          variant: "destructive",
        });
      },
    },
  });

  const registerMutation = useRegister({
    mutation: {
      onSuccess: (res) => {
        queryClient.setQueryData(["/api/auth/me"], res.user);
        toast({ title: "Welcome to VISTA!", description: res.message });
        setLocation("/");
      },
      onError: (error: any) => {
        toast({
          title: "Registration failed",
          description: error.message || "Could not create account",
          variant: "destructive",
        });
      },
    },
  });

  const logoutMutation = useLogout({
    mutation: {
      onSuccess: () => {
        queryClient.setQueryData(["/api/auth/me"], null);
        queryClient.clear(); // clear other user data
        toast({ title: "Logged out successfully" });
        setLocation("/");
      },
    },
  });

  const login = async (data: LoginBody) => {
    await loginMutation.mutateAsync({ data });
  };

  const registerUser = async (data: RegisterBody) => {
    await registerMutation.mutateAsync({ data });
  };

  const logoutUser = async () => {
    await logoutMutation.mutateAsync();
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        login,
        register: registerUser,
        logout: logoutUser,
        isLoginPending: loginMutation.isPending,
        isRegisterPending: registerMutation.isPending,
        isLogoutPending: logoutMutation.isPending,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}