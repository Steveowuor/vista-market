import { Truck, MapPin, Clock, CheckCircle, AlertCircle, Package } from "lucide-react";

const HOSTELS = [
  "Block A, B, C, D (Main Campus)", "Mara Hostel", "Migori Hostel",
  "Masaba Hostel", "Staff Quarters", "Main Lecture Block area",
];

const FAQS = [
  {
    q: "How long does delivery take?",
    a: "Most orders are delivered within 2–6 hours during business hours (8am–7pm). Orders placed after 7pm are delivered the next morning.",
  },
  {
    q: "Is there a delivery fee?",
    a: "Delivery is FREE for all orders within the Rongo University campus. Off-campus delivery is not currently available.",
  },
  {
    q: "What if I'm not in my room when delivery arrives?",
    a: "The vendor will call your contact number. If unreachable, the delivery is rescheduled or a notice is left at your door.",
  },
  {
    q: "Can I change my delivery address after ordering?",
    a: "Contact the vendor directly through the order detail page as soon as possible. Changes before dispatch can usually be accommodated.",
  },
  {
    q: "What about large or fragile items?",
    a: "Vendors are responsible for safe packaging. If an item arrives damaged, initiate a return within 24 hours.",
  },
];

export default function ShippingPage() {
  return (
    <div className="min-h-screen">
      <div className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <Truck className="h-12 w-12 mx-auto mb-4 text-secondary" />
          <h1 className="text-4xl font-bold mb-4">Shipping Rates & Policies</h1>
          <p className="text-xl text-gray-300">
            Fast, free campus delivery — all orders delivered right to your hostel room.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        {/* Highlight */}
        <div className="bg-green-50 border border-green-200 rounded-xl p-5 flex gap-3 mb-12">
          <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-green-900">FREE Delivery on All Orders</p>
            <p className="text-sm text-green-800">VISTA offers free campus delivery on every order — no minimum spend required. Vendors hand-deliver to your hostel block or room number.</p>
          </div>
        </div>

        {/* Delivery Info */}
        <div className="grid md:grid-cols-3 gap-6 mb-14">
          {[
            { icon: Clock, title: "Delivery Time", value: "2–6 Hours", desc: "Same-day delivery for orders placed before 7pm", color: "text-blue-600 bg-blue-50" },
            { icon: MapPin, title: "Delivery Zone", value: "Campus Only", desc: "All Rongo University hostels, blocks, and lecture areas", color: "text-orange-600 bg-orange-50" },
            { icon: Package, title: "Delivery Fee", value: "KSh 0", desc: "Completely free — always", color: "text-green-600 bg-green-50" },
          ].map(({ icon: Icon, title, value, desc, color }) => (
            <div key={title} className="bg-white border border-gray-200 rounded-xl p-6 text-center hover:shadow-md transition-shadow">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 ${color}`}>
                <Icon className="h-6 w-6" />
              </div>
              <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">{title}</p>
              <p className="text-2xl font-bold text-gray-900 mb-1">{value}</p>
              <p className="text-xs text-gray-500">{desc}</p>
            </div>
          ))}
        </div>

        {/* Delivery locations */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 mb-10">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" /> Delivery Locations
          </h2>
          <p className="text-sm text-gray-600 mb-4">We deliver to all areas within Rongo University campus, including:</p>
          <div className="grid md:grid-cols-2 gap-2">
            {HOSTELS.map((h) => (
              <div key={h} className="flex items-center gap-2 text-sm text-gray-700">
                <CheckCircle className="h-3.5 w-3.5 text-green-500 flex-shrink-0" />
                {h}
              </div>
            ))}
          </div>
        </div>

        {/* Off-campus note */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-5 flex gap-3 mb-10">
          <AlertCircle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-yellow-900">Off-Campus Delivery</p>
            <p className="text-sm text-yellow-800">VISTA currently only delivers within Rongo University campus. Off-campus delivery is coming soon. For urgent off-campus needs, contact the vendor directly.</p>
          </div>
        </div>

        {/* FAQs */}
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {FAQS.map((faq) => (
            <div key={faq.q} className="bg-white border border-gray-200 rounded-xl p-5">
              <p className="font-semibold text-gray-900 mb-2">{faq.q}</p>
              <p className="text-sm text-gray-600 leading-relaxed">{faq.a}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
