import { Link } from "wouter";
import { Shield, Lock, CreditCard, TrendingUp, CheckCircle, AlertCircle } from "lucide-react";

export default function SecuredCardPage() {
  return (
    <div className="min-h-screen">
      <div className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <Shield className="h-12 w-12 mx-auto mb-4 text-secondary" />
          <h1 className="text-4xl font-bold mb-4">VISTA Secured Card</h1>
          <p className="text-xl text-gray-300">
            A prepaid secured card for students who want full control over their spending. Set your limit, shop safely.
          </p>
          <div className="mt-8">
            <Link href="/register">
              <button className="bg-secondary text-primary font-bold px-8 py-3 rounded-lg hover:bg-[#f3a847] transition-colors text-lg">
                Get Secured Card
              </button>
            </Link>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        {/* Difference callout */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-5 flex gap-3 mb-12">
          <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-blue-900 mb-1">What makes it "Secured"?</p>
            <p className="text-sm text-blue-800">Unlike a regular store card, the Secured Card requires a deposit that becomes your spending limit. This protects you from overspending and helps you build a trusted payment record on VISTA.</p>
          </div>
        </div>

        {/* Benefits grid */}
        <div className="grid md:grid-cols-2 gap-6 mb-14">
          {[
            { icon: Lock, title: "Controlled Spending", desc: "Your deposit sets your limit — you can never spend more than you've loaded.", color: "text-red-600 bg-red-50" },
            { icon: TrendingUp, title: "Build Trust Score", desc: "Regular on-time purchases build your VISTA Trust Score, unlocking higher limits over time.", color: "text-green-600 bg-green-50" },
            { icon: CreditCard, title: "Upgrade Path", desc: "After 6 months of responsible use, upgrade to the full VISTA Rewards Visa Signature Card.", color: "text-purple-600 bg-purple-50" },
            { icon: Shield, title: "Fraud Protection", desc: "If your card details are compromised, your liability is zero — VISTA covers fraudulent charges.", color: "text-blue-600 bg-blue-50" },
          ].map(({ icon: Icon, title, desc, color }) => (
            <div key={title} className="bg-white border border-gray-200 rounded-xl p-6 flex gap-4 hover:shadow-md transition-shadow">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${color}`}>
                <Icon className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 mb-1">{title}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Deposit tiers */}
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">Deposit & Limit Tiers</h2>
        <div className="grid md:grid-cols-3 gap-4 mb-14">
          {[
            { tier: "Starter", deposit: "KSh 500", limit: "KSh 500", color: "border-gray-200" },
            { tier: "Regular", deposit: "KSh 1,500", limit: "KSh 1,500", color: "border-secondary bg-primary text-white" },
            { tier: "Premium", deposit: "KSh 5,000", limit: "KSh 5,000", color: "border-gray-200" },
          ].map((t) => (
            <div key={t.tier} className={`border-2 rounded-xl p-6 text-center ${t.color}`}>
              <p className={`font-bold text-xl mb-1 ${t.color.includes("primary") ? "text-white" : "text-gray-900"}`}>{t.tier}</p>
              <p className={`text-sm mb-3 ${t.color.includes("primary") ? "text-gray-300" : "text-gray-500"}`}>Required Deposit</p>
              <p className={`text-3xl font-bold ${t.color.includes("primary") ? "text-secondary" : "text-primary"}`}>{t.deposit}</p>
              <p className={`text-xs mt-2 ${t.color.includes("primary") ? "text-gray-300" : "text-gray-500"}`}>Spending limit: {t.limit}</p>
            </div>
          ))}
        </div>

        <div className="bg-gray-50 rounded-xl p-8 mb-10">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Requirements</h2>
          <div className="space-y-2">
            {[
              "Active VISTA buyer account",
              "Valid student or staff ID from Rongo University",
              "Minimum deposit of KSh 500 (via M-PESA)",
              "One-time card issuance fee: KSh 50",
            ].map((r) => (
              <div key={r} className="flex items-start gap-2">
                <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                <span className="text-sm text-gray-700">{r}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center">
          <Link href="/register">
            <button className="bg-primary text-white font-bold px-8 py-3 rounded-lg hover:bg-primary/90 transition-colors">
              Apply for Secured Card
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
