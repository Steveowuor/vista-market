import { Router } from "express";
import {
  db, vendorsTable, productsTable, usersTable,
  ordersTable, orderItemsTable
} from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth.js";
import { CreateVendorBody, UpdateVendorPaymentBody } from "@workspace/api-zod";

// ─── Public / registration router (/vendors) ────────────────────────────────
const router = Router();

function formatVendor(vendor: any, productCount = 0, totalSales = 0) {
  return {
    id: vendor.id,
    userId: vendor.userId,
    businessName: vendor.businessName,
    description: vendor.description,
    logoUrl: vendor.logoUrl,
    contactEmail: vendor.contactEmail,
    contactPhone: vendor.contactPhone,
    address: vendor.address,
    commissionRate: parseFloat(vendor.commissionRate),
    isApproved: vendor.isApproved,
    productCount,
    totalSales,
    paymentType: vendor.paymentType,
    mpesaNumber: vendor.mpesaNumber,
    bankName: vendor.bankName,
    bankAccount: vendor.bankAccount,
    bankBranch: vendor.bankBranch,
    paybillNumber: vendor.paybillNumber,
    paybillBusinessName: vendor.paybillBusinessName,
    tillNumber: vendor.tillNumber,
    createdAt: vendor.createdAt.toISOString(),
  };
}

router.get("/", async (_req, res) => {
  const vendors = await db.select().from(vendorsTable);
  const withCounts = await Promise.all(
    vendors.map(async (v) => {
      const [{ count }] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(productsTable)
        .where(eq(productsTable.vendorId, v.id));
      return formatVendor(v, count, 0);
    })
  );
  res.json(withCounts);
});

router.get("/me", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.userId, user.id)).limit(1);
  if (!vendor) {
    res.status(404).json({ message: "No vendor profile found" });
    return;
  }
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(productsTable)
    .where(eq(productsTable.vendorId, vendor.id));
  res.json(formatVendor(vendor, count, 0));
});

router.get("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.id, id)).limit(1);
  if (!vendor) {
    res.status(404).json({ message: "Vendor not found" });
    return;
  }
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(productsTable)
    .where(eq(productsTable.vendorId, vendor.id));
  res.json(formatVendor(vendor, count, 0));
});

router.post("/", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const existing = await db.select().from(vendorsTable).where(eq(vendorsTable.userId, user.id)).limit(1);
  if (existing.length > 0) {
    res.status(409).json({ message: "Already registered as a vendor" });
    return;
  }
  const parsed = CreateVendorBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }
  await db.update(usersTable).set({ role: "vendor" }).where(eq(usersTable.id, user.id));
  const [vendor] = await db.insert(vendorsTable).values({
    userId: user.id,
    businessName: parsed.data.businessName,
    description: parsed.data.description,
    contactEmail: parsed.data.contactEmail,
    contactPhone: parsed.data.contactPhone,
    address: parsed.data.address,
    isApproved: false,
    commissionRate: "7.00",
  }).returning();
  res.status(201).json(formatVendor(vendor, 0, 0));
});

export default router;

// ─── Vendor owner router (/vendor) ──────────────────────────────────────────
export const vendorOwnerRouter = Router();

async function getVendorForUser(userId: number) {
  const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.userId, userId)).limit(1);
  return vendor;
}

async function formatOrder(order: any) {
  const items = await db.select().from(orderItemsTable).where(eq(orderItemsTable.orderId, order.id));
  let customerName = order.guestName || "Guest";
  if (order.customerId) {
    const [customer] = await db.select().from(usersTable).where(eq(usersTable.id, order.customerId)).limit(1);
    if (customer) customerName = customer.name;
  }
  return {
    id: order.id,
    customerId: order.customerId,
    customerName,
    guestName: order.guestName,
    hostelName: order.hostelName,
    roomNumber: order.roomNumber,
    contactPhone: order.contactPhone,
    items: items.map((item) => ({
      id: item.id,
      productId: item.productId,
      productName: item.productName,
      quantity: item.quantity,
      unitPrice: parseFloat(item.unitPrice),
      subtotal: parseFloat(item.subtotal),
    })),
    subtotal: parseFloat(order.subtotal || order.totalAmount),
    buyerFee: parseFloat(order.buyerFee || "0"),
    totalAmount: parseFloat(order.totalAmount),
    commissionAmount: parseFloat(order.commissionAmount),
    vendorAmount: parseFloat(order.vendorAmount),
    status: order.status,
    paymentMethod: order.paymentMethod,
    mpesaPhone: order.mpesaPhone,
    createdAt: order.createdAt.toISOString(),
  };
}

vendorOwnerRouter.get("/products", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const vendor = await getVendorForUser(user.id);
  if (!vendor) { res.status(403).json({ message: "No vendor profile found" }); return; }

  const products = await db
    .select()
    .from(productsTable)
    .where(eq(productsTable.vendorId, vendor.id))
    .orderBy(sql`${productsTable.createdAt} DESC`);

  res.json(products.map((p) => ({
    id: p.id, name: p.name, description: p.description,
    price: parseFloat(p.price), imageUrl: p.imageUrl,
    category: p.category, condition: p.condition,
    stock: p.stock, rating: p.rating ? parseFloat(p.rating) : 0,
    reviewCount: p.reviewCount, vendorId: p.vendorId,
    vendorName: vendor.businessName, createdAt: p.createdAt.toISOString(),
  })));
});

vendorOwnerRouter.get("/orders", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const vendor = await getVendorForUser(user.id);
  if (!vendor) { res.status(403).json({ message: "No vendor profile found" }); return; }

  const vendorProducts = await db.select().from(productsTable).where(eq(productsTable.vendorId, vendor.id));
  const productIds = vendorProducts.map((p) => p.id);
  if (productIds.length === 0) { res.json([]); return; }

  const orderItemsForVendor = await db.select().from(orderItemsTable)
    .where(sql`${orderItemsTable.productId} = ANY(${productIds})`);
  const orderIds = [...new Set(orderItemsForVendor.map((oi) => oi.orderId))];
  if (orderIds.length === 0) { res.json([]); return; }

  const orders = await db.select().from(ordersTable)
    .where(sql`${ordersTable.id} = ANY(${orderIds})`);
  const formatted = await Promise.all(orders.map(formatOrder));
  res.json(formatted);
});

vendorOwnerRouter.get("/stats", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const vendor = await getVendorForUser(user.id);
  if (!vendor) { res.status(403).json({ message: "No vendor profile found" }); return; }

  const [{ totalProducts }] = await db
    .select({ totalProducts: sql<number>`count(*)::int` })
    .from(productsTable)
    .where(eq(productsTable.vendorId, vendor.id));

  const vendorProducts = await db.select().from(productsTable).where(eq(productsTable.vendorId, vendor.id));
  const productIds = vendorProducts.map((p) => p.id);

  let grossRevenue = 0;
  const orderIds: number[] = [];

  if (productIds.length > 0) {
    const orderItems = await db.select().from(orderItemsTable)
      .where(sql`${orderItemsTable.productId} = ANY(${productIds})`);
    const uniqueOrderIds = [...new Set(orderItems.map((oi) => oi.orderId))];
    orderIds.push(...uniqueOrderIds);
    for (const oi of orderItems) grossRevenue += parseFloat(oi.subtotal);
  }

  let pendingOrders = 0;
  if (orderIds.length > 0) {
    const orders = await db.select().from(ordersTable)
      .where(sql`${ordersTable.id} = ANY(${orderIds})`);
    pendingOrders = orders.filter((o) => o.status === "pending").length;
  }

  const vendorCommissionRate = parseFloat(vendor.commissionRate) / 100;
  const platformFee = grossRevenue * vendorCommissionRate;
  const netPayout = grossRevenue - platformFee;

  const recentOrdersRaw = orderIds.length > 0
    ? await db.select().from(ordersTable).where(sql`${ordersTable.id} = ANY(${orderIds})`).limit(5)
    : [];
  const recentOrders = await Promise.all(recentOrdersRaw.map(formatOrder));

  // Revenue by month (last 6 months)
  const revenueByMonth = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    const monthStart = new Date(d.getFullYear(), d.getMonth(), 1);
    const monthEnd = new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59);
    let monthRevenue = 0;
    if (productIds.length > 0) {
      const monthOrders = await db.select({ id: ordersTable.id }).from(ordersTable)
        .where(sql`${ordersTable.createdAt} >= ${monthStart} AND ${ordersTable.createdAt} <= ${monthEnd}`);
      const monthOrderIds = monthOrders.map((o) => o.id);
      if (monthOrderIds.length > 0) {
        const monthItems = await db.select().from(orderItemsTable)
          .where(sql`${orderItemsTable.productId} = ANY(${productIds}) AND ${orderItemsTable.orderId} = ANY(${monthOrderIds})`);
        for (const item of monthItems) monthRevenue += parseFloat(item.subtotal);
      }
    }
    revenueByMonth.push({
      month: d.toLocaleString("default", { month: "short", year: "2-digit" }),
      revenue: monthRevenue,
    });
  }

  // Top products by revenue
  const topProducts = await Promise.all(
    vendorProducts.map(async (p) => {
      const items = await db.select().from(orderItemsTable).where(eq(orderItemsTable.productId, p.id));
      const revenue = items.reduce((sum, i) => sum + parseFloat(i.subtotal), 0);
      const quantity = items.reduce((sum, i) => sum + i.quantity, 0);
      return { productName: p.name, revenue, quantity };
    })
  );
  topProducts.sort((a, b) => b.revenue - a.revenue);

  // Orders by status
  const ordersByStatus: Record<string, number> = {};
  if (orderIds.length > 0) {
    const statusCounts = await db.select({
      status: ordersTable.status,
      count: sql<number>`count(*)::int`,
    }).from(ordersTable)
      .where(sql`${ordersTable.id} = ANY(${orderIds})`)
      .groupBy(ordersTable.status);
    for (const row of statusCounts) ordersByStatus[row.status] = row.count;
  }

  res.json({
    totalProducts, totalOrders: orderIds.length, grossRevenue, platformFee, netPayout,
    pendingOrders, recentOrders, revenueByMonth, topProducts: topProducts.slice(0, 6), ordersByStatus,
  });
});

vendorOwnerRouter.put("/orders/:id/status", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const vendor = await getVendorForUser(user.id);
  if (!vendor) { res.status(403).json({ message: "No vendor profile found" }); return; }

  const id = parseInt(String(req.params.id));
  const { status } = req.body;
  const validStatuses = ["processing", "shipped", "delivered", "cancelled"];
  if (!validStatuses.includes(status)) { res.status(400).json({ message: "Invalid status" }); return; }

  const vendorProducts = await db.select().from(productsTable).where(eq(productsTable.vendorId, vendor.id));
  const productIds = vendorProducts.map((p) => p.id);
  if (productIds.length === 0) { res.status(403).json({ message: "No products" }); return; }

  const orderItems = await db.select().from(orderItemsTable)
    .where(sql`${orderItemsTable.orderId} = ${id} AND ${orderItemsTable.productId} = ANY(${productIds})`);
  if (orderItems.length === 0) { res.status(403).json({ message: "Order not found for this vendor" }); return; }

  const [order] = await db.update(ordersTable).set({ status }).where(eq(ordersTable.id, id)).returning();
  if (!order) { res.status(404).json({ message: "Order not found" }); return; }
  res.json(await formatOrder(order));
});

vendorOwnerRouter.get("/payment", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const vendor = await getVendorForUser(user.id);
  if (!vendor) { res.status(404).json({ message: "No vendor profile found" }); return; }
  res.json({
    paymentType: vendor.paymentType,
    mpesaNumber: vendor.mpesaNumber,
    bankName: vendor.bankName,
    bankAccount: vendor.bankAccount,
    bankBranch: vendor.bankBranch,
    paybillNumber: vendor.paybillNumber,
    paybillBusinessName: vendor.paybillBusinessName,
    tillNumber: vendor.tillNumber,
  });
});

vendorOwnerRouter.put("/payment", requireAuth, async (req, res) => {
  const user = (req as any).user;
  const vendor = await getVendorForUser(user.id);
  if (!vendor) { res.status(404).json({ message: "No vendor profile found" }); return; }

  const parsed = UpdateVendorPaymentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid payment details", errors: parsed.error.errors });
    return;
  }

  const { paymentType, mpesaNumber, bankName, bankAccount, bankBranch, paybillNumber, paybillBusinessName, tillNumber } = parsed.data;

  const [updated] = await db.update(vendorsTable).set({
    paymentType,
    mpesaNumber: mpesaNumber || null,
    bankName: bankName || null,
    bankAccount: bankAccount || null,
    bankBranch: bankBranch || null,
    paybillNumber: paybillNumber || null,
    paybillBusinessName: paybillBusinessName || null,
    tillNumber: tillNumber || null,
  }).where(eq(vendorsTable.id, vendor.id)).returning();

  res.json({
    paymentType: updated.paymentType,
    mpesaNumber: updated.mpesaNumber,
    bankName: updated.bankName,
    bankAccount: updated.bankAccount,
    bankBranch: updated.bankBranch,
    paybillNumber: updated.paybillNumber,
    paybillBusinessName: updated.paybillBusinessName,
    tillNumber: updated.tillNumber,
  });
});
