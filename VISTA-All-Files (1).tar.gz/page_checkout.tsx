import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useGetCart, useCreateOrder, useCreateGuestOrder, getGetCartQueryOptions } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { useGuestCart } from "@/hooks/use-guest-cart";
import { useLocation } from "wouter";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { getGetCartQueryKey, getListOrdersQueryKey } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Smartphone, Banknote, CreditCard, Building2, Info } from "lucide-react";

const BUYER_FEE_RATE = 0.10;

const PAYMENT_METHODS = [
  {
    id: "mpesa",
    label: "M-PESA",
    description: "Pay via Safaricom M-PESA STK Push",
    icon: Smartphone,
    color: "text-green-600",
    needsPhone: true,
  },
  {
    id: "airtel",
    label: "Airtel Money",
    description: "Pay via Airtel Money",
    icon: Smartphone,
    color: "text-red-500",
    needsPhone: true,
  },
  {
    id: "cash",
    label: "Cash on Delivery",
    description: "Pay cash when your order arrives",
    icon: Banknote,
    color: "text-gray-600",
    needsPhone: false,
  },
  {
    id: "bank",
    label: "Bank Transfer",
    description: "Direct transfer to vendor bank account",
    icon: Building2,
    color: "text-blue-600",
    needsPhone: false,
  },
];

const baseSchema = {
  hostelName: z.string().min(2, "Hostel name is required"),
  roomNumber: z.string().min(1, "Room number is required"),
  contactPhone: z.string().min(9, "Valid phone number required"),
  paymentMethod: z.string().min(1, "Payment method is required"),
  mpesaPhone: z.string().optional(),
};

const guestSchema = z.object({
  ...baseSchema,
  guestName: z.string().min(2, "Full name is required"),
  guestEmail: z.string().email("Valid email is required").optional().or(z.literal("")),
});

const authSchema = z.object({ ...baseSchema });

type GuestValues = z.infer<typeof guestSchema>;
type AuthValues = z.infer<typeof authSchema>;

function PaymentOptions({ field, mpesaPhoneField }: { field: any; mpesaPhoneField?: any }) {
  const selected = field.value;
  const needsPhone = PAYMENT_METHODS.find((m) => m.id === selected)?.needsPhone;

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {PAYMENT_METHODS.map((method) => {
          const Icon = method.icon;
          const isSelected = field.value === method.id;
          return (
            <label
              key={method.id}
              className={`flex items-start gap-3 p-3 border-2 rounded-lg cursor-pointer transition-all ${
                isSelected
                  ? "border-secondary bg-secondary/5"
                  : "border-gray-200 hover:border-gray-300"
              }`}
            >
              <input
                type="radio"
                {...field}
                value={method.id}
                checked={isSelected}
                className="mt-1 text-secondary focus:ring-secondary h-4 w-4"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <Icon className={`h-4 w-4 ${method.color}`} />
                  <span className="font-semibold text-sm text-gray-900">{method.label}</span>
                </div>
                <p className="text-xs text-gray-500 mt-0.5">{method.description}</p>
              </div>
            </label>
          );
        })}
      </div>

      {needsPhone && mpesaPhoneField && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-3">
          <label className="block text-sm font-medium text-green-800 mb-1">
            {selected === "mpesa" ? "M-PESA" : "Airtel Money"} Phone Number
          </label>
          <Input
            {...mpesaPhoneField}
            placeholder="e.g. 0712 345 678"
            type="tel"
            className="border-green-300 focus-visible:ring-green-400"
          />
          <p className="text-xs text-green-700 mt-1">
            You'll receive a payment prompt on this number.
          </p>
        </div>
      )}
    </div>
  );
}

function OrderSummary({
  subtotal,
  itemCount,
  pending,
  formId,
}: {
  subtotal: number;
  itemCount: number;
  pending: boolean;
  formId: string;
}) {
  const buyerFee = subtotal * BUYER_FEE_RATE;
  const total = subtotal + buyerFee;

  return (
    <div className="w-full lg:w-80 flex-shrink-0">
      <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm sticky top-24">
        <h3 className="font-bold text-gray-900 mb-4 text-lg">Order Summary</h3>

        <div className="space-y-2.5 text-sm text-gray-600 border-b pb-4 mb-4">
          <div className="flex justify-between">
            <span>Items ({itemCount}):</span>
            <span className="font-medium text-gray-900">KSh {subtotal.toLocaleString()}</span>
          </div>
          <div className="flex justify-between">
            <span>Delivery:</span>
            <span className="text-green-600 font-medium">Free (campus)</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="flex items-center gap-1">
              Service fee (10%):
              <Info className="h-3 w-3 text-gray-400" />
            </span>
            <span className="font-medium text-orange-600">KSh {buyerFee.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
          </div>
        </div>

        <div className="flex justify-between items-center text-xl font-bold text-gray-900 mb-5">
          <span>Total:</span>
          <span className="text-primary">KSh {total.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
        </div>

        <p className="text-xs text-gray-400 text-center mb-4">
          10% service fee supports platform operations & secure campus delivery.
        </p>

        <Button
          type="submit"
          form={formId}
          className="w-full bg-secondary hover:bg-[#f3a847] text-primary font-bold py-6"
          disabled={pending}
        >
          {pending ? "Processing..." : "Place Order"}
        </Button>
        <p className="text-xs text-gray-400 text-center mt-3">
          By placing your order, you agree to VISTA's conditions of use.
        </p>
      </div>
    </div>
  );
}

export default function CheckoutPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const guestCart = useGuestCart();

  const { data: cartItems, isLoading } = useGetCart({
    query: { ...getGetCartQueryOptions(), enabled: !!user && user.role === "buyer" },
  });

  const createOrderMutation = useCreateOrder({
    mutation: {
      onSuccess: (order) => {
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() });
        toast({ title: "Order placed!", description: `Order #${order.id} confirmed. We'll deliver to your hostel room.` });
        setLocation("/orders");
      },
      onError: (err: any) => {
        toast({ title: "Checkout failed", description: err?.response?.data?.message || "Please try again.", variant: "destructive" });
      },
    },
  });

  const createGuestOrderMutation = useCreateGuestOrder({
    mutation: {
      onSuccess: (order) => {
        guestCart.clearCart();
        toast({ title: "Order placed!", description: `Order #${order.id} confirmed! We'll deliver to your hostel room.` });
        setLocation("/");
      },
      onError: (err: any) => {
        toast({ title: "Checkout failed", description: err?.response?.data?.message || "Please try again.", variant: "destructive" });
      },
    },
  });

  const guestForm = useForm<GuestValues>({
    resolver: zodResolver(guestSchema),
    defaultValues: { guestName: "", guestEmail: "", hostelName: "", roomNumber: "", contactPhone: "", paymentMethod: "mpesa", mpesaPhone: "" },
  });

  const authForm = useForm<AuthValues>({
    resolver: zodResolver(authSchema),
    defaultValues: { hostelName: "", roomNumber: "", contactPhone: "", paymentMethod: "mpesa", mpesaPhone: "" },
  });

  const subtotal = user && cartItems
    ? cartItems.reduce((sum, item) => sum + item.subtotal, 0)
    : guestCart.subtotal;

  const itemCount = user && cartItems
    ? cartItems.reduce((sum, item) => sum + item.quantity, 0)
    : guestCart.totalItems;

  if (isLoading && user) {
    return <div className="container mx-auto px-4 py-12 text-center">Loading checkout...</div>;
  }

  if (user && user.role === "buyer" && (!cartItems || cartItems.length === 0)) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <p className="text-gray-500 mb-4">Your cart is empty.</p>
        <Link href="/products"><Button>Browse products</Button></Link>
      </div>
    );
  }

  const onAuthSubmit = (data: AuthValues) => {
    createOrderMutation.mutate({ data: { ...data } });
  };

  const onGuestSubmit = (data: GuestValues) => {
    if (guestCart.items.length === 0) {
      toast({ title: "No items", description: "Add products to your cart first.", variant: "destructive" });
      return;
    }
    createGuestOrderMutation.mutate({
      data: {
        guestName: data.guestName,
        guestEmail: data.guestEmail || undefined,
        hostelName: data.hostelName,
        roomNumber: data.roomNumber,
        contactPhone: data.contactPhone,
        paymentMethod: data.paymentMethod,
        mpesaPhone: data.mpesaPhone || undefined,
        items: guestCart.items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
      },
    });
  };

  const DeliveryFields = ({ control, step = 1 }: { control: any; step?: number }) => (
    <div className="bg-white p-6 rounded-xl border border-gray-200 space-y-4">
      <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
        <span className="w-7 h-7 rounded-full bg-secondary text-primary font-bold flex items-center justify-center text-sm">{step}</span>
        Delivery Details
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <FormField control={control} name="hostelName" render={({ field }) => (
          <FormItem>
            <FormLabel>Hostel / Block Name</FormLabel>
            <FormControl><Input placeholder="e.g. Block A, Mara Hostel" {...field} /></FormControl>
            <FormMessage />
          </FormItem>
        )} />
        <FormField control={control} name="roomNumber" render={({ field }) => (
          <FormItem>
            <FormLabel>Room Number</FormLabel>
            <FormControl><Input placeholder="e.g. A204" {...field} /></FormControl>
            <FormMessage />
          </FormItem>
        )} />
      </div>
      <FormField control={control} name="contactPhone" render={({ field }) => (
        <FormItem>
          <FormLabel>Contact Phone</FormLabel>
          <FormControl><Input placeholder="e.g. 0712 345 678" type="tel" {...field} /></FormControl>
          <FormMessage />
        </FormItem>
      )} />
    </div>
  );

  if (user && user.role === "buyer") {
    return (
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Checkout</h1>
        <p className="text-gray-500 mb-8">Review your order and choose a payment method.</p>
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="flex-1 space-y-6">
            <Form {...authForm}>
              <form id="checkout-form" onSubmit={authForm.handleSubmit(onAuthSubmit)} className="space-y-6">
                <DeliveryFields control={authForm.control} />
                <div className="bg-white p-6 rounded-xl border border-gray-200">
                  <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <span className="w-7 h-7 rounded-full bg-secondary text-primary font-bold flex items-center justify-center text-sm">2</span>
                    Payment Method
                  </h2>
                  <FormField control={authForm.control} name="paymentMethod" render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <PaymentOptions
                          field={field}
                          mpesaPhoneField={authForm.register("mpesaPhone")}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
                <div className="bg-white p-6 rounded-xl border border-gray-200">
                  <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <span className="w-7 h-7 rounded-full bg-secondary text-primary font-bold flex items-center justify-center text-sm">3</span>
                    Review Cart
                  </h2>
                  <div className="space-y-3">
                    {cartItems?.map((item) => (
                      <div key={item.id} className="flex gap-3 p-3 border rounded-lg">
                        <div className="w-12 h-12 bg-gray-100 rounded flex-shrink-0 flex items-center justify-center overflow-hidden">
                          {item.product?.imageUrl
                            ? <img src={item.product.imageUrl} alt={item.product.name} className="w-full h-full object-cover" />
                            : <CreditCard className="h-5 w-5 text-gray-300" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-gray-900 text-sm line-clamp-1">{item.product?.name}</div>
                          <div className="text-xs text-gray-500">Qty: {item.quantity}</div>
                          <div className="text-sm font-bold text-primary">KSh {item.subtotal.toLocaleString()}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </form>
            </Form>
          </div>
          <OrderSummary subtotal={subtotal} itemCount={itemCount} pending={createOrderMutation.isPending} formId="checkout-form" />
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <h1 className="text-3xl font-bold text-gray-900 mb-2">Checkout</h1>
      <p className="text-gray-500 mb-6">No account needed — fill in your details below.</p>

      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6 flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <p className="text-sm text-blue-800">
          Already have an account?{" "}
          <Link href="/login" className="font-semibold underline">Sign in</Link> for order tracking & history.
        </p>
        <Link href="/register">
          <Button variant="outline" size="sm">Create account</Button>
        </Link>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="flex-1 space-y-6">
          <Form {...guestForm}>
            <form id="guest-checkout-form" onSubmit={guestForm.handleSubmit(onGuestSubmit)} className="space-y-6">
              <div className="bg-white p-6 rounded-xl border border-gray-200 space-y-4">
                <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                  <span className="w-7 h-7 rounded-full bg-secondary text-primary font-bold flex items-center justify-center text-sm">1</span>
                  Your Information
                </h2>
                <FormField control={guestForm.control} name="guestName" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl><Input placeholder="Your full name" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={guestForm.control} name="guestEmail" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email <span className="text-gray-400 text-xs">(optional)</span></FormLabel>
                    <FormControl><Input placeholder="your@email.com" type="email" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <DeliveryFields control={guestForm.control} step={2} />

              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <span className="w-7 h-7 rounded-full bg-secondary text-primary font-bold flex items-center justify-center text-sm">3</span>
                  Payment Method
                </h2>
                <FormField control={guestForm.control} name="paymentMethod" render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <PaymentOptions
                        field={field}
                        mpesaPhoneField={guestForm.register("mpesaPhone")}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              {guestCart.items.length > 0 && (
                <div className="bg-white p-6 rounded-xl border border-gray-200">
                  <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <span className="w-7 h-7 rounded-full bg-secondary text-primary font-bold flex items-center justify-center text-sm">4</span>
                    Review Items
                  </h2>
                  <div className="space-y-3">
                    {guestCart.items.map((item) => (
                      <div key={item.productId} className="flex justify-between items-center border-b pb-2 last:border-0">
                        <span className="text-gray-800 font-medium text-sm">{item.name}</span>
                        <span className="text-sm text-gray-500">×{item.quantity} — KSh {(item.price * item.quantity).toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </form>
          </Form>
        </div>
        <OrderSummary subtotal={subtotal} itemCount={itemCount} pending={createGuestOrderMutation.isPending} formId="guest-checkout-form" />
      </div>
    </div>
  );
}
