import { RefreshCcw, CheckCircle, XCircle, AlertCircle, Package, MessageSquare } from "lucide-react";

const RETURNABLE = [
  "Wrong item delivered",
  "Damaged or broken product on arrival",
  "Product significantly different from description",
  "Missing parts or accessories",
  "Expired food or perishable products",
];

const NOT_RETURNABLE = [
  "Items returned after 48 hours of delivery",
  "Used clothing or personal hygiene products",
  "Digital products and services",
  "Perishable food ordered and accepted without issue",
  "Items damaged by the buyer after delivery",
];

const STEPS = [
  { icon: MessageSquare, title: "Contact Vendor", desc: "Open your order, tap 'Report Issue', and describe the problem. The vendor has 12 hours to respond." },
  { icon: Package, title: "Return the Item", desc: "If approved, arrange to return the item to the vendor at an agreed campus location." },
  { icon: RefreshCcw, title: "Get Refund or Replacement", desc: "Once the vendor confirms receipt, your refund is processed within 24–48 hours, or a replacement is sent." },
];

export default function ReturnsPage() {
  return (
    <div className="min-h-screen">
      <div className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <RefreshCcw className="h-12 w-12 mx-auto mb-4 text-secondary" />
          <h1 className="text-4xl font-bold mb-4">Returns & Replacements</h1>
          <p className="text-xl text-gray-300">
            Not happy with your order? We make returns simple and fair for everyone.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        {/* Policy window */}
        <div className="bg-secondary/10 border border-secondary/30 rounded-xl p-5 flex gap-3 mb-12 text-center justify-center">
          <div>
            <p className="text-3xl font-bold text-primary mb-1">48-Hour</p>
            <p className="font-semibold text-gray-900">Return Window</p>
            <p className="text-sm text-gray-600">All return requests must be submitted within 48 hours of delivery confirmation.</p>
          </div>
        </div>

        {/* Return process */}
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-10">How to Return an Item</h2>
        <div className="grid md:grid-cols-3 gap-6 mb-14">
          {STEPS.map((s, i) => {
            const Icon = s.icon;
            return (
              <div key={s.title} className="bg-white border border-gray-200 rounded-xl p-6 text-center hover:shadow-md transition-shadow">
                <div className="w-12 h-12 rounded-full bg-primary text-white font-bold text-xl flex items-center justify-center mx-auto mb-4">{i + 1}</div>
                <Icon className="h-6 w-6 text-primary mx-auto mb-3" />
                <h3 className="font-bold text-gray-900 mb-2">{s.title}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{s.desc}</p>
              </div>
            );
          })}
        </div>

        {/* What can / can't be returned */}
        <div className="grid md:grid-cols-2 gap-6 mb-10">
          <div className="bg-green-50 border border-green-200 rounded-xl p-6">
            <h3 className="font-bold text-green-900 mb-4 flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" /> Eligible for Return
            </h3>
            <ul className="space-y-2">
              {RETURNABLE.map((r) => (
                <li key={r} className="flex items-start gap-2 text-sm text-green-800">
                  <CheckCircle className="h-3.5 w-3.5 text-green-500 mt-0.5 flex-shrink-0" /> {r}
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-red-50 border border-red-200 rounded-xl p-6">
            <h3 className="font-bold text-red-900 mb-4 flex items-center gap-2">
              <XCircle className="h-5 w-5 text-red-600" /> Not Eligible for Return
            </h3>
            <ul className="space-y-2">
              {NOT_RETURNABLE.map((r) => (
                <li key={r} className="flex items-start gap-2 text-sm text-red-800">
                  <XCircle className="h-3.5 w-3.5 text-red-500 mt-0.5 flex-shrink-0" /> {r}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Dispute */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-5 flex gap-3">
          <AlertCircle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-yellow-900 mb-1">Vendor not responding?</p>
            <p className="text-sm text-yellow-800">
              If a vendor fails to respond within 12 hours or refuses a valid return, escalate to VISTA support at{" "}
              <a href="mailto:support@vista.ac.ke" className="underline font-semibold">support@vista.ac.ke</a>.
              Our team will mediate and issue a refund directly if necessary.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
