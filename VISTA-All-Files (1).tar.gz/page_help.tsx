import { useState } from "react";
import { Link } from "wouter";
import { Search, ShoppingCart, Package, CreditCard, User, Truck, RefreshCcw, MessageSquare, ChevronDown, ChevronUp } from "lucide-react";

const CATEGORIES = [
  { icon: ShoppingCart, label: "Orders", color: "text-blue-600 bg-blue-50" },
  { icon: Package, label: "Products", color: "text-orange-600 bg-orange-50" },
  { icon: CreditCard, label: "Payments", color: "text-green-600 bg-green-50" },
  { icon: User, label: "Account", color: "text-purple-600 bg-purple-50" },
  { icon: Truck, label: "Delivery", color: "text-red-600 bg-red-50" },
  { icon: RefreshCcw, label: "Returns", color: "text-yellow-600 bg-yellow-50" },
];

const FAQS = [
  { q: "How do I place an order?", a: "Browse products, add items to your cart, and go to checkout. Fill in your hostel name, room number, and choose a payment method. Your order is sent to the vendor immediately." },
  { q: "Can I order without an account?", a: "Yes! Guest checkout is supported. Just fill in your name, hostel, room, and phone. You won't be able to track orders afterward, so creating an account is recommended." },
  { q: "How do I track my order?", a: "Log in to your account and go to 'Your Orders'. Each order shows its current status — Pending, Processing, Shipped, or Delivered." },
  { q: "What payment methods are supported?", a: "We accept M-PESA, Airtel Money, Cash on Delivery, and Bank Transfer. M-PESA is the most popular and fastest option on campus." },
  { q: "How do I become a vendor?", a: "Click 'Sell on VISTA' in the footer or visit /vendor/register. Fill in your business details and submit. Our admin team reviews applications within 24 hours." },
  { q: "Why is my order still pending?", a: "Pending means the vendor has received your order but hasn't started preparing it yet. If it stays pending for more than 2 hours, contact the vendor via the order page." },
  { q: "How do I cancel an order?", a: "You can request cancellation from the order detail page if the vendor hasn't started processing. Once an order is in 'Processing' status, contact the vendor directly." },
  { q: "What is the 10% service fee?", a: "A 10% service fee is added to every buyer order at checkout. This fee covers platform operations, campus delivery infrastructure, and payment processing." },
  { q: "How do I change my password?", a: "Go to your Account settings from the top-right menu. You can update your password, email, and phone number there." },
  { q: "I haven't received my order. What do I do?", a: "First check the order status in 'Your Orders'. If it says Delivered but you haven't received it, contact the vendor and then escalate to support@vista.ac.ke if unresolved." },
];

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
      <button className="w-full flex items-center justify-between p-5 text-left hover:bg-gray-50 transition-colors" onClick={() => setOpen(!open)}>
        <span className="font-semibold text-gray-900 pr-4">{q}</span>
        {open ? <ChevronUp className="h-5 w-5 text-gray-400 flex-shrink-0" /> : <ChevronDown className="h-5 w-5 text-gray-400 flex-shrink-0" />}
      </button>
      {open && (
        <div className="px-5 pb-5">
          <p className="text-sm text-gray-600 leading-relaxed">{a}</p>
        </div>
      )}
    </div>
  );
}

export default function HelpPage() {
  const [search, setSearch] = useState("");
  const filtered = FAQS.filter((f) => !search || f.q.toLowerCase().includes(search.toLowerCase()) || f.a.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="min-h-screen">
      <div className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <h1 className="text-4xl font-bold mb-4">Help Centre</h1>
          <p className="text-xl text-gray-300 mb-8">How can we help you today?</p>
          <div className="relative max-w-xl mx-auto">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search for answers..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-12 pr-4 py-4 rounded-xl text-gray-900 text-base focus:outline-none focus:ring-2 focus:ring-secondary"
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        {/* Categories */}
        {!search && (
          <div className="mb-14">
            <h2 className="text-xl font-bold text-gray-900 text-center mb-8">Browse by Topic</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {CATEGORIES.map(({ icon: Icon, label, color }) => (
                <button key={label} onClick={() => setSearch(label.toLowerCase())}
                  className="bg-white border border-gray-200 rounded-xl p-5 flex flex-col items-center gap-3 hover:shadow-md hover:border-primary/30 transition-all group">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${color}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <span className="font-semibold text-gray-900 group-hover:text-primary transition-colors">{label}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* FAQs */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            {search ? `Results for "${search}"` : "Frequently Asked Questions"}
          </h2>
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <Search className="h-10 w-10 mx-auto mb-3 opacity-40" />
              <p>No results found. Try a different search or contact support below.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filtered.map((f) => <FAQItem key={f.q} q={f.q} a={f.a} />)}
            </div>
          )}
        </div>

        {/* Contact Support */}
        <div className="bg-gray-50 rounded-2xl p-8 text-center">
          <MessageSquare className="h-10 w-10 text-primary mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-900 mb-2">Still need help?</h3>
          <p className="text-gray-600 text-sm mb-6">Our support team is available Monday–Friday, 8am–6pm.</p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a href="mailto:support@vista.ac.ke" className="inline-block bg-primary text-white font-semibold px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors">
              Email: support@vista.ac.ke
            </a>
            <a href="https://wa.me/254700000000" className="inline-block bg-green-500 text-white font-semibold px-6 py-3 rounded-lg hover:bg-green-600 transition-colors">
              WhatsApp Us
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
