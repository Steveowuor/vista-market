import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import { AppLayout } from "@/components/layout/AppLayout";
import NotFound from "@/pages/not-found";

// Pages
import HomePage from "@/pages/home";
import ProductsPage from "@/pages/products/index";
import ProductDetailPage from "@/pages/products/detail";
import LoginPage from "@/pages/auth/login";
import RegisterPage from "@/pages/auth/register";
import CartPage from "@/pages/cart";
import CheckoutPage from "@/pages/checkout";
import WishlistPage from "@/pages/wishlist";
import OrderHistoryPage from "@/pages/orders/index";
import OrderDetailPage from "@/pages/orders/detail";

// Vendor Pages
import VendorDashboard from "@/pages/vendor/dashboard";
import VendorRegisterPage from "@/pages/vendor/register";
import VendorSettingsPage from "@/pages/vendor/settings";
import NewProductPage from "@/pages/vendor/products/new";
import EditProductPage from "@/pages/vendor/products/edit";

// Info / Footer Pages
import AboutPage from "@/pages/about";
import CareersPage from "@/pages/careers";
import PressPage from "@/pages/press";
import AffiliatesPage from "@/pages/affiliates";
import AdvertisePage from "@/pages/advertise";
import RewardsPage from "@/pages/rewards";
import StoreCardPage from "@/pages/store-card";
import SecuredCardPage from "@/pages/secured-card";
import ShippingPage from "@/pages/shipping";
import ReturnsPage from "@/pages/returns";
import HelpPage from "@/pages/help";
import AccountPage from "@/pages/account";

// Admin Pages
import AdminDashboard from "@/pages/admin/dashboard";
import AdminOrdersPage from "@/pages/admin/orders";
import AdminCommissionsPage from "@/pages/admin/commissions";
import AdminVendorsPage from "@/pages/admin/vendors";
import AdminCustomersPage from "@/pages/admin/customers";
import AdminReportsPage from "@/pages/admin/reports";
import AdminProductsPage from "@/pages/admin/products";
import VendorOrdersPage from "@/pages/vendor/orders";

const queryClient = new QueryClient();

function Router() {
  return (
    <AppLayout>
      <Switch>
        {/* Public Routes */}
        <Route path="/" component={HomePage} />
        <Route path="/products" component={ProductsPage} />
        <Route path="/categories/:slug">
          {(params) => <ProductsPage params={params} />}
        </Route>
        <Route path="/products/:id" component={ProductDetailPage} />
        
        {/* Auth Routes */}
        <Route path="/login" component={LoginPage} />
        <Route path="/register" component={RegisterPage} />
        
        {/* Buyer Routes */}
        <Route path="/cart" component={CartPage} />
        <Route path="/checkout" component={CheckoutPage} />
        <Route path="/wishlist" component={WishlistPage} />
        <Route path="/orders" component={OrderHistoryPage} />
        <Route path="/orders/:id" component={OrderDetailPage} />
        
        {/* Vendor Routes */}
        <Route path="/vendor/register" component={VendorRegisterPage} />
        <Route path="/vendor/dashboard" component={VendorDashboard} />
        <Route path="/vendor/settings" component={VendorSettingsPage} />
        <Route path="/vendor/products/new" component={NewProductPage} />
        <Route path="/vendor/products/:id/edit" component={EditProductPage} />
        
        {/* Admin Routes */}
        <Route path="/admin/dashboard" component={AdminDashboard} />
        <Route path="/admin/orders" component={AdminOrdersPage} />
        <Route path="/admin/commissions" component={AdminCommissionsPage} />
        <Route path="/admin/vendors" component={AdminVendorsPage} />
        <Route path="/admin/customers" component={AdminCustomersPage} />
        <Route path="/admin/reports" component={AdminReportsPage} />
        <Route path="/admin/products" component={AdminProductsPage} />
        <Route path="/vendor/orders" component={VendorOrdersPage} />

        {/* Footer / Info Pages */}
        <Route path="/about" component={AboutPage} />
        <Route path="/careers" component={CareersPage} />
        <Route path="/press" component={PressPage} />
        <Route path="/affiliates" component={AffiliatesPage} />
        <Route path="/advertise" component={AdvertisePage} />
        <Route path="/rewards" component={RewardsPage} />
        <Route path="/store-card" component={StoreCardPage} />
        <Route path="/reload" component={SecuredCardPage} />
        <Route path="/shipping" component={ShippingPage} />
        <Route path="/returns" component={ReturnsPage} />
        <Route path="/help" component={HelpPage} />
        <Route path="/account" component={AccountPage} />

        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <Router />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;