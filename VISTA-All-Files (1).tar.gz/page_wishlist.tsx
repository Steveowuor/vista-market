import { useGetWishlist, getGetWishlistQueryOptions } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { ProductCard } from "@/components/product/product-card";
import { Skeleton } from "@/components/ui/skeleton";
import { Heart } from "lucide-react";

export default function WishlistPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: wishlistItems, isLoading } = useGetWishlist({
    query: {
      ...getGetWishlistQueryOptions(),
      enabled: !!user && user.role === "buyer",
    }
  });

  if (!user || user.role !== "buyer") {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold mb-4">Please sign in to view your wishlist</h2>
        <button 
          onClick={() => setLocation("/login")}
          className="bg-primary text-white px-6 py-2 rounded-md hover:bg-primary/90"
        >
          Sign In
        </button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Your Wishlist</h1>

      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {Array(8).fill(0).map((_, i) => (
            <div key={i} className="flex flex-col space-y-3">
              <Skeleton className="h-[200px] w-full rounded-xl" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-4 w-[80%]" />
              </div>
            </div>
          ))}
        </div>
      ) : wishlistItems && wishlistItems.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {wishlistItems.map((item) => item.product ? (
            <ProductCard key={item.id} product={item.product} />
          ) : null)}
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-lg border border-gray-200">
          <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4 text-gray-400">
            <Heart className="h-8 w-8" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Your wishlist is empty</h2>
          <p className="text-gray-500 mb-6">Keep track of items you love by clicking the heart icon on products.</p>
          <button 
            onClick={() => setLocation("/products")}
            className="bg-secondary text-primary font-medium px-6 py-2 rounded-md hover:bg-[#f3a847]"
          >
            Explore Products
          </button>
        </div>
      )}
    </div>
  );
}